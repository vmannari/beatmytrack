"""Weekly championships over immutable tracks and server-verified races."""
from __future__ import annotations

import secrets
import statistics
from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException, Query, Request
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import literal_column, or_, select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import aliased

from .appearance_routes import owner_for_write
from .contracts import compatible_physics_versions, vehicle_build_contract
from .identity_models import Player
from .middleware import ParsedJSONRoute
from .rivalry_models import RivalryArchivedBest, RivalryBest, RivalryGroup, RivalryMember, RivalryTicket
from .runs import PINNED_FIELDS, BoardDB, _ticket_payload, board_manifest
from .test_population import check_scope, contract_scope
from .track_models import (
    Board,
    IdempotencyRecord,
    OperationState,
    PersonalBest,
    Run,
    RunTicket,
    Track,
    TrackVersion,
    commit_response,
    digest,
    new_id,
    now,
    replay_response,
)
from .tracks import DB, Auth, Key, track_payload
from .vehicle_appearance import Appearance

router = APIRouter(route_class=ParsedJSONRoute, tags=["weekly rivalry"])
TRACK_COUNT = 5
GROUP_CAPACITY = 20
POINTS = (30, 26, 23, 20, 18, 16, 14, 12, 10, 8, 6, 4, 2, 1, 1, 1, 1, 1, 1, 1)
random = secrets.SystemRandom()


class Join(BaseModel):
    model_config = ConfigDict(extra="forbid")
    vehicle_id: str = Field(min_length=1, max_length=80)
    test_population: bool = False
    automatic_test_drivers: bool = False


class Race(BaseModel):
    model_config = ConfigDict(extra="forbid")
    slot: int = Field(strict=True, ge=0, lt=TRACK_COUNT)


@router.put("/rivalry/appearance")
def save_appearance(payload: Appearance, session: DB, player: Auth):
    # Serialize per-player car updates with other devices and account erasure.
    owner = owner_for_write(session, player.id)
    from .appearance_authorization import require_owned
    require_owned(session, player.id, payload)
    value = payload.model_dump()
    owner.vehicle_appearances = {**owner.vehicle_appearances, payload.vehicle_id: value}
    session.commit()
    return value


def week_window(timestamp: int) -> tuple[int, int, int, int]:
    day = timestamp // 86400
    start = (day - (day + 3) % 7) * 86400  # Monday 00:00 UTC.
    iso = datetime.fromtimestamp(start, timezone.utc).isocalendar()
    return start, start + 7 * 86400, iso.year, iso.week


def active_contract(request, vehicle):
    try:
        active = request.app.state.verifier.manifest()
    except RuntimeError:
        raise HTTPException(503, "Race verifier temporarily unavailable") from None
    config = active.get("vehicles", {}).get(vehicle)
    if not config:
        raise HTTPException(422, "Vehicle is not allowed by the server manifest")
    return active, digest(vehicle_build_contract(active, vehicle))


def compatible_contract_keys(active, vehicle, test_population=False):
    """Keep existing memberships/circuits under their original immutable key."""
    return [contract_scope(digest(vehicle_build_contract({**active, "physics_version": version}, vehicle)), test_population)
            for version in compatible_physics_versions(active["physics_version"], vehicle)]


def compatible_fields(column, active, vehicle):
    conditions = []
    for field in PINNED_FIELDS:
        values = [active[field]]
        if field == "physics_version":
            values = list(compatible_physics_versions(active[field], vehicle))
        if field == "rules_key" and active[field] in ("standing-5-road-gates-v18", "standing-5-road-gates-v19", "standing-5-road-gates-v20", "standing-5-road-gates-v21", "standing-5-road-gates-v22", "standing-5-road-gates-v23", "standing-5-road-gates-v24"):
            upper = int(active[field].rsplit("v", 1)[1])
            values += [f"standing-5-road-gates-v{n}" for n in range(12, upper)]
        if field == "physics_version" and active[field] in ("arcade-planar-0.50", "arcade-planar-0.51", "arcade-planar-0.52", "arcade-planar-0.53"):
            upper = int(active[field].rsplit(".", 1)[1])
            values += [f"arcade-planar-0.{n}" for n in range(39, upper)]
        item = column[field].as_integer() if type(active[field]) is int else column[field].as_string()
        conditions.append(item.in_(values))
    return conditions


def eligible_query(active, vehicle):
    newer = aliased(TrackVersion)
    config = active["vehicles"][vehicle]
    return (select(TrackVersion).join(Track).join(Player, Player.id == Track.owner_id)
        .where(TrackVersion.state == "published", Track.hidden.is_(False), Player.disabled.is_(False),
            ~select(newer.id).where(newer.track_id == Track.id, newer.state == "published",
                                   newer.number > TrackVersion.number).exists(),
            or_(Track.official.is_(True), (TrackVersion.rating_count > 0)
                & (TrackVersion.rating_sum > 4 * TrackVersion.rating_count) & (TrackVersion.verified_finishers > 100)),
            *compatible_fields(TrackVersion.manifest, active, vehicle),
            *[TrackVersion.manifest["vehicles"][vehicle][key].as_string() == config[key]
              for key in ("handling_version", "config_hash")]))


def eligible_versions(session, active, vehicle):
    """Indexed, bounded candidate window; no PB aggregation or global random sort."""
    statement = eligible_query(active, vehicle)
    anchor = new_id()
    rows = session.scalars(statement.where(TrackVersion.id >= anchor).order_by(TrackVersion.id).limit(1000)).all()
    if len(rows) < 1000:
        rows += session.scalars(statement.where(TrackVersion.id < anchor).order_by(TrackVersion.id).limit(1000-len(rows))).all()
    return rows


def selected_slots(session, request, active, vehicle, test_population, *, timestamp=None, use_circuit=True):
    from .rivalry_planning import planned_versions
    timestamp = now() if timestamp is None else timestamp
    if use_circuit and vehicle == "compact" and not test_population:
        from .world_ranking_models import Circuit
        circuit = session.scalar(select(Circuit).where(Circuit.week_start == week_window(timestamp)[0]))
        if circuit is not None and circuit.contract_key in compatible_contract_keys(active, vehicle):
            return circuit.tracks
    chosen = planned_versions(session, active, vehicle, timestamp)
    if len(chosen) < TRACK_COUNT:
        return []
    metadata = {version.id: (version, track, name) for version,track,name in session.execute(
        select(TrackVersion,Track,Player.display_name).select_from(TrackVersion).join(Track).join(Player,Player.id==Track.owner_id)
        .where(TrackVersion.id.in_(chosen)))}
    slots=[]
    for vid in chosen:
        version,track,name = metadata[vid]
        pinned=board_manifest(version,vehicle)
        if test_population:
            pinned={**pinned,"test_population":True}
        bid=digest({"version_id":vid,**pinned})
        entry=track_payload(version,track,name,request.app.state.settings.public_base_url)
        entry.pop("manifest",None)
        slots.append({"version_id":vid,"board_id":bid,"tick_rate":pinned["tick_rate"],"entry":entry,"manifest":pinned})
    return slots


def skill_score(session, player_id, vehicle, active, timestamp, test_population=False):
    """Two queries, at most 20 indexed comparable boards; exact tied percentiles."""
    config = active["vehicles"][vehicle]
    own = session.execute(select(PersonalBest, Board).join(Board)
        .where(PersonalBest.player_id == player_id, Board.vehicle_id == vehicle,
            PersonalBest.achieved_at >= timestamp - 90 * 86400,
            Board.manifest["purpose"].as_string().is_(None),
            Board.manifest["test_population"].as_boolean().is_(True) if test_population else Board.manifest["test_population"].as_boolean().is_not(True),
            Board.manifest["rules_key"].as_string() == active["rules_key"],
            Board.manifest["physics_version"].as_string().in_(compatible_physics_versions(active["physics_version"], vehicle)),
            Board.manifest["config_hash"].as_string() == config["config_hash"])
        .order_by(PersonalBest.achieved_at.desc(), Board.id).limit(20)).all()
    if not own:
        return None
    from .leaderboard_ranks import time_counts_many
    frequencies = time_counts_many(session, [(board.id, best.time_ticks) for best, board in own],
                                   artificial=test_population)
    scores = []
    for best, board in own:
        total = board.all_count if test_population else board.public_count
        if total < 5:
            continue
        _, tied, slower = frequencies.get(board.id, (0, 0, 0))
        scores.append(round(1000 * (slower + (tied - 1) / 2) / (total - 1)))
    return round(statistics.median(scores)) if len(scores) >= 3 else None


def require_member(session, group_id, player_id, request=None):
    member = session.get(RivalryMember, (group_id, player_id))
    group = session.get(RivalryGroup, group_id)
    if member is None or group is None:
        raise HTTPException(404, "Rivalry not found")
    if request is not None:
        check_scope(request, group.test_population, session.get(Player, player_id))
    return group, member


def rankings(rows, key, reverse=False):
    rows.sort(key=lambda row: (row[key] is None, -row[key] if reverse and row[key] is not None else row[key] or 0, row["id"]))
    previous, rank = None, None
    for position, row in enumerate(rows):
        if row[key] is None:
            row["rank"] = None
            continue
        if rank is None or row[key] != previous:
            rank = position + 1
        row["rank"], previous = rank, row[key]
    return rows


def standings_data(session, group, facts=None):
    if facts is None:
        players = session.execute(select(Player.id, Player.display_name, Player.is_test_driver, Player.country_code).join(RivalryMember)
            .where(RivalryMember.group_id == group.id, Player.disabled.is_(False)).order_by(Player.id)).all()
        model = RivalryArchivedBest if group.archived else RivalryBest
        bests = {(best.slot, best.player_id): {"ticks": best.time_ticks, "run_id": getattr(best, "run_id", None)}
                 for best in session.scalars(select(model).where(model.group_id == group.id))}
    else:
        players = [(p["id"], p["name"], p["is_test_driver"], p["country_code"]) for p in facts["players"]]
        bests = {(best["slot"], best["id"]): best for best in facts["bests"]}
    totals = {pid: {"id": pid, "name": name, "is_test_driver": synthetic, "country_code": country, "points": 0, "completed": 0} for pid, name, synthetic, country in players}
    tracks = []
    for slot, entry in enumerate(group.tracks):
        rows = []
        for pid, name, synthetic, country in players:
            best = bests.get((slot, pid))
            rows.append({"id": pid, "name": name, "is_test_driver": synthetic, "country_code": country, "ticks": best["ticks"] if best else None,
                         "ms": round(best["ticks"] * 1000 / entry["tick_rate"]) if best else None,
                         "run_id": best["run_id"] if best else None})
        rankings(rows, "ticks")
        for row in rows:
            row["points"] = POINTS[row["rank"] - 1] if row["rank"] else 0
            totals[row["id"]]["points"] += row["points"]
            totals[row["id"]]["completed"] += int(row["ticks"] is not None)
        tracks.append(rows)
    overall = rankings(list(totals.values()), "points", True)
    for row in overall:
        if row["completed"] == 0:
            row["rank"] = None
    return tracks, overall


def snapshot(session, group, player_id, timestamp=None, *, facts=None):
    timestamp = now() if timestamp is None else timestamp
    if facts is None:
        from .rivalry_reads import read_snapshot
        facts = read_snapshot(session, group, player_id, timestamp)
    tracks, overall = standings_data(session, group, facts)
    blocked = set(facts["blocked"])
    appearances = {p["id"]: p["appearances"] for p in facts["players"]}
    for row in overall:
        appearance = appearances.get(row["id"], {}).get(group.vehicle_id)
        if appearance is not None:
            row["appearance"] = appearance
    for row in overall + [row for board_rows in tracks for row in board_rows]:
        if row["id"] in blocked:
            row["name"], row["country_code"] = "Blocked player", ""
            row.pop("appearance", None)
    pending, state = facts["pending"], facts["state"]
    personal_best_slots = facts["personal_best_slots"]
    iso = datetime.fromtimestamp(group.week_start, timezone.utc).isocalendar()
    result = {"group_id": group.id, "state": state, "week": iso.week, "year": iso.year,
              "world_circuit": {"id": group.world_circuit_id, "official": True, "required_tracks": 5,
                                "free_resumes": 3, "week_start": group.week_start} if group.world_circuit_id else None,
              "ends_at": group.ends_at, "server_now": timestamp, "remaining_seconds": max(0, group.ends_at - timestamp),
              "vehicle_id": group.vehicle_id, "placement": group.skill_band == -1, "driver_count": len(overall),
              "test_population": group.test_population,
              "automatic_test_drivers": bool(group.tracks[0].get("automatic_test_drivers", False)),
              "group_forming": len(overall) < 10, "standings": overall, "self_id": player_id, "tracks": [],
              "points_policy": list(POINTS), "pending_runs": pending, "personal_best_slots": personal_best_slots}
    for slot, pinned in enumerate(group.tracks):
        entry = pinned["entry"]
        version = facts["versions"].get(pinned["version_id"])
        available = bool(version and version["available"] and version["owner_id"] not in blocked)
        if version is not None:
            if version["deleted_at"] is not None:
                # Refresh redacted source hashes as well as names for retained
                # cohort snapshots; their board/score pins remain unchanged.
                entry = {**entry, "creator": "Removed account", "content_hash": version["content_hash"],
                    "redacted_track_hash": version["redacted_track_hash"], "canonical_track_hash": version["canonical_track_hash"]}
        if not available:
            # Keep score/board pins while withdrawing objectionable public art/text.
            entry = {**entry, "name": "Unavailable track", "creator": "Unavailable creator", "points": []}
        result["tracks"].append({"slot": slot, "entry": entry, "board_id": pinned["board_id"],
                                 "available": not group.archived and available,
                                 "entries": tracks[slot]})
    return result


def finish_join_response(session, player_id, key, saved):
    """Persist the response after releasing cohort capacity locks.

    Membership and a recoverable retry marker commit together. If this process
    dies before the snapshot is saved, the same key completes it without joining
    twice. Concurrent retries return the first frozen response.
    """
    if not saved.get("_rivalry_snapshot_pending"):
        return saved
    session.commit()
    if session.bind.dialect.name == "postgresql":
        from sqlalchemy import text
        session.execute(text("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ"))
    group = session.get(RivalryGroup, saved["group_id"])
    result = snapshot(session, group, player_id)
    session.commit()
    row = session.scalar(select(IdempotencyRecord).where(IdempotencyRecord.player_id==player_id,
        IdempotencyRecord.scope=="rivalry_join",IdempotencyRecord.key==key).with_for_update()
        .execution_options(populate_existing=True))
    if row.response.get("_rivalry_snapshot_pending"):
        row.response = result
    frozen = row.response
    session.commit()
    return frozen


def commit_join(session, player_id, key, body, group_id, circuit_id=None):
    from .world_circuit import enter
    group = session.get(RivalryGroup, group_id)
    if group.world_circuit_id != circuit_id:
        raise HTTPException(409, "CIRCUIT_MEMBERSHIP_CONFLICT")
    enter(session, group, session.get(Player, player_id))
    if body.get("automatic_test_drivers"):
        from .automatic_test_drivers import enroll
        enroll(session, group_id)
    saved=commit_response(session,player_id,"rivalry_join",key,body,
        {"_rivalry_snapshot_pending":True,"group_id":group_id})
    return finish_join_response(session,player_id,key,saved)


@router.get("/rivalry/current")
def current(request: Request, session: BoardDB, player: Auth, vehicle_id: str = Query(min_length=1, max_length=80), test_population: bool = False):
    check_scope(request, test_population, player)
    active, _contract = active_contract(request, vehicle_id)
    contracts = compatible_contract_keys(active, vehicle_id, test_population)
    start, end, year, week = week_window(now())
    member = session.scalar(select(RivalryMember).where(RivalryMember.player_id == player.id,
        RivalryMember.week_start == start, RivalryMember.contract_key.in_(contracts))
        .order_by(RivalryMember.joined_at.desc(), RivalryMember.group_id).limit(1))
    if member:
        return snapshot_response(request, session, session.get(RivalryGroup, member.group_id), player.id)
    previous = session.scalar(select(RivalryMember).join(RivalryGroup)
        .where(RivalryMember.player_id == player.id, RivalryGroup.vehicle_id == vehicle_id,
               RivalryGroup.test_population.is_(test_population),
               RivalryMember.week_start < start, RivalryMember.acknowledged.is_(False))
        # A build update can create several memberships in the same week.
        # Resume the player's latest field instead of an arbitrary old build.
        .order_by(RivalryMember.week_start.desc(), RivalryMember.joined_at.desc(),
                  RivalryGroup.created_at.desc(), RivalryGroup.id).limit(1))
    if previous:
        return snapshot_response(request, session, session.get(RivalryGroup, previous.group_id), player.id)
    return {"state": "not_joined", "test_population": test_population, "week": week, "year": year, "ends_at": end, "server_now": now(),
            "eligible_track_count": len(session.scalars(eligible_query(active, vehicle_id).limit(TRACK_COUNT)).all()),
            "eligible_track_count_capped": True, "required_track_count": TRACK_COUNT}


@router.post("/rivalry/join")
def join(payload: Join, request: Request, session: DB, player: Auth, key: Key):
    check_scope(request, payload.test_population, player)
    if payload.automatic_test_drivers and (not payload.test_population or player.is_test_driver):
        raise HTTPException(422, "AUTOMATIC_DRIVERS_REQUIRE_HUMAN_TEST_RIVALRY")
    body = payload.model_dump(exclude={"automatic_test_drivers"})
    if payload.automatic_test_drivers:
        body["automatic_test_drivers"] = True
    old = replay_response(session, player.id, "rivalry_join", key, body)
    if old is not None:
        return finish_join_response(session,player.id,key,old)
    if player.needs_username:
        raise HTTPException(409, "USERNAME_REQUIRED")
    active, contract = active_contract(request, payload.vehicle_id)
    contract = contract_scope(contract, payload.test_population)
    contracts = compatible_contract_keys(active, payload.vehicle_id, payload.test_population)
    timestamp = now()
    start, end, _, _ = week_window(timestamp)
    circuit_id = None
    launch = request.app.state.settings.world_ranking_launch_week
    if launch and start >= launch and payload.vehicle_id == "compact" and not payload.test_population:
        from .world_ranking_models import Circuit
        circuit = session.scalar(select(Circuit).where(Circuit.week_start == start))
        if circuit is None:
            raise HTTPException(503, "CIRCUIT_PREPARING")
        if circuit.contract_key not in contracts:
            raise HTTPException(409, "CIRCUIT_BUILD_PINNED_UNTIL_NEXT_WEEK")
        contract = circuit.contract_key
        circuit_id = circuit.id
    member = session.scalar(select(RivalryMember).where(RivalryMember.player_id == player.id,
        RivalryMember.week_start == start, RivalryMember.contract_key.in_(contracts))
        .order_by(RivalryMember.joined_at.desc(), RivalryMember.group_id).limit(1))
    if member:
        return commit_join(session,player.id,key,body,member.group_id,circuit_id)
    session.scalar(select(Player).where(Player.id == player.id).with_for_update())
    member = session.scalar(select(RivalryMember).where(RivalryMember.player_id == player.id,
        RivalryMember.week_start == start, RivalryMember.contract_key.in_(contracts))
        .order_by(RivalryMember.joined_at.desc(), RivalryMember.group_id).limit(1))
    if member:
        return commit_join(session,player.id,key,body,member.group_id,circuit_id)
    skill = skill_score(session, player.id, payload.vehicle_id, active, timestamp, payload.test_population)
    # Expensive candidate selection is read work outside the cohort reservation.
    prepared_slots = selected_slots(session,request,active,payload.vehicle_id,payload.test_population)
    band = min(9, skill // 100) if skill is not None else -1
    group = reserve_compatible_group(session, start, contract, contracts, band, circuit_id)
    if group is None:
        # Only creation takes a guard. A busy open group must fill before another
        # is created; ordinary joins lock their group, never the whole skill band.
        lock_id = digest({"purpose": "rivalry-create-v2", "week": start, "contract": contract, "band": band})
        if session.get(OperationState, lock_id) is None:
            try:
                with session.begin_nested():
                    session.add(OperationState(id=lock_id))
                    session.flush()
            except IntegrityError:
                pass
        session.scalar(select(OperationState).where(OperationState.id == lock_id).with_for_update())
        group = reserve_compatible_group(session, start, contract, contracts, band, circuit_id)
    if group is None:
        if len(prepared_slots) < TRACK_COUNT:
            raise HTTPException(409, "NOT_ENOUGH_ELIGIBLE_TRACKS")
        slots = []
        for prepared in prepared_slots:
            board_id = prepared["board_id"]
            if session.get(Board, board_id) is None:
                try:
                    with session.begin_nested():
                        session.add(Board(id=board_id, version_id=prepared["version_id"], vehicle_id=payload.vehicle_id, manifest=prepared["manifest"]))
                        session.flush()
                except IntegrityError:
                    pass
            slots.append({key:value for key,value in prepared.items() if key!="manifest"})
        group = RivalryGroup(week_start=start, ends_at=end, vehicle_id=payload.vehicle_id,
                             world_circuit_id=circuit_id,
                             test_population=payload.test_population,
                             contract_key=contract, skill_band=band, tracks=slots, member_count=1)
        session.add(group)
        session.flush()
    session.add(RivalryMember(group_id=group.id, player_id=player.id, week_start=start, contract_key=group.contract_key, skill=skill))
    session.flush()
    return commit_join(session,player.id,key,body,group.id,circuit_id)


def reserve_compatible_group(session, start, preferred, contracts, band, circuit_id):
    for contract in (preferred, *(value for value in contracts if value != preferred)):
        group = reserve_open_group(session, start, contract, band, circuit_id)
        if group is not None:
            return group
    return None


def open_group_candidates(start, contract, band):
    # Literal predicate also permits the partial index in PostgreSQL generic plans.
    return select(RivalryGroup.id).where(RivalryGroup.week_start == start,
        RivalryGroup.contract_key == contract, RivalryGroup.skill_band == band,
        RivalryGroup.member_count < literal_column("20")).order_by(
            RivalryGroup.created_at, RivalryGroup.id).limit(100)


def reserve_open_group(session, start, contract, band, circuit_id=None):
    candidates = list(session.scalars(open_group_candidates(start, contract, band).where(
        RivalryGroup.world_circuit_id == circuit_id)))
    random.shuffle(candidates)
    for identity in candidates:
        candidate = session.scalar(select(RivalryGroup).where(RivalryGroup.id == identity,
            RivalryGroup.member_count < GROUP_CAPACITY).with_for_update(skip_locked=True))
        if candidate is None:
            continue
        # SQLite has no row locks; the conditional write still enforces capacity.
        reserved = session.execute(update(RivalryGroup).where(RivalryGroup.id == identity,
            RivalryGroup.member_count < GROUP_CAPACITY).values(member_count=RivalryGroup.member_count + 1)).rowcount
        if reserved:
            return candidate
    if candidates:
        # All open candidates may be locked by in-flight joins. Wait for one
        # group's exact capacity decision instead of fragmenting a 20-driver
        # field into many smaller groups. Other open groups were tried first.
        candidate = session.scalar(select(RivalryGroup).where(RivalryGroup.id == candidates[0],
            RivalryGroup.member_count < GROUP_CAPACITY).with_for_update())
        if candidate is not None and session.execute(update(RivalryGroup).where(
                RivalryGroup.id == candidate.id, RivalryGroup.member_count < GROUP_CAPACITY)
                .values(member_count=RivalryGroup.member_count + 1)).rowcount:
            return candidate
    return None


@router.get("/rivalry/{group_id}")
def view(group_id: str, request: Request, session: BoardDB, player: Auth):
    group, _ = require_member(session, group_id, player.id, request)
    return snapshot_response(request, session, group, player.id)


@router.post("/rivalry/{group_id}/tickets", status_code=201)
def ticket(group_id: str, payload: Race, request: Request, session: DB, player: Auth, key: Key):
    body, scope = payload.model_dump(), "rivalry_ticket:" + group_id
    old = replay_response(session, player.id, scope, key, body)
    if old is not None:
        return old
    group, _ = require_member(session, group_id, player.id, request)
    if now() >= group.ends_at:
        raise HTTPException(410, "RIVALRY_WEEK_ENDED")
    active, _contract = active_contract(request, group.vehicle_id)
    if group.contract_key not in compatible_contract_keys(active, group.vehicle_id, group.test_population):
        raise HTTPException(409, "RIVALRY_BUILD_CHANGED")
    pinned = group.tracks[payload.slot]
    version = session.get(TrackVersion, pinned["version_id"])
    track = session.get(Track, version.track_id)
    from .community import check_creator
    check_creator(session, player.id, track.owner_id)
    if version.state != "published" or track.hidden or session.get(Player, track.owner_id).disabled:
        raise HTTPException(404, "Rivalry track unavailable")
    board = session.get(Board, pinned["board_id"])
    race_ticket = RunTicket(player_id=player.id, board_id=board.id, expires_at=min(now() + 7200, group.ends_at))
    session.add(race_ticket)
    session.flush()
    session.add(RivalryTicket(ticket_id=race_ticket.id, group_id=group.id, slot=payload.slot))
    return commit_response(session, player.id, scope, key, body,
                           {**_ticket_payload(race_ticket, board), "rivalry_group": group.id, "rivalry_slot": payload.slot})


def accept_verified(session, run, *, acceptance=None):
    """Called within fenced worker finalization; retries/slower runs mint no points."""
    binding = acceptance.rivalry if acceptance else session.get(RivalryTicket, run.ticket_id)
    if binding is None or binding.outcome is not None:
        return
    group = session.scalar(select(RivalryGroup).where(RivalryGroup.id == binding.group_id).with_for_update())
    if not group.week_start <= run.created_at < group.ends_at:
        return
    before_tracks, before_overall = standings_data(session, group)
    prior = next(row for row in before_tracks[binding.slot] if row["id"] == run.player_id)
    previous = acceptance.previous[0] if acceptance else None
    if previous is None:
        personal_best = session.get(PersonalBest, (run.board_id, run.player_id))
        previous = personal_best.time_ticks if personal_best else 0
    new_personal_best = run.status != "skipped" and (not previous or run.time_ticks < previous)
    best = session.get(RivalryBest, (group.id, run.player_id, binding.slot))
    improved = run.status != "skipped" and (best is None or run.time_ticks < best.time_ticks)
    if improved:
        if best is None:
            best = RivalryBest(group_id=group.id, player_id=run.player_id, slot=binding.slot)
            session.add(best)
        best.run_id, best.time_ticks, best.achieved_at = run.id, run.time_ticks, now()
        session.flush()
    after_tracks, after_overall = standings_data(session, group) if improved else (before_tracks, before_overall)
    after = next(row for row in after_tracks[binding.slot] if row["id"] == run.player_id)
    beaten = [row for row in before_tracks[binding.slot] if row["id"] != run.player_id and row["ticks"] is not None
              and run.time_ticks < row["ticks"] and (prior["ticks"] is None or row["ticks"] < prior["ticks"])] if improved else []
    binding.outcome = {"improved": improved, "personal_best": new_personal_best, "before": prior, "after": after,
                       "points_delta": after["points"] - prior["points"], "beaten": beaten,
                       "ms": round(run.time_ticks * 1000 / group.tracks[binding.slot]["tick_rate"]),
                       "overall_before": next(row for row in before_overall if row["id"] == run.player_id),
                       "overall_after": next(row for row in after_overall if row["id"] == run.player_id)}


@router.get("/rivalry/tickets/{ticket_id}/result")
def result(ticket_id: str, request: Request, session: BoardDB, player: Auth):
    own = session.get(RunTicket, ticket_id)
    binding = session.get(RivalryTicket, ticket_id)
    if own is None or binding is None or own.player_id != player.id:
        raise HTTPException(404, "Rivalry result not found")
    require_member(session, binding.group_id, player.id, request)
    run = session.scalar(select(Run).where(Run.ticket_id == ticket_id))
    status = run.status if run else "verified" if binding.outcome else "expired" if now() >= own.expires_at else "upload_pending"
    from .runs import pending_poll_ms
    return {"status": status, "poll_after_ms": pending_poll_ms(run,status),
            "failure_code": run.failure_code if run else None,
            "outcome": binding.outcome, "slot": binding.slot}


@router.post("/rivalry/{group_id}/continue")
def acknowledge(group_id: str, request: Request, session: DB, player: Auth, key: Key):
    scope = "rivalry_continue:" + group_id
    old = replay_response(session, player.id, scope, key, {})
    if old is not None:
        return old
    group, _ = require_member(session, group_id, player.id, request)
    if snapshot(session, group, player.id)["state"] != "complete":
        raise HTTPException(409, "RIVALRY_NOT_COMPLETE")
    # Continue leaves the reviewed finale and any older history in this car's
    # population. Otherwise /current walks the unacknowledged weeks backwards
    # and makes the player press Continue once for every missed finale.
    ended_groups = select(RivalryGroup.id).where(
        RivalryGroup.vehicle_id == group.vehicle_id,
        RivalryGroup.test_population.is_(group.test_population),
        RivalryGroup.week_start <= group.week_start,
        RivalryGroup.ends_at <= now(),
    )
    session.execute(update(RivalryMember).where(
        RivalryMember.player_id == player.id,
        RivalryMember.group_id.in_(ended_groups),
        RivalryMember.acknowledged.is_(False),
    ).values(acknowledged=True))
    return commit_response(session, player.id, scope, key, {}, {"acknowledged": True})


@router.get("/rivalry/{group_id}/tracks/{slot}/ghosts/{driver_id}")
def ghost(group_id: str, slot: int, driver_id: str, request: Request, session: BoardDB, player: Auth,
          metadata: bool = False, expected_run_id: str = "", encoding: str = "json"):
    from .community import check_creator
    check_creator(session, player.id, driver_id)
    group, _ = require_member(session, group_id, player.id, request)
    if group.archived:
        raise HTTPException(410, "RIVALRY_GHOST_ARCHIVED")
    if session.get(RivalryMember, (group_id, driver_id)) is None or session.get(Player, driver_id).disabled:
        raise HTTPException(404, "Rival ghost unavailable")
    best = session.get(RivalryBest, (group_id, driver_id, slot))
    run = session.get(Run, best.run_id) if best else None
    if run is None or not run.ghost_hash:
        raise HTTPException(404, "Rival ghost unavailable")
    run_id, ghost_hash, owner_id = run.id, run.ghost_hash, run.player_id
    session.commit()
    from .ghost_http import recording_response
    return recording_response(request, run_id, ghost_hash, owner_id, metadata=metadata, expected_run_id=expected_run_id, encoding=encoding)


def snapshot_response(request, session, group, player_id):
    from .rivalry_reads import response
    return response(request, session, group, player_id, now())


def conditional_snapshot(request, value):
    from fastapi.responses import JSONResponse, Response
    stable = {key: data for key, data in value.items() if key not in ("server_now", "remaining_seconds")}
    tag = '"' + digest(stable) + '"'
    headers = {"ETag": tag, "Cache-Control": "private, no-cache, must-revalidate", "Vary": "Authorization, Accept-Encoding", "X-Server-Time": str(value["server_now"])}
    if request.headers.get("if-none-match") == tag:
        return Response(status_code=304, headers=headers)
    return JSONResponse(value, headers=headers)
