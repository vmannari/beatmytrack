extends Node
signal identity_changed
signal run_completed
## Optional online adapter. The local game and canonical step never depend on it.
## Browser sign-in and UI live in account_controller.gd. Persisted credentials are protected by the platform vault.
const MAX_RESPONSE_BYTES: int = 8388608
const INLINE_RESPONSE_BYTES: int = 32768
var _base_url: String = ""
var _access_token: String = ""
var _refresh_token: String = ""
var _login_id: String = ""
var _busy: bool = false
var _refresh_busy: bool = false
var _session_generation: int = 0
var player: Dictionary = {}
# Empty disables persistence for standalone adapters/tests. Never include in exports.
var session_path: String = ""
var persistence_error: bool = false
var _public_reads: Array[HTTPRequest] = []
var _telemetry_requests: Array[HTTPRequest] = []
var _telemetry_epoch: int = 1
var _configuration_epoch: int = 1
var _rotation_locks: Array[RefCounted] = []
var _read_cache: Dictionary = {}
var _encoding_threads: Array[Thread] = []
var _background_busy: bool = false
var _race_status_cache: Dictionary = {}
var _run_waits: Dictionary = {}
var _run_wait_requests: Array[HTTPRequest] = []
var _capabilities: Dictionary = {}
var _server_sample: int = 0
var _server_sample_msec: int = 0
var _disable_gzip: bool = false
var _refresh_request_id: String = ""
var resume_recovery: Node
var session_vault: RefCounted = preload("res://backend/session_vault.gd").new()
var _idle_requests: Array[HTTPRequest] = []
var _ipv4_fallback: RefCounted = preload("res://backend/ipv4_fallback.gd").new()
var network_health: RefCounted = preload("res://backend/network_health.gd").new()
var _analytics_generation: int = 0
var analytics_opt_in: bool = true:
	set(value):
		if analytics_opt_in == value: return
		analytics_opt_in = value
		_analytics_generation += 1
		if not value: network_health.clear()
var _delete_request_id: String = ""
var _delete_access_token: String = ""
var _pending_network_context: Dictionary = {}
var safety: Node
var news: Node
var game_configuration: Node
var recording_cache_directory: String = "user://network-recordings"
var recording_cache_hits: int = 0
var recording_downloads: int = 0
var _read_flights: Dictionary = {}

func fetch_recording(path: String, authorized: bool = true, expected_run_id: String = "") -> Dictionary:
	return await load("res://backend/recording_downloads.gd").fetch(self,path,authorized,expected_run_id)

func _coalesced_read(path: String, authorized: bool) -> Dictionary:
	var generation: int = _session_generation
	var origin: String = _base_url
	var actor: String = str(player.get("id",""))
	var identity: String = origin+"/"+actor+"/"+str(generation)+"/"+str(authorized)+path
	if _read_flights.has(identity):
		var existing: Dictionary = _read_flights[identity]
		while not existing.done:
			await get_tree().process_frame
			if generation != _session_generation or origin != _base_url or actor != str(player.get("id","")): return _failure("ACCOUNT_CHANGED")
		if generation != _session_generation or origin != _base_url or actor != str(player.get("id","")): return _failure("ACCOUNT_CHANGED")
		return _checked(existing.response.duplicate(true),path,HTTPClient.METHOD_GET)
	if _read_flights.size() >= 64: return _failure("READ_BUSY",503)
	var pending: Dictionary = {"done":false,"response":{}}
	_read_flights[identity] = pending
	pending.response = await _authenticated_read(path) if authorized else _checked(await _send(path,HTTPClient.METHOD_GET,{},false),path,HTTPClient.METHOD_GET)
	pending.done = true
	_read_flights.erase(identity)
	if generation != _session_generation or origin != _base_url or actor != str(player.get("id","")): return _failure("ACCOUNT_CHANGED")
	return pending.response

func _vault_context() -> String:
	return "bmt-session-v1/"+_base_url+"/"+ProjectSettings.globalize_path(session_path)

func _write_saved_config(config: ConfigFile) -> Error:
	var sealed: String = session_vault.seal(config.encode_to_text(),_vault_context())
	if sealed.is_empty(): return ERR_UNAVAILABLE
	var temporary: String = session_path+".tmp"
	var file: Variant = FileAccess.open(temporary,FileAccess.WRITE)
	if file == null: return FileAccess.get_open_error()
	file.store_string(sealed)
	file.flush()
	var result: Error = file.get_error()
	file.close()
	return DirAccess.rename_absolute(temporary,session_path) if result == OK else result

func _load_saved_config(config: ConfigFile, migrate: bool = false) -> Error:
	var file: Variant = FileAccess.open(session_path,FileAccess.READ)
	if file == null: return FileAccess.get_open_error()
	if file.get_length() > 90000: return ERR_FILE_CORRUPT
	var text: String = file.get_as_text()
	file.close()
	var protected: bool = text.begins_with(load("res://backend/session_vault.gd").HEADER)
	if protected: text = session_vault.open(text,_vault_context())
	elif not session_vault.available(): return ERR_UNAVAILABLE
	if text.is_empty(): return ERR_FILE_CORRUPT
	var result: Error = config.parse(text)
	# Migration occurs under the same inter-process rotation lease, before
	# sending any refresh request. A failed vault write cannot consume a token.
	if result == OK and not protected and migrate:
		if str(config.get_value("session","url","")) != _base_url: return ERR_INVALID_DATA
		result = _write_saved_config(config)
	return result

func _take_request() -> HTTPRequest:
	var request: HTTPRequest
	if _idle_requests.is_empty():
		request = HTTPRequest.new()
		add_child(request)
	else: request = _idle_requests.pop_back()
	request.set_meta("cancelled",false)
	request.set_meta("owner_id",0)
	request.set_tls_options(TLSOptions.client())
	return request

func _release_request(request: HTTPRequest) -> void:
	if not is_instance_valid(request): return
	# Reuse bounded nodes after their completion callback has unwound. HTTPRequest
	# owns its own connection lifecycle; this saves nodes, not TLS handshakes.
	if _idle_requests.size() < 4: _idle_requests.append(request)
	else: request.queue_free()

func _profile_request(path: String, phase: String, start: int) -> void:
	if not OS.is_debug_build() or (OS.get_environment("BMT_RACE_LOAD_PROFILE") != "1" and not "--profile-race-load" in OS.get_cmdline_user_args()): return
	# Category only: never log account/track/ticket IDs, URLs, headers or bodies.
	var kind: String = "challenge_source" if path.get_slice("?",0) == "/challenges/sources" else "race_ticket" if _race_ticket_path(path) else "track_document" if path.ends_with("/document") else "score_upload" if path == "/runs" else "other"
	print("RACE_LOAD_REQUEST ",JSON.stringify({"kind":kind,"phase":phase,"ms":(Time.get_ticks_usec()-start)/1000.0}))

func _ready() -> void:
	news = load("res://backend/news_client.gd").new()
	news.client = self
	add_child(news)
	identity_changed.connect(news.identity_changed)
	news.identity_changed()
	safety = load("res://backend/community_safety.gd").new()
	safety.client = self
	add_child(safety)
	identity_changed.connect(safety.identity_changed)
	safety.identity_changed()
	safety.changed.connect(news.blocks_changed)
	resume_recovery = load("res://backend/resume_recovery.gd").new()
	resume_recovery.client = self
	add_child(resume_recovery)

func _exit_tree() -> void:
	cancel_run_waits()
	for thread: Thread in _encoding_threads:
		if thread.is_started(): thread.wait_to_finish()
	for lock: RefCounted in _rotation_locks: lock.release()
	_rotation_locks.clear()

func cancel_public_reads(owner_id: int) -> void:
	for request: HTTPRequest in _public_reads.duplicate():
		if is_instance_valid(request) and int(request.get_meta("owner_id",0)) == owner_id:
			request.cancel_request()
			request.set_meta("cancelled",true)
			request.request_completed.emit(HTTPRequest.RESULT_REQUEST_FAILED,0,PackedStringArray(),PackedByteArray())

func request_public(path: String, owner_id: int) -> Dictionary:
	return _checked(await _send(path,HTTPClient.METHOD_GET,{},false,"",PackedStringArray(),owner_id),path,HTTPClient.METHOD_GET)

func request_discovery(payload: Dictionary, owner_id: int, random_choice: bool = false) -> Dictionary:
	if int(_capabilities.get("discovery_paging_version",0)) < 3:
		return _failure("DISCOVERY_SERVER_UPDATE_REQUIRED",426)
	var path: String = "/discovery/v3/random" if random_choice else "/discovery/v3/tracks"
	if not payload.has("cursor") and not payload.has("query"): payload = {"query":payload.duplicate(true)}
	if signed_in() or payload.get("section",payload.get("query",{}).get("section","all")) == "saved": return await request_api(path,HTTPClient.METHOD_POST,payload,"",true)
	return _checked(await _send(path,HTTPClient.METHOD_POST,payload,false,"",PackedStringArray(),owner_id),path,HTTPClient.METHOD_POST)

func base_url() -> String:
	return _base_url

func auth_busy() -> bool:
	return _busy

func appearance_contract() -> String:
	return str(_capabilities.get("appearance_contract",""))

func telemetry_supported() -> bool:
	var capability: Variant = _capabilities.get("product_telemetry",{})
	return _delete_request_id.is_empty() and analytics_opt_in and bool(player.get("analytics_enabled",true)) and signed_in() and capability is Dictionary and bool(capability.get("enabled",false)) and int(capability.get("schema_version",0)) == 1

func game_configuration_supported() -> bool:
	return _delete_request_id.is_empty() and int(_capabilities.get("game_configuration_version",0)) == 1

func cancel_configuration() -> void:
	var epoch: int = _configuration_epoch
	_configuration_epoch += 1
	cancel_public_reads(-epoch)

func request_configuration(path: String, assign: bool = false) -> Dictionary:
	if not game_configuration_supported() or _busy or _refresh_busy: return _failure("CONFIGURATION_DEFERRED")
	if not (path.begins_with("/game-config") or (assign and path.begins_with("/experiments/assignments?"))): return _failure("INVALID_PATH")
	var epoch: int = _configuration_epoch
	var scope: String = _network_scope()
	var method: HTTPClient.Method = HTTPClient.METHOD_POST if assign else HTTPClient.METHOD_GET
	var response: Dictionary = await _send(path,method,{},signed_in(),"",PackedStringArray(),-epoch)
	if epoch != _configuration_epoch or scope != _network_scope(): return _failure("ACCOUNT_CHANGED")
	return response

func cancel_telemetry() -> void:
	_telemetry_epoch += 1
	for request: HTTPRequest in _telemetry_requests.duplicate():
		if not is_instance_valid(request): continue
		request.cancel_request()
		request.set_meta("cancelled",true)
		request.request_completed.emit(HTTPRequest.RESULT_REQUEST_FAILED,0,PackedStringArray(),PackedByteArray())

func quality_supported() -> bool:
	return quality_schema_version() > 0

func loss_counters_supported() -> bool:
	return telemetry_supported() and int(_capabilities.get("product_telemetry",{}).get("loss_counter_version",0)) == 2

func network_supported() -> bool:
	return telemetry_supported() and int(_capabilities.get("product_telemetry",{}).get("network_schema_version",0)) == 1

func shader_profiles_supported() -> bool:
	return telemetry_supported() and int(_capabilities.get("product_telemetry",{}).get("shader_profile_schema_version",0)) == 1

func _network_scope() -> String:
	return (_base_url+"/"+str(player.get("id",""))).sha256_text()

func note_upload_age(key: String, queued_server_at: int) -> void:
	if not network_supported(): return
	var current: int = server_now()
	var age: int = current-queued_server_at if queued_server_at > 0 and current >= queued_server_at else -1
	network_health.note_preparation(_network_scope(),key,0,age)

func note_request_preparation(key: String, usec: int) -> void:
	if network_supported(): network_health.note_preparation(_network_scope(),key,usec)

func quality_schema_version() -> int:
	if not telemetry_supported(): return 0
	var capability: Dictionary = _capabilities.get("product_telemetry",{})
	if capability.get("quality_schema_versions") is Array:
		for version: int in [3,2]:
			for supported: Variant in capability.quality_schema_versions:
				if _whole(supported,2,3) and int(supported) == version: return version
		return 0
	var version: int = int(capability.get("quality_schema_version",0))
	return version if telemetry_supported() and version in [2,3] else 0

func request_telemetry(payload: Dictionary) -> Dictionary:
	# Optional observations never reserve the mutation queue or rotate credentials.
	# Expired credentials retain the same durable events for a later normal sign-in.
	if not telemetry_supported() or _busy or _refresh_busy: return _failure("TELEMETRY_DEFERRED")
	var response: Dictionary = await _send("/telemetry/batches",HTTPClient.METHOD_POST,payload,true,"",PackedStringArray(),_telemetry_epoch)
	if int(response.get("status",0)) == 403 and response.get("error") == "ANALYTICS_DISABLED":
		player.analytics_enabled = false
		analytics_opt_in = false
		network_health.clear()
		identity_changed.emit()
	return response

static func refresh_retry_safe(response: Dictionary) -> bool:
	return bool(response.get("not_delivered",false)) or (bool(response.get("recoverable_refresh",false)) and (int(response.get("status",0)) in [0,429,500,502,503,504] or str(response.get("error","")) in ["INVALID_INPUT","INVALID_RESPONSE"])) or (int(response.get("status",0)) == 429 and str(response.get("error","")) == "RATE_LIMITED") or (int(response.get("status",0)) == 503 and str(response.get("error","")) == "REQUEST_VALIDATION_BUSY")

func configure(base_url: String) -> Error:
	if _busy: return ERR_BUSY
	_capabilities.clear()
	_server_sample = 0
	_disable_gzip = false
	var url: String = base_url.trim_suffix("/")
	if url.is_empty():
		clear_session()
		_base_url = ""
		return OK
	# Bearer credentials require TLS except explicit local development loopback.
	var loopback: bool = url.begins_with("http://127.0.0.1:") or url.begins_with("http://localhost:")
	if not (url.begins_with("https://") or loopback) or "@" in url or "?" in url or "#" in url or "\n" in url or "\r" in url:
		return ERR_INVALID_PARAMETER
	if not _base_url.is_empty(): clear_session()
	_base_url = url
	return OK

func clear_session(preserve_saved: bool = false) -> void:
	cancel_run_waits()
	cancel_telemetry()
	_session_generation += 1
	_read_cache.clear()
	_race_status_cache.clear()
	persistence_error = false
	if not preserve_saved and not session_path.is_empty() and (not _access_token.is_empty() or FileAccess.file_exists(session_path)):
		# A durable sign-out fence also protects restarts if an open file cannot
		# be removed on this platform. Only a later successful sign-in removes it.
		var fence: Variant = FileAccess.open(session_path+".signed_out",FileAccess.WRITE)
		if fence == null: persistence_error = true
		else:
			fence.store_string("signed_out")
			fence.flush()
			persistence_error = fence.get_error() != OK
			fence.close()
	if not preserve_saved: _forget_saved_session()
	_access_token = ""
	_refresh_token = ""
	_refresh_request_id = ""
	_delete_request_id = ""
	_delete_access_token = ""
	_login_id = ""
	player = {}
	identity_changed.emit()

func _forget_saved_session() -> void:
	if session_path.is_empty(): return
	for suffix: String in ["", ".tmp"]:
		if FileAccess.file_exists(session_path + suffix):
			if DirAccess.remove_absolute(session_path + suffix) != OK: persistence_error = true

func _save_session() -> void:
	if session_path.is_empty(): return
	if _login_id.is_empty(): _login_id = new_idempotency_key()
	var config: Variant = ConfigFile.new()
	config.set_value("session", "url", _base_url)
	config.set_value("session", "refresh_token", _refresh_token)
	# The same private file already holds the more powerful refresh credential.
	# Sharing its current access credential avoids rotation ping-pong between
	# game instances belonging to the same explicit login.
	config.set_value("session", "access_token", _access_token)
	config.set_value("session", "login_id", _login_id)
	config.set_value("session", "player_id", str(player.get("id","")))
	if not _refresh_request_id.is_empty(): config.set_value("session","refresh_request_id",_refresh_request_id)
	if not _delete_request_id.is_empty():
		config.set_value("session","delete_request_id",_delete_request_id)
		config.set_value("session","delete_access_token",_delete_access_token)
	persistence_error = _write_saved_config(config) != OK
	if not session_vault.available(): _forget_saved_session()
	if not persistence_error and FileAccess.file_exists(session_path+".signed_out"):
		persistence_error = DirAccess.remove_absolute(session_path+".signed_out") != OK
	# A failed replacement must preserve the previous durable recovery operation.

func has_saved_session() -> bool:
	return not session_path.is_empty() and not FileAccess.file_exists(session_path+".signed_out") and FileAccess.file_exists(session_path)

func discard_signed_out_session() -> void:
	if not session_path.is_empty() and FileAccess.file_exists(session_path+".signed_out"):
		_forget_saved_session()

func restore_session() -> Dictionary:
	if _busy: return _failure("BUSY")
	var config: Variant = ConfigFile.new()
	if not has_saved_session() or _load_saved_config(config) != OK:
		_forget_saved_session()
		return _failure("SIGN_IN_REQUIRED")
	if str(config.get_value("session", "url", "")) != _base_url:
		clear_session()
		return _failure("SIGN_IN_REQUIRED")
	_delete_request_id = str(config.get_value("session","delete_request_id",""))
	_delete_access_token = str(config.get_value("session","delete_access_token",""))
	if not _delete_request_id.is_empty() and not _delete_access_token.is_empty():
		_access_token = _delete_access_token
		_refresh_token = str(config.get_value("session","refresh_token",""))
		_login_id = _stored_login_id(config)
		player = {"id":str(config.get_value("session","player_id",""))}
		return await delete_account()
	var token: String = str(config.get_value("session", "refresh_token", ""))
	if token.is_empty():
		clear_session()
		return _failure("SIGN_IN_REQUIRED")
	_busy = true
	# Retain credentials only when transport proves the request was never delivered.
	var generation: int = _session_generation
	_refresh_token = token
	_login_id = _stored_login_id(config)
	var response: Dictionary = await _renew_session(generation)
	if generation != _session_generation:
		_busy = false
		return _failure("ACCOUNT_CHANGED")
	if not response.ok and not refresh_retry_safe(response): clear_session()
	_busy = false
	return response

static func _stored_login_id(config: ConfigFile) -> String:
	# Existing saves gain this metadata after their first successful rotation.
	return str(config.get_value("session","login_id","legacy-"+str(config.get_value("session","refresh_token","")).sha256_text()))

func deletion_supported() -> bool:
	return int(_capabilities.get("privacy",{}).get("schema_version",0)) == 1

func delete_account() -> Dictionary:
	if not signed_in() or not deletion_supported(): return _failure("DELETION_UNAVAILABLE")
	if _delete_request_id.is_empty():
		var checked: Dictionary = await request_api("/me",HTTPClient.METHOD_GET,{},"",true)
		if not checked.ok: return checked
		if str(checked.data.get("id","")) != str(player.get("id","")): return _failure("ACCOUNT_CHANGED")
	var generation: int = _session_generation
	while _busy or _refresh_busy:
		await get_tree().process_frame
		if generation != _session_generation: return _failure("ACCOUNT_CHANGED")
	_busy = true
	var lock: Variant = load("res://backend/session_rotation_lock.gd").new(session_path)
	_rotation_locks.append(lock)
	var acquired: Error = await lock.acquire(get_tree())
	if acquired != OK:
		_rotation_locks.erase(lock)
		_busy = false
		return _failure("SESSION_ROTATION_BUSY")
	if generation != _session_generation:
		_release_account_lock(lock)
		_busy = false
		return _failure("ACCOUNT_CHANGED")
	if has_saved_session():
		var saved: Variant = ConfigFile.new()
		if _load_saved_config(saved,true) != OK or _stored_login_id(saved) != _login_id or str(saved.get_value("session","player_id","")) != str(player.get("id","")):
			_release_account_lock(lock)
			_busy = false
			clear_session(true)
			return _failure("ACCOUNT_CHANGED")
		if _delete_request_id.is_empty():
			_access_token = str(saved.get_value("session","access_token",_access_token))
			_refresh_token = str(saved.get_value("session","refresh_token",_refresh_token))
	if _delete_request_id.is_empty():
		_delete_request_id = load("res://backend/product_telemetry.gd").uuid()
		_delete_access_token = _access_token
	if not session_path.is_empty() and session_vault.available():
		_save_session()
		if persistence_error:
			_release_account_lock(lock)
			_busy = false
			return _failure("SESSION_STORAGE_ERROR")
	var owner: String = str(player.get("id",""))
	var origin: String = _base_url
	var response: Dictionary = _checked(await _send("/privacy/account-deletion",HTTPClient.METHOD_POST,
		{"request_id":_delete_request_id,"confirmation":"DELETE"},false,_delete_request_id,
		PackedStringArray(["Authorization: Bearer "+_delete_access_token])),"/privacy/account-deletion",HTTPClient.METHOD_POST)
	if int(response.get("status",0)) == 401 and not _refresh_token.is_empty() and generation == _session_generation:
		# A 401 proves this credential has no deletion receipt. The original
		# operation may never have reached the server before access expiry.
		var renewed: Dictionary = await _renew_locked(generation,"",HTTPClient.METHOD_GET,{},"",_access_token)
		if renewed.ok and generation == _session_generation:
			_delete_access_token = _access_token
			if not session_path.is_empty() and session_vault.available(): _save_session()
			if not persistence_error:
				response = _checked(await _send("/privacy/account-deletion",HTTPClient.METHOD_POST,
					{"request_id":_delete_request_id,"confirmation":"DELETE"},false,_delete_request_id,
					PackedStringArray(["Authorization: Bearer "+_delete_access_token])),"/privacy/account-deletion",HTTPClient.METHOD_POST)
	_release_account_lock(lock)
	_busy = false
	if generation != _session_generation or origin != _base_url: return _failure("ACCOUNT_CHANGED")
	if response.ok:
		if str(response.data.get("player_id","")) != owner: return _failure("INVALID_RESPONSE",502)
		var preserve_saved: bool = false
		if has_saved_session():
			var saved: Variant = ConfigFile.new()
			preserve_saved = _load_saved_config(saved) != OK or _stored_login_id(saved) != _login_id
		network_health.erase_scope((origin+"/"+owner).sha256_text())
		response.removed_player_id = owner
		response.removed_origin = origin
		response.account_removed = true
		clear_session(preserve_saved)
	return response

func _release_account_lock(lock: RefCounted) -> void:
	lock.release()
	_rotation_locks.erase(lock)

func _renew_session(generation: int, path: String = "", method: HTTPClient.Method = HTTPClient.METHOD_GET, payload: Dictionary = {}, key: String = "", used_access: String = "", network_context: Dictionary = {}) -> Dictionary:
	# Serialize credentials independently from durable application mutations.
	# This also covers standalone clients without a persisted rotation lock.
	var began: int = Time.get_ticks_msec()
	while _refresh_busy:
		if generation != _session_generation: return _failure("ACCOUNT_CHANGED")
		# Renewal may already be complete while its owner's original read is
		# still being retried under the rotation lock. Race authorization and
		# challenge-time lookup can use that credential without waiting for an
		# unrelated response or releasing either lock. Keep the exact request.
		if _independent_auth_request(path,method) and not _access_token.is_empty() and _access_token != used_access:
			var ticket: Dictionary = _checked(await _send(path,method,payload,true,key),path,method)
			return ticket if generation == _session_generation else _failure("ACCOUNT_CHANGED")
		if Time.get_ticks_msec()-began >= 35000:
			var waiting: Dictionary = _failure("SESSION_ROTATION_BUSY")
			waiting.not_delivered = true
			return waiting
		await get_tree().process_frame
	if generation != _session_generation: return _failure("ACCOUNT_CHANGED")
	_refresh_busy = true
	var lock: Variant = load("res://backend/session_rotation_lock.gd").new(session_path)
	_rotation_locks.append(lock)
	var acquired: Error = await lock.acquire(get_tree())
	if acquired != OK:
		_rotation_locks.erase(lock)
		_refresh_busy = false
		var failed: Dictionary = _failure("SESSION_ROTATION_BUSY")
		failed.not_delivered = true
		return failed
	if not network_context.is_empty(): network_context.queue_us = int(network_context.get("queue_us",0))+maxi(0,Time.get_ticks_msec()-began)*1000
	var response: Dictionary = await _renew_locked(generation,path,method,payload,key,used_access,network_context)
	lock.release()
	_rotation_locks.erase(lock)
	_refresh_busy = false
	return response

func _renew_locked(generation: int, path: String, method: HTTPClient.Method, payload: Dictionary, key: String, used_access: String, network_context: Dictionary = {}) -> Dictionary:
	if generation != _session_generation: return _failure("ACCOUNT_CHANGED")
	if not path.is_empty() and _access_token != used_access:
		# An earlier request in this client already renewed while we waited.
		var retried: Dictionary = _checked(await _send_context(path,method,payload,true,key,network_context),path,method)
		if generation != _session_generation: return _failure("ACCOUNT_CHANGED")
		if int(retried.status) != 401: return retried
	var expected_player: String = str(player.get("id",""))
	var config: Variant = ConfigFile.new()
	if not session_path.is_empty() and session_vault.available():
		if not has_saved_session() or _load_saved_config(config,true) != OK:
			if FileAccess.file_exists(session_path+".signed_out"):
				clear_session(true)
				return _failure("ACCOUNT_CHANGED")
			var failed: Dictionary = _failure("SESSION_STORAGE_ERROR")
			failed.not_delivered = true
			return failed
		var saved_player: String = str(config.get_value("session","player_id",""))
		if str(config.get_value("session","url","")) != _base_url or _stored_login_id(config) != _login_id or (not expected_player.is_empty() and not saved_player.is_empty() and expected_player != saved_player):
			# Another explicit sign-in is a different session, even for the same
			# player. Leave that saved session intact; never silently adopt it.
			clear_session(true)
			return _failure("ACCOUNT_CHANGED")
		_refresh_token = str(config.get_value("session","refresh_token",""))
		_refresh_request_id = str(config.get_value("session","refresh_request_id",""))
		if expected_player.is_empty(): expected_player = saved_player
		var saved_access: String = str(config.get_value("session","access_token",""))
		if not path.is_empty() and not saved_access.is_empty() and saved_access != _access_token and _refresh_request_id.is_empty():
			_access_token = saved_access
			var reused: Dictionary = _checked(await _send_context(path,method,payload,true,key,network_context),path,method)
			if generation != _session_generation: return _failure("ACCOUNT_CHANGED")
			# A concurrent explicit login/sign-out still fences this request, even
			# when the already issued access credential was accepted by the server.
			var latest: Variant = ConfigFile.new()
			if not has_saved_session() or _load_saved_config(latest) != OK or _stored_login_id(latest) != _login_id:
				clear_session(true)
				return _failure("ACCOUNT_CHANGED")
			if int(reused.status) != 401: return reused
	var supports_recovery: bool = not _refresh_request_id.is_empty() or int(_capabilities.get("refresh_recovery_seconds",0)) > 0
	var body: Dictionary = {"refresh_token":_refresh_token}
	if supports_recovery:
		if _refresh_request_id.is_empty(): _refresh_request_id = Crypto.new().generate_random_bytes(24).hex_encode()
		body.refresh_request_id = _refresh_request_id
		if not session_path.is_empty() and session_vault.available():
			config.set_value("session","refresh_request_id",_refresh_request_id)
			if _write_saved_config(config) != OK:
				var failure: Dictionary = _failure("SESSION_STORAGE_ERROR")
				failure.not_delivered = true
				return failure
	var refresh: Dictionary = _checked(await _send("/auth/refresh",HTTPClient.METHOD_POST,body,false),"/auth/refresh",HTTPClient.METHOD_POST)
	if supports_recovery and not refresh.ok: refresh.recoverable_refresh = true
	if generation != _session_generation: return _failure("ACCOUNT_CHANGED")
	if not session_path.is_empty() and session_vault.available():
		var current: Variant = ConfigFile.new()
		if not has_saved_session() or _load_saved_config(current) != OK or _stored_login_id(current) != _login_id:
			clear_session(true)
			return _failure("ACCOUNT_CHANGED")
	var returned_player: Variant = refresh.data.get("player",{})
	if refresh.ok and returned_player is Dictionary and not expected_player.is_empty() and str(returned_player.get("id","")) != expected_player:
		clear_session(true)
		return _failure("ACCOUNT_CHANGED")
	refresh = _remember(refresh,generation)
	if not refresh.ok:
		refresh.refresh_failed = true
		return refresh
	if path.is_empty(): return refresh
	# Keep the shared lock through this retry: another process cannot consume
	# the new access credential before the server accepts the original request.
	var response: Dictionary = _checked(await _send_context(path,method,payload,true,key,network_context),path,method)
	if generation != _session_generation: return _failure("ACCOUNT_CHANGED")
	return response

func signed_in() -> bool:
	return not _access_token.is_empty()

static func new_idempotency_key(unix_time: int = 0) -> String:
	var random: String = Crypto.new().generate_random_bytes(24).hex_encode()
	return "v2."+str(unix_time)+"."+random if unix_time > 0 else "op."+random

func server_now() -> int:
	return _server_sample+maxi(0,Time.get_ticks_msec()-_server_sample_msec)/1000 if _server_sample > 0 else 0

func test_drivers_available() -> bool:
	return OS.is_debug_build() and signed_in() and bool(_capabilities.get("test_drivers",false))

func new_operation_key() -> String:
	return new_idempotency_key(server_now())

func _sample_time(unix_time: int) -> void:
	if unix_time < 1000000000 or unix_time > 9999999999: return
	_server_sample = unix_time
	_server_sample_msec = Time.get_ticks_msec()

func _failure(code: String, status: int = 0) -> Dictionary:
	return {"ok":false,"status":status,"error":code,"data":{}}

static func _encode_request(payload: Dictionary, allow_compression: bool = true) -> Dictionary:
	var body: PackedByteArray = JSON.stringify(payload).to_utf8_buffer()
	if body.size() > MAX_RESPONSE_BYTES: return {"too_large":true}
	if body.size() < 1024 or not allow_compression: return {"body":body,"compressed":false}
	var compressed: PackedByteArray = body.compress(FileAccess.COMPRESSION_GZIP)
	return {"body":compressed if compressed.size() < body.size() else body,"compressed":compressed.size() < body.size()}

static func _decode_response(bytes: PackedByteArray, cacheable: bool = false) -> Dictionary:
	var body: String = bytes.get_string_from_utf8()
	var parser: Variant = JSON.new()
	var parsed: Variant = parser.data if parser.parse(body) == OK else null
	return {"parsed":parsed,"body":body,"cache_data":parsed.duplicate(true) if cacheable and parsed is Dictionary else {}}

func remember_run(value: Dictionary, allow_restart: bool = false) -> void:
	if not value.has_all(["ticket_id","status"]): return
	var previous: Dictionary = _race_status_cache.get(str(value.ticket_id),{}).get("data",{})
	if not allow_restart and value.status in ["queued","verifying"] and previous.get("status") in ["verified","skipped","rejected","failed"] and not str(value.get("run_id","")).is_empty() and value.get("run_id") == previous.get("run_id"): return
	_race_status_cache[str(value.ticket_id)] = {"data":value,"at":Time.get_ticks_msec()}
	while _race_status_cache.size() > 32: _race_status_cache.erase(_race_status_cache.keys()[0])

func run_read_path(path: String) -> String:
	return path+("&" if path.contains("?") else "?")+"completion=true" if int(_capabilities.get("run_completion_version",0)) == 1 else path

func recent_completion(ticket_id: String) -> Dictionary:
	var recent: Dictionary = recent_run(ticket_id)
	if recent.get("status") not in ["verified","skipped","rejected","failed"]: return {}
	var value: Variant = recent.get("completion")
	return value if value is Dictionary and value.get("version") == 1 else {}

func invalidate_challenge_completions() -> void:
	for entry: Dictionary in _race_status_cache.values():
		var value: Variant = entry.get("data",{}).get("completion")
		if value is Dictionary: value.erase("challenge_result")

static func valid_completion_reward(value: Variant) -> bool:
	if not value is Dictionary or value.get("status") not in ["credited","unavailable"] or not _whole(value.get("amount"),0,2147483647) or not value.get("rows") is Array or value.rows.size() > 32: return false
	var total: int = 0
	for row: Variant in value.rows:
		if not row is Dictionary or not _text(row.get("title")) or not _text(row.get("icon")) or not _whole(row.get("amount"),0,2147483647) or not row.get("eligible") is bool or not _text(row.get("status")): return false
		total += int(row.amount)
	return total == int(value.amount) and (value.status == "credited" or (value.rows.is_empty() and total == 0))

func recent_run(ticket_id: String) -> Dictionary:
	var cached: Dictionary = _race_status_cache.get(ticket_id,{})
	var duration: int = 250 if cached.get("data",{}).get("status","") in ["queued","verifying"] else 3000
	return cached.get("data",{}) if Time.get_ticks_msec()-int(cached.get("at",-10000)) < duration else {}

func run_wait_pending(ticket_id: String) -> bool:
	for pending: Dictionary in _run_waits.values():
		if str(pending.ticket) == ticket_id and not pending.done: return true
	return false

func cancel_run_waits() -> void:
	_run_waits.clear()
	for request: HTTPRequest in _run_wait_requests.duplicate():
		if is_instance_valid(request):
			request.cancel_request()
			request.set_meta("cancelled",true)
			request.request_completed.emit(HTTPRequest.RESULT_REQUEST_FAILED,0,PackedStringArray(),PackedByteArray())

func wait_for_run(run_id: String, ticket_id: String) -> Dictionary:
	var wait_ms: int = clampi(int(_capabilities.get("run_wait_ms",0)),0,2000)
	if wait_ms == 0 or not signed_in(): return _failure("WAIT_UNAVAILABLE")
	var generation: int = _session_generation
	var origin: String = _base_url
	var owner: String = str(player.get("id",""))
	var identity: String = origin+"/"+owner+"/"+str(generation)+"/"+run_id
	if _run_waits.has(identity):
		var existing: Dictionary = _run_waits[identity]
		while not existing.done: await get_tree().process_frame
		return existing.response
	if not _run_waits.is_empty(): return _failure("WAIT_BUSY")
	var pending: Dictionary = {"ticket":ticket_id,"done":false,"response":{}}
	_run_waits[identity] = pending
	var deadline: int = Time.get_ticks_msec()+8000
	var response: Dictionary = _failure("WAIT_EXPIRED")
	# Keep one foreground waiter across a few server-sized windows. A cold
	# verification just beyond the first window must not wait for the outbox's
	# slower retry timer. Requests stay serial, shared and bounded.
	for attempt: int in range(4):
		var cached: Dictionary = recent_run(ticket_id)
		if valid_run(cached) and str(cached.run_id) == run_id and cached.status in ["verified","skipped","rejected","failed"]:
			response = {"ok":true,"status":200,"error":"","data":cached}
			break
		var remaining: int = deadline-Time.get_ticks_msec()
		if remaining <= 0: break
		var window: int = mini(wait_ms,remaining)
		var started: int = Time.get_ticks_msec()
		response = await request_api(run_read_path("/runs/"+run_id.uri_encode()+"/wait?timeout_ms="+str(window)),HTTPClient.METHOD_GET,{},"",true)
		if generation != _session_generation or origin != _base_url or owner != str(player.get("id","")): break
		if not response.ok or not valid_run(response.data): break
		if str(response.data.get("run_id","")) != run_id or str(response.data.get("ticket_id","")) != ticket_id: break
		if response.data.status not in ["queued","verifying"]: break
		# Capacity limits or an unavailable listener can return pending at once.
		# Let ordinary polling back off instead of repeatedly hitting that path.
		if Time.get_ticks_msec()-started < maxi(1,window/2): break
	if generation != _session_generation or origin != _base_url or owner != str(player.get("id","")):
		response = _failure("ACCOUNT_CHANGED")
	elif response.ok:
		if not valid_run(response.data) or str(response.data.get("run_id","")) != run_id or str(response.data.get("ticket_id","")) != ticket_id:
			response = _failure("INVALID_RESPONSE",502)
		else:
			remember_run(response.data)
	elif int(response.get("status",0)) in [404,405,501]:
		_capabilities["run_wait_ms"] = 0
	pending.response = response
	pending.done = true
	_run_waits.erase(identity)
	if response.ok and response.data.status in ["verified","skipped","rejected","failed"]: run_completed.emit()
	return response

func _background(work: Callable) -> Variant:
	# Bound JSON, trajectory and compression work across saving and uploading.
	# Wait on frames rather than creating competing large encoder threads.
	while _background_busy: await get_tree().process_frame
	_background_busy = true
	var thread: Variant = Thread.new()
	if thread.start(work) != OK:
		_background_busy = false
		return null
	_encoding_threads.append(thread)
	while thread.is_alive(): await get_tree().process_frame
	_encoding_threads.erase(thread)
	var result: Variant = thread.wait_to_finish()
	_background_busy = false
	return result

func _network_context_key(path: String, method: int, key: String) -> String:
	return JSON.stringify([_session_generation,path,method,key]).sha256_text()

func _send_context(path: String, method: HTTPClient.Method, payload: Dictionary, authorized: bool, key: String, context: Dictionary) -> Dictionary:
	# _send consumes this small context before its first await. Preserve the
	# established transport signature and isolated test/platform overrides.
	var identity: String = _network_context_key(path,method,key)
	_pending_network_context[identity] = context
	while _pending_network_context.size() > 256: _pending_network_context.erase(_pending_network_context.keys()[0])
	var response: Dictionary = await _send(path,method,payload,authorized,key)
	if _pending_network_context.has(identity) and is_same(_pending_network_context[identity],context): _pending_network_context.erase(identity)
	return response

func _send(path: String, method: HTTPClient.Method, payload: Dictionary, authorized: bool, idempotency_key: String = "", extra_headers: PackedStringArray = [], owner_id: int = 0) -> Dictionary:
	var identity: String = _network_context_key(path,method,idempotency_key)
	var network_context: Dictionary = _pending_network_context.get(identity,{})
	_pending_network_context.erase(identity)
	var monitor = load("res://backend/network_health.gd")
	var category: String = monitor.category(path)
	var collect: bool = network_supported() and not str(player.get("id","")).is_empty() and not category.is_empty()
	var scope: String = _network_scope()
	var generation: int = _session_generation
	var context: Dictionary = network_context if not network_context.is_empty() else {"attempt":0,"queue_us":0}
	var analytics_generation: int = _analytics_generation
	var attempt: int = int(context.get("attempt",0)); context.attempt = attempt+1
	var metrics: Dictionary = {"collect":collect,"request_id":"","http_status":0}
	if collect:
		metrics.merge(network_health.begin(scope,idempotency_key,attempt))
		metrics.queue_ms = clampi(int(context.get("queue_us",0))/1000,0,monitor.MAX_MS)
	context.queue_us = 0
	var started: int = Time.get_ticks_usec()
	var response: Dictionary = await _send_transport(path,method,payload,authorized,idempotency_key,extra_headers,owner_id,metrics)
	if not str(metrics.request_id).is_empty(): response.request_id = metrics.request_id
	if collect and analytics_generation == _analytics_generation and network_supported() and generation == _session_generation and scope == _network_scope():
		metrics.encode_ms = clampi((int(metrics.get("encode_us",0))+int(metrics.extra_encode_us))/1000,0,monitor.MAX_MS)
		metrics.total_ms = clampi((Time.get_ticks_usec()-started+int(metrics.extra_encode_us))/1000+int(metrics.queue_ms),0,monitor.MAX_MS)
		network_health.record(scope,category,monitor.method_name(method),response,metrics)
	return response

func _send_transport(path: String, method: HTTPClient.Method, payload: Dictionary, authorized: bool, idempotency_key: String, extra_headers: PackedStringArray, owner_id: int, metrics: Dictionary) -> Dictionary:
	if _base_url.is_empty(): return _failure("NOT_CONFIGURED")
	if not path.begins_with("/") or path.begins_with("//") or "\n" in path or "\r" in path: return _failure("INVALID_PATH")
	if authorized and _access_token.is_empty(): return _failure("SIGN_IN_REQUIRED")
	var headers: Variant = PackedStringArray(["Accept: application/json","Content-Type: application/json"])
	if authorized: headers.append("Authorization: Bearer "+_access_token)
	if not idempotency_key.is_empty():
		if idempotency_key.length() > 128 or "\n" in idempotency_key or "\r" in idempotency_key: return _failure("INVALID_IDEMPOTENCY_KEY")
		headers.append("Idempotency-Key: "+idempotency_key)
	headers.append_array(extra_headers)
	var cache_key: String = _base_url+"/"+str(_session_generation)+path
	if method == HTTPClient.METHOD_GET and _read_cache.has(cache_key): headers.append("If-None-Match: "+str(_read_cache[cache_key].tag))
	var origin: String = _base_url
	var generation: int = _session_generation
	var profile_start: int = Time.get_ticks_usec()
	var packet: Variant = {"body":PackedByteArray(),"compressed":false} if method == HTTPClient.METHOD_GET else await _background(_encode_request.bind(payload,not _disable_gzip and "gzip" in _capabilities.get("upload_encodings",[])))
	_profile_request(path,"encode",profile_start)
	if metrics.collect: metrics.encode_us = Time.get_ticks_usec()-profile_start
	if not packet is Dictionary: return _failure("REQUEST_ENCODING_FAILED")
	if packet.get("too_large",false): return _failure("REQUEST_TOO_LARGE",413)
	if origin != _base_url or (authorized and generation != _session_generation): return _failure("ACCOUNT_CHANGED")
	# A menu request may finish encoding after the player starts loading a race.
	# Its owner cancellation fence prevents starting network work after that point.
	if path == "/telemetry/batches" and owner_id != 0 and owner_id != _telemetry_epoch: return _failure("CANCELLED")
	if owner_id < 0 and -owner_id != _configuration_epoch: return _failure("CANCELLED")
	if packet.compressed: headers.append("Content-Encoding: gzip")
	if metrics.collect: metrics.request_body_bytes = packet.body.size()
	var request: HTTPRequest = _take_request()
	request.use_threads = true
	var run_wait: bool = path.begins_with("/runs/") and path.get_slice("?",0).ends_with("/wait")
	request.timeout = 5.0 if run_wait else 10.0 if path == "/telemetry/batches" else 2.0 if "/ghosts/" in path else 30.0
	request.body_size_limit = 16384 if path == "/telemetry/batches" else MAX_RESPONSE_BYTES
	if owner_id < 0:
		request.timeout = 3.0
		request.body_size_limit = 65536
	request.max_redirects = 0 # Never forward credentials to a redirect target.
	profile_start = Time.get_ticks_usec()
	if owner_id != 0 and (method == HTTPClient.METHOD_GET or path.begins_with("/discovery/") or owner_id < 0):
		request.set_meta("owner_id",owner_id)
		_public_reads.append(request)
	if path == "/telemetry/batches": _telemetry_requests.append(request)
	if run_wait: _run_wait_requests.append(request)
	var route: Dictionary = await _ipv4_fallback.route(origin, get_tree())
	var stale: bool = origin != _base_url or (authorized and generation != _session_generation)
	if bool(request.get_meta("cancelled",false)) or stale:
		_public_reads.erase(request)
		_telemetry_requests.erase(request)
		_run_wait_requests.erase(request)
		_release_request.call_deferred(request)
		return _failure("CANCELLED" if not stale else "ACCOUNT_CHANGED")
	var request_origin: String = origin
	if not route.is_empty():
		request_origin = route.url
		# The IP selects routing only: SNI/certificate identity and Host stay original.
		request.set_tls_options(TLSOptions.client(null, route.host))
		headers.append("Host: " + str(route.authority))
	var start: Error = request.request_raw(request_origin+"/v1"+path,headers,method,packet.body)
	if start != OK:
		_public_reads.erase(request)
		_telemetry_requests.erase(request)
		_run_wait_requests.erase(request)
		_release_request.call_deferred(request)
		var failed: Dictionary = _failure("REQUEST_START_FAILED")
		failed.not_delivered = true
		return failed
	var completed: Array = await request.request_completed
	_profile_request(path,"http",profile_start)
	if metrics.collect:
		metrics.http_ms = clampi((Time.get_ticks_usec()-profile_start)/1000,0,load("res://backend/network_health.gd").MAX_MS)
		# HTTPRequest's counter is before automatic gzip/deflate decompression.
		metrics.response_body_bytes = request.get_downloaded_bytes()
	metrics.request_id = load("res://backend/network_health.gd").request_id(completed[2])
	metrics.http_status = int(completed[1])
	_public_reads.erase(request)
	_telemetry_requests.erase(request)
	_run_wait_requests.erase(request)
	var cancelled: bool = bool(request.get_meta("cancelled",false))
	_release_request.call_deferred(request)
	if cancelled or origin != _base_url: return _failure("CANCELLED")
	if int(completed[0]) != HTTPRequest.RESULT_SUCCESS:
		var failed: Dictionary = _failure("NETWORK_ERROR")
		failed.transport_result = int(completed[0])
		failed.not_delivered = int(completed[0]) in [HTTPRequest.RESULT_CANT_RESOLVE,HTTPRequest.RESULT_CANT_CONNECT,HTTPRequest.RESULT_TLS_HANDSHAKE_ERROR]
		return failed
	var status: int = int(completed[1])
	var tag: String = ""
	var server_time: int = 0
	for header: String in completed[2]:
		if header.to_lower().begins_with("etag:"): tag = header.substr(5).strip_edges()
		elif header.to_lower().begins_with("x-server-time:"): server_time = int(header.get_slice(":",1).strip_edges())
	if server_time > 0: _sample_time(server_time)
	if status == 304 and _read_cache.has(cache_key):
		var cached: Dictionary = _read_cache[cache_key].data.duplicate(true)
		if server_time > 0 and cached.has("server_now"):
			cached.server_now = server_time
			if cached.has("ends_at"): cached.remaining_seconds = maxi(0,int(cached.ends_at)-server_time)
			if path.begins_with("/game-config"): cached.expires_at = server_time+7*86400
		return {"ok":true,"status":200,"data":cached,"body":str(_read_cache[cache_key].get("body","")),"error":"","not_modified":true}
	var bytes: PackedByteArray = completed[3]
	var cacheable: bool = method == HTTPClient.METHOD_GET and status == 200 and not tag.is_empty() and bytes.size() <= 524288
	profile_start = Time.get_ticks_usec()
	var decoded: Variant
	if bytes.is_empty(): decoded = {"parsed":{},"body":"","cache_data":{}}
	elif bytes.size() <= INLINE_RESPONSE_BYTES: decoded = _decode_response(bytes,cacheable)
	else: decoded = await _background(_decode_response.bind(bytes,cacheable))
	_profile_request(path,"decode",profile_start)
	if metrics.collect: metrics.decode_ms = clampi((Time.get_ticks_usec()-profile_start)/1000,0,load("res://backend/network_health.gd").MAX_MS)
	if not decoded is Dictionary: return _failure("INVALID_RESPONSE",status)
	var parsed: Variant = decoded.parsed
	if str(metrics.request_id).is_empty() and parsed is Dictionary and parsed.get("request_id") is String:
		metrics.request_id = load("res://backend/network_health.gd").request_id(PackedStringArray(["X-Request-Id: "+str(parsed.request_id)]))
	if origin != _base_url: return _failure("CANCELLED")
	if authorized and generation != _session_generation: return _failure("ACCOUNT_CHANGED")
	if not parsed is Dictionary: return _failure("INVALID_RESPONSE",status)
	if status >= 200 and status < 300 and not valid_response(path,method,parsed): return _failure("INVALID_RESPONSE",502)
	if path == "/bootstrap" and _whole(parsed.get("server_now",0)): _sample_time(int(parsed.get("server_now",0)))
	if path == "/bootstrap" and status == 200: _capabilities = parsed.duplicate(true)
	if authorized and generation == _session_generation and status >= 200 and status < 300:
		if parsed.has("ticket_id") and parsed.has("status") and not run_wait:
			var restart: bool = method == HTTPClient.METHOD_POST and path.get_slice("?",0) == "/runs/"+str(parsed.get("run_id",""))+"/retry"
			remember_run(parsed,restart)
		if path.begins_with("/runs/status"):
			for item: Dictionary in parsed.get("items",[]):
				if item.get("completion") is Dictionary and parsed.get("completion_wallet") is Dictionary:
					item.completion.wallet = parsed.completion_wallet
				remember_run(item)
	if method == HTTPClient.METHOD_GET and status == 200 and not tag.is_empty() and bytes.size() <= 524288 and origin == _base_url and generation == _session_generation:
		_read_cache.erase(cache_key)
		_read_cache[cache_key] = {"tag":tag,"data":decoded.cache_data,"body":decoded.body,"bytes":bytes.size()}
		while _read_cache.size() > 16: _read_cache.erase(_read_cache.keys()[0])
		var cache_bytes: int = 0
		for entry: Dictionary in _read_cache.values(): cache_bytes += int(entry.bytes)
		while cache_bytes > 2097152:
			var oldest: String = str(_read_cache.keys()[0])
			cache_bytes -= int(_read_cache[oldest].bytes)
			_read_cache.erase(oldest)
	var retry_after: int = _retry_after(completed[2],server_now() if _server_sample > 0 else -1)
	return {"ok":status >= 200 and status < 300,"status":status,"data":parsed,"body":decoded.body,"retry_after":retry_after,"error":"" if status >= 200 and status < 300 else str(parsed.get("detail","HTTP_ERROR"))}

static func _retry_after(headers: PackedStringArray, reference_unix: int = -1) -> int:
	var reference: int = reference_unix if reference_unix >= 0 else int(Time.get_unix_time_from_system())
	if reference_unix < 0:
		for header: String in headers:
			if header.to_lower().begins_with("date:"):
				var server_date: int = _http_date(header.substr(5).strip_edges(),reference)
				if server_date >= 0: reference = server_date
	for header: String in headers:
		if header.to_lower().begins_with("retry-after:"):
			var value: String = header.substr(header.find(":")+1).strip_edges()
			if value.length() <= 10 and value.is_valid_int() and not value.begins_with("-") and not value.begins_with("+"): return clampi(int(value),0,3600)
			var date: int = _http_date(value,reference)
			if date >= 0: return clampi(date-reference,0,3600)
	return 0

static func _http_date(value: String, reference: int) -> int:
	# HTTP recipients accept IMF-fixdate and both obsolete HTTP-date forms.
	if value.length() > 80: return -1
	var patterns: Array[String] = [
		"^(Mon|Tue|Wed|Thu|Fri|Sat|Sun), ([0-9]{2}) ([A-Z][a-z]{2}) ([0-9]{4}) ([0-9]{2}):([0-9]{2}):([0-9]{2}) GMT$",
		"^(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday), ([0-9]{2})-([A-Z][a-z]{2})-([0-9]{2}) ([0-9]{2}):([0-9]{2}):([0-9]{2}) GMT$",
		"^(Mon|Tue|Wed|Thu|Fri|Sat|Sun) ([A-Z][a-z]{2}) +([0-9]{1,2}) ([0-9]{2}):([0-9]{2}):([0-9]{2}) ([0-9]{4})$"]
	var months: Array[String] = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
	for index: int in range(patterns.size()):
		var match_value: RegExMatch = RegEx.create_from_string(patterns[index]).search(value)
		if match_value == null: continue
		var year: int = int(match_value.get_string(7 if index == 2 else 4))
		if index == 1:
			var current_year: int = Time.get_datetime_dict_from_unix_time(reference).year
			year += ((current_year+50)/100)*100
			if year > current_year+50: year -= 100
		var month: int = months.find(match_value.get_string(2 if index == 2 else 3))+1
		var date: Dictionary = {"year":year,"month":month,"day":int(match_value.get_string(3 if index == 2 else 2)),"hour":int(match_value.get_string(4 if index == 2 else 5)),"minute":int(match_value.get_string(5 if index == 2 else 6)),"second":int(match_value.get_string(6 if index == 2 else 7))}
		if index == 1:
			var reference_date: Dictionary = Time.get_datetime_dict_from_unix_time(reference)
			if int(date.year) == int(reference_date.year)+50:
				for field: String in ["month","day","hour","minute","second"]:
					if int(date[field]) > int(reference_date[field]): date.year -= 100; break
					if int(date[field]) < int(reference_date[field]): break
				year = int(date.year)
		if year < 1970 or year > 9999 or month == 0 or date.day < 1 or date.day > 31 or date.hour > 23 or date.minute > 59 or date.second > 59: return -1
		var days: Array[int] = [31,29 if year%4 == 0 and (year%100 != 0 or year%400 == 0) else 28,31,30,31,30,31,31,30,31,30,31]
		if date.day > days[month-1]: return -1
		var timestamp: int = Time.get_unix_time_from_datetime_dict(date)
		var round_trip: Dictionary = Time.get_datetime_dict_from_unix_time(timestamp)
		for field: String in date:
			if date[field] != round_trip[field]: return -1
		return timestamp
	return -1

func _remember(response: Dictionary, generation: int = -1) -> Dictionary:
	if generation != -1 and generation != _session_generation: return _failure("ACCOUNT_CHANGED")
	if not response.ok: return response
	var data: Dictionary = response.data
	if not data.get("access_token") is String or not data.get("refresh_token") is String or not data.get("player") is Dictionary:
		clear_session()
		return _failure("INVALID_SESSION_RESPONSE")
	_access_token = data.access_token
	_refresh_token = data.refresh_token
	_refresh_request_id = ""
	var previous_player: Dictionary = player
	player = data.player.duplicate(true)
	_save_session()
	if player != previous_player: identity_changed.emit()
	# Callers receive player/expiry, never copies of bearer credentials.
	var safe: Dictionary = data.duplicate(true)
	safe.erase("access_token")
	safe.erase("refresh_token")
	response.data = safe
	response.erase("body")
	return response

func google_challenge() -> Dictionary:
	return await request_api("/auth/google/challenge",HTTPClient.METHOD_POST)

func developer_login(development_key: String) -> Dictionary:
	if _busy: return _failure("BUSY")
	if "\n" in development_key or "\r" in development_key: return _failure("INVALID_DEVELOPMENT_KEY")
	_busy = true
	clear_session()
	var generation: int = _session_generation
	var response: Dictionary = _remember(await _send("/auth/developer",HTTPClient.METHOD_POST,{},false,"",PackedStringArray(["X-Dev-Auth-Key: "+development_key])),generation)
	_busy = false
	return response

func poll_google(poll_token: String) -> Dictionary:
	if _busy: return _failure("BUSY")
	_busy = true
	var generation: int = _session_generation
	var response: Dictionary = await _send("/auth/google/browser/poll",HTTPClient.METHOD_POST,{"token":poll_token},false)
	if response.ok and response.data.get("status", "") != "pending": response = _remember(response,generation)
	_busy = false
	return response

func google_login(id_token: String, challenge_id: String, display_name: String = "Racer") -> Dictionary:
	if _busy: return _failure("BUSY")
	_busy = true
	clear_session()
	var generation: int = _session_generation
	var payload: Dictionary = {"id_token":id_token,"challenge_id":challenge_id}
	if not display_name.is_empty(): payload.display_name = display_name
	var response: Dictionary = _remember(await _send("/auth/google",HTTPClient.METHOD_POST,payload,false),generation)
	_busy = false
	return response

func development_login(subject: String, display_name: String, development_key: String) -> Dictionary:
	if _busy: return _failure("BUSY")
	if "\n" in development_key or "\r" in development_key: return _failure("INVALID_DEVELOPMENT_KEY")
	_busy = true
	clear_session()
	var generation: int = _session_generation
	var response: Dictionary = _remember(await _send("/auth/development",HTTPClient.METHOD_POST,{"subject":subject,"display_name":display_name},false,"",PackedStringArray(["X-Dev-Auth-Key: "+development_key])),generation)
	_busy = false
	return response

func request_api(path: String, method: HTTPClient.Method = HTTPClient.METHOD_GET, payload: Dictionary = {}, idempotency_key: String = "", authenticated: bool = false) -> Dictionary:
	if signed_in() and method == HTTPClient.METHOD_GET and (path == "/tracks" or path.begins_with("/tracks?") or path.begins_with("/track-versions/") or path.begins_with("/challenges/")): authenticated = true
	if authenticated and not _delete_request_id.is_empty(): return _failure("DELETION_PENDING")
	# Public reads need no session rotation and must not block racing or sign-in.
	if method == HTTPClient.METHOD_GET:
		return await _coalesced_read(path,authenticated)
	# Fresh race authorization is independent of a prior durable score upload.
	# Healthy tickets bypass the mutation queue; credential rotation stays serialized.
	if authenticated and method == HTTPClient.METHOD_POST and _race_ticket_path(path):
		return await _authenticated_read(path,method,payload,idempotency_key)
	var identity: String = str(player.get("id",""))
	var generation: int = _session_generation
	var profile_wait: int = Time.get_ticks_usec()
	while _busy: await get_tree().process_frame
	_profile_request(path,"queue",profile_wait)
	if authenticated and (str(player.get("id","")) != identity or generation != _session_generation): return _failure("ACCOUNT_CHANGED")
	_busy = true
	var used_access: String = _access_token
	var network_context: Dictionary = {"attempt":0,"queue_us":Time.get_ticks_usec()-profile_wait}
	var response: Dictionary = _checked(await _send_context(path,method,payload,authenticated,idempotency_key,network_context),path,method)
	if response.status == 415 and not _disable_gzip:
		_disable_gzip = true
		response = _checked(await _send_context(path,method,payload,authenticated,idempotency_key,network_context),path,method)
	if authenticated and (str(player.get("id","")) != identity or generation != _session_generation):
		_busy = false
		return _failure("ACCOUNT_CHANGED")
	if authenticated and response.status == 401 and not _refresh_token.is_empty():
		response = await _renew_session(generation,path,method,payload,idempotency_key,used_access,network_context)
		if generation != _session_generation:
			_busy = false
			return _failure("ACCOUNT_CHANGED")
		if response.status == 401 or (response.get("refresh_failed",false) and not refresh_retry_safe(response)): clear_session()
	elif authenticated and response.status == 401:
		clear_session()
	_busy = false
	return response

static func _race_ticket_path(path: String) -> bool:
	path = path.get_slice("?",0)
	return path == "/run-tickets" or ((path.begins_with("/rivalry/") or path.begins_with("/challenges/")) and path.get_slice_count("/") == 4 and path.ends_with("/tickets"))

static func _independent_auth_request(path: String, method: HTTPClient.Method) -> bool:
	# A tiny verified-time lookup must not queue behind durable uploads. Its
	# credential rotation uses the same independent lock as race authorization.
	return (method == HTTPClient.METHOD_POST and _race_ticket_path(path)) or (method == HTTPClient.METHOD_GET and path.get_slice("?",0) == "/challenges/sources")

func _authenticated_read(path: String, method: HTTPClient.Method = HTTPClient.METHOD_GET, payload: Dictionary = {}, idempotency_key: String = "") -> Dictionary:
	var identity: String = str(player.get("id",""))
	var generation: int = _session_generation
	var used_access: String = _access_token
	var network_context: Dictionary = {"attempt":0,"queue_us":0}
	var response: Dictionary = _checked(await _send_context(path,method,payload,true,idempotency_key,network_context),path,method)
	if response.status == 415 and method != HTTPClient.METHOD_GET and not _disable_gzip:
		_disable_gzip = true
		response = _checked(await _send_context(path,method,payload,true,idempotency_key,network_context),path,method)
	if str(player.get("id","")) != identity or generation != _session_generation: return _failure("ACCOUNT_CHANGED")
	if int(response.status) != 401: return response
	if _refresh_token.is_empty():
		clear_session()
		return response
	var profile_wait: int = Time.get_ticks_usec()
	var independent: bool = _independent_auth_request(path,method)
	if not independent:
		while _busy: await get_tree().process_frame
	_profile_request(path,"refresh_queue",profile_wait)
	network_context.queue_us = Time.get_ticks_usec()-profile_wait
	if str(player.get("id","")) != identity or generation != _session_generation: return _failure("ACCOUNT_CHANGED")
	if not independent: _busy = true
	response = await _renew_session(generation,path,method,payload,idempotency_key,used_access,network_context)
	if not independent: _busy = false
	if str(player.get("id","")) != identity or generation != _session_generation: return _failure("ACCOUNT_CHANGED")
	if response.status == 401 or (response.get("refresh_failed",false) and not refresh_retry_safe(response)): clear_session()
	return response

func logout() -> Dictionary:
	var token: String = _access_token
	var refresh: String = _refresh_token
	clear_session()
	var storage_failed: bool = persistence_error
	# Revocation uses the captured credential on its own request; local sign-out
	# is immediate even while another operation is rotating the session.
	if token.is_empty() and refresh.is_empty(): return _failure("SESSION_STORAGE_ERROR") if storage_failed else {"ok":true,"status":200,"data":{},"error":""}
	var payload: Dictionary = {} if refresh.is_empty() else {"refresh_token":refresh}
	var headers: Variant = PackedStringArray() if token.is_empty() else PackedStringArray(["Authorization: Bearer "+token])
	var response: Dictionary = await _send("/auth/logout",HTTPClient.METHOD_POST,payload,false,"",headers)
	return _failure("SESSION_STORAGE_ERROR") if storage_failed else response

func race_ticket(version_id: String, vehicle_id: String, key: String, purpose: String = "race") -> Dictionary:
	return await request_api("/run-tickets",HTTPClient.METHOD_POST,{"version_id":version_id,"vehicle_id":vehicle_id,"purpose":purpose},key,true)

static func _normalize_proof(proof: Dictionary, include_incidents: bool) -> Dictionary:
	if proof.get("schema","") != "bmt-race-proof-v1" or not proof.get("samples") is Array: return {}
	var samples: Array = []
	for row: Variant in proof.samples:
		if not row is Array or row.size() != 8: return {}
		for value: Variant in row:
			if not (value is int or value is float) or not is_finite(float(value)): return {}
		if not _whole(row[0],0,216000) or not _whole(row[6],0,1): return {}
		var sample: Array = row.duplicate()
		sample[0] = int(row[0]); sample[6] = int(row[6])
		samples.append(sample)
	var result: Dictionary = {"schema":"bmt-race-proof-v1","samples":samples}
	var incidents: Variant = proof.get("incidents")
	if include_incidents and incidents is Dictionary and incidents.size() == 4 and incidents.get("schema") == "bmt-race-incidents-v1" and _whole(incidents.get("ticks"),1,216000) and _whole(incidents.get("collision_count"),0,216000) and incidents.get("off_track") is bool:
		result.incidents = {"schema":"bmt-race-incidents-v1","ticks":int(incidents.ticks),"collision_count":int(incidents.collision_count),"off_track":incidents.off_track}
	return result

func race_submission_options() -> Dictionary:
	var result: Dictionary = {"path":1 if int(_capabilities.get("race_path_wire_version",0)) >= 1 else 0,
		"incidents":int(_capabilities.get("race_incident_rewards_version",0)) == 1}
	if int(_capabilities.get("non_improving_runs_version",0)) == 1: result.result = 1
	return result

static func _lap_tick_summary(seconds: Array[float], elapsed_ticks: int, tick_rate: int = 120) -> Array:
	# RaceProof captures each lap at its ending simulation tick. Difference the
	# absolute crossing ticks; rounding five fractional lap durations loses ticks.
	if seconds.size() != 5 or elapsed_ticks < 1 or elapsed_ticks > 216000 or tick_rate < 1: return []
	var laps: Array = []
	var total_seconds: float = 0.0
	var previous: int = 0
	for duration: float in seconds:
		if not is_finite(duration) or duration <= 0.0: return []
		total_seconds += duration
		if total_seconds*tick_rate > elapsed_ticks: return []
		var boundary: int = ceili(total_seconds*tick_rate)
		if boundary <= previous or boundary > elapsed_ticks: return []
		laps.append(boundary-previous)
		previous = boundary
	return laps if previous == elapsed_ticks else []

static func _rounded_lap_mismatch(count: int, rewinds: Array, claims: Array) -> bool:
	# Only the old five-lap rounding error is recoverable here. Its invalid hint
	# never produced a wire body; omit it and submit the unchanged path normally.
	if not _whole(count,1,216000) or claims.size() != 5 or rewinds.size() > 3: return false
	var total: int = 0
	for value: Variant in claims:
		if not _whole(value,1,216000): return false
		total += int(value)
	var elapsed: int = count
	for event: Variant in rewinds:
		if not event is Dictionary or not _whole(event.get("from_tick"),0,216000) or not _whole(event.get("to_tick"),0,216000): return false
		elapsed -= int(event.from_tick)-int(event.to_tick)
	return elapsed > 0 and elapsed-total in [-2,-1,1,2,3]

static func _pack_trajectory(count: int, proof: Dictionary, rewinds: Array, ghost: Dictionary = {}, include_incidents: bool = false, packed_path: bool = false, claimed_lap_ticks: Array = []) -> Dictionary:
	# Normalize the small movement record without encoding/scanning control frames.
	if not _whole(count,1,216000): return {}
	var normalized: Dictionary = _normalize_proof(proof,include_incidents)
	if normalized.is_empty(): return {}
	var events: Array = []
	if rewinds.size() > 3: return {}
	for source: Variant in rewinds:
		if not source is Dictionary or not source.get("receipt_id") is String or str(source.receipt_id).is_empty(): return {}
		for field: String in ["input_offset","from_tick","to_tick"]:
			if not _whole(source.get(field),0,216000): return {}
		events.append({"receipt_id":str(source.receipt_id),"input_offset":int(source.input_offset),"from_tick":int(source.from_tick),"to_tick":int(source.to_tick)})
	var path: Array = []
	for row: Array in normalized.samples: path.append([row[0],row[1],row[2],row[6]])
	var result: Dictionary = {"schema":"bmt-trajectory-v1","input_count":count,"race_proof":{"schema":"bmt-race-path-v1","samples":path},"rewinds":events}
	if not claimed_lap_ticks.is_empty():
		if claimed_lap_ticks.size() != 5: return {}
		var laps: Array = []
		var total: int = 0
		for value: Variant in claimed_lap_ticks:
			if not _whole(value,1,216000): return {}
			laps.append(int(value))
			total += int(value)
		var elapsed: int = count
		for event: Dictionary in events: elapsed -= int(event.from_tick)-int(event.to_tick)
		if total != elapsed: return {}
		result.claimed_lap_ticks = laps
	if packed_path: result.race_proof = load("res://backend/path_wire.gd").encode(result.race_proof)
	if normalized.has("incidents"): result.race_proof.incidents = normalized.incidents
	if not ghost.is_empty(): result.ghost = ghost
	return result

func submit_run(ticket_id: String, frames: Array, key: String, rewinds: Array = [], race_proof: Dictionary = {}, ghost: Dictionary = {}) -> Dictionary:
	if not bool(_capabilities.get("trajectory_verification",false)):
		return _failure("SUBMISSION_SERVER_UPDATE_REQUIRED")
	var generation: int = _session_generation
	var origin: String = _base_url
	var include_incidents: bool = int(_capabilities.get("race_incident_rewards_version",0)) == 1
	var preparation: int = Time.get_ticks_usec()
	var replay: Variant = await _background(_pack_trajectory.bind(frames.size(),race_proof,rewinds,ghost,include_incidents))
	if generation != _session_generation or origin != _base_url: return _failure("ACCOUNT_CHANGED")
	note_request_preparation(key,Time.get_ticks_usec()-preparation)
	if not replay is Dictionary or replay.is_empty(): return _failure("INVALID_REPLAY",422)
	return await request_api("/runs",HTTPClient.METHOD_POST,{"ticket_id":ticket_id,"replay":replay},key,true)

static func _whole(value: Variant, minimum: int = 0, maximum: int = 9007199254740991) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) >= minimum and float(value) <= maximum and float(value) == float(int(value))

static func _text(value: Variant) -> bool:
	return value is String and not value.is_empty() and value.length() <= 256

static func valid_run(data: Variant) -> bool:
	return data is Dictionary and _text(data.get("run_id")) and data.get("status") in ["queued","verifying","verified","skipped","rejected","failed"] and (data.status not in ["failed","rejected"] or _text(data.get("failure_code"))) and (data.status != "skipped" or data.get("skip_reason") == "no_improvement") and (not data.get("outcome") is Dictionary or _whole(data.get("slot"),0,4))

static func valid_wallet(data: Variant) -> bool:
	if not data is Dictionary: return false
	for field: String in ["free_rewinds","ad_free"]:
		if data.has(field) and not data[field] is bool: return false
	return data is Dictionary and _whole(data.get("balance")) and _whole(data.get("free"),0,1) and _whole(data.get("reset_at"),1)

static func valid_deletion_preview(data: Variant) -> bool:
	if not data is Dictionary or data.get("schema_version") != 1 or not _text(data.get("player_id")): return false
	for field: String in ["publishing_slots","coins","banked_resumes","cosmetic_unlocks","pending_purchases"]:
		if not _whole(data.get(field)): return false
	if not _whole(data.get("server_now"),1,253402300799) or not _whole(data.get("ad_free_until"),0,253402300799): return false
	if not data.get("ad_free") is bool or not data.get("ad_free_forever") is bool: return false
	return data.ad_free == (data.ad_free_forever or data.ad_free_until > data.server_now)

static func valid_response(path: String, method: HTTPClient.Method, data: Variant) -> bool:
	if not data is Dictionary: return false
	var endpoint: String = path.get_slice("?",0)
	if endpoint == "/me/appearances":
		return load("res://persistence/appearance_state.gd").valid_car(data) if method == HTTPClient.METHOD_PUT else data.size() == 1 and load("res://persistence/appearance_state.gd").valid_collection(data.get("appearances"))
	if endpoint == "/economy": return load("res://persistence/cosmetic_catalog.gd").valid_wallet(data)
	if endpoint == "/economy/purchases":
		return _text(data.get("item_id")) and _whole(data.get("charged")) and load("res://persistence/cosmetic_catalog.gd").valid_wallet(data.get("wallet"))
	if endpoint.begins_with("/economy/rewards/"):
		if data.get("status") not in ["credited","pending","unavailable"] or not _whole(data.get("amount")) or not data.get("rows") is Array or data.rows.size() > 12: return false
		var total: int = 0
		for row: Variant in data.rows:
			if not row is Dictionary or not _text(row.get("title")) or not _whole(row.get("amount")) or row.get("icon") not in ["flag","coin","timer","bars","trophy"] or row.get("eligible") != true: return false
			total += int(row.amount)
		return total == int(data.amount)
	if endpoint == "/privacy/deletion-preview": return method == HTTPClient.METHOD_GET and valid_deletion_preview(data)
	if endpoint == "/privacy/account-deletion": return data.get("status") in ["requested","complete"] and _text(data.get("player_id")) and data.get("tracks_retained") == true and data.get("standings_retained") == true and data.get("display_name") == "Removed account" and _whole(data.get("requested_at"),1)
	if endpoint == "/community/terms": return _text(data.get("version")) and data.get("accepted") is bool and (method != HTTPClient.METHOD_GET or (data.get("text") is String and not data.text.is_empty() and data.text.length() <= 16384))
	if endpoint == "/community/blocks":
		if not data.get("items") is Array or data.items.size() > 1000: return false
		for item: Variant in data.items:
			if not item is Dictionary or not _text(item.get("player_id")) or not _text(item.get("display_name")): return false
		return true
	if endpoint.begins_with("/community/blocks/"): return _text(data.get("player_id")) and data.get("blocked") is bool
	if endpoint == "/reports" and method == HTTPClient.METHOD_GET: return data.get("items") is Array and data.items.size() <= 50 and data.get("has_more") is bool
	if endpoint == "/reports" or (endpoint.begins_with("/reports/") and endpoint.ends_with("/appeal")): return _text(data.get("id")) and data.get("status") in ["open","investigating","resolved","appealed"]
	if endpoint == "/privacy/preferences": return data.get("analytics_enabled") is bool
	if endpoint == "/auth/google/browser/cancel": return method == HTTPClient.METHOD_POST and data.is_empty()
	if endpoint == "/auth/google/browser/prepare": return _text(data.get("client_id")) and _text(data.get("nonce"))
	if endpoint == "/auth/google/browser/complete": return data.get("status") == "complete"
	if endpoint == "/auth/google/browser/start": return _text(data.get("poll_token")) and data.get("browser_url") is String and data.browser_url.length() < 4096
	if endpoint == "/auth/google/challenge": return _text(data.get("challenge_id")) and _text(data.get("nonce"))
	if endpoint.begins_with("/auth/") and endpoint not in ["/auth/logout","/auth/logout-all","/auth/google/challenge","/auth/google/browser/start"]:
		if data.get("status") == "pending": return true
		return _text(data.get("access_token")) and _text(data.get("refresh_token")) and data.get("player") is Dictionary and _text(data.player.get("id"))
	if endpoint == "/me": return _text(data.get("id"))
	if endpoint.begins_with("/run-tickets/") and endpoint.ends_with("/submission"):
		return data.has("run") and (data.run == null or (valid_run(data.run) and str(data.run.get("ticket_id","")) == endpoint.get_slice("/",2)))
	if endpoint == "/runs/status":
		if not data.get("items") is Array or data.items.size() > 32: return false
		for item: Variant in data.items:
			if not valid_run(item): return false
		return true
	if endpoint == "/runs" or (endpoint.begins_with("/runs/") and not endpoint.ends_with("/replay")): return valid_run(data)
	if endpoint == "/resumes": return valid_wallet(data)
	if endpoint == "/resume-races": return _text(data.get("race_id")) and _whole(data.get("used"),0,3)
	if endpoint.begins_with("/resume-races/") and endpoint.ends_with("/resumes"): return _text(data.get("receipt_id")) and _whole(data.get("used"),1,3) and valid_wallet(data.get("wallet"))
	if endpoint == "/resume-recovery": return data.get("state") in ["absent","consumed","abandoned"] and valid_wallet(data.get("wallet")) and (data.state != "consumed" or (_text(data.get("receipt_id")) and _whole(data.get("used"),1,3)))
	if (endpoint == "/run-tickets" or ((endpoint.begins_with("/rivalry/") or endpoint.begins_with("/challenges/")) and endpoint.ends_with("/tickets"))) and method == HTTPClient.METHOD_POST:
		if not _text(data.get("ticket_id")) or not data.get("manifest") is Dictionary: return false
		for key: String in ["track_content_hash","engine_version","track_schema","replay_schema","verifier_version","physics_version","compiler_version","rules_key","config_hash"]:
			if not _text(data.manifest.get(key)): return false
		return _whole(data.manifest.get("tick_rate"),1) and _whole(data.manifest.get("laps"),1)
	if endpoint == "/tracks" and method == HTTPClient.METHOD_GET:
		if not data.get("items") is Array: return false
		for item: Variant in data.items:
			if not item is Dictionary: return false
	if (endpoint == "/tracks" and method == HTTPClient.METHOD_POST) or (endpoint.begins_with("/tracks/") and endpoint.ends_with("/versions")) or (endpoint.begins_with("/track-versions/") and endpoint.ends_with("/publish")):
		return _text(data.get("track_id")) and _text(data.get("version_id"))
	if endpoint == "/me/tracks":
		if not data.get("items") is Array: return false
		for item: Variant in data.items:
			if not item is Dictionary or not _text(item.get("version_id")) or not _text(item.get("content_hash")): return false
	if endpoint.begins_with("/rivalry/tickets/") and endpoint.ends_with("/result"):
		return data.get("status") in ["upload_pending","queued","verifying","verified","skipped","rejected","failed","expired"] and (not data.get("outcome") is Dictionary or _whole(data.get("slot"),0,4))
	return true

func _checked(response: Dictionary, path: String, method: HTTPClient.Method) -> Dictionary:
	if response.get("ok",false) and response.get("data") is Dictionary and is_instance_valid(safety) and not path.begins_with("/community/") and not path.begins_with("/reports") and not path.ends_with("/document"):
		response.data = response.data.duplicate(true)
		safety.mask_public(response.data)
	if not response.get("ok",false) or valid_response(path,method,response.get("data")): return response
	var failed: Dictionary = _failure("INVALID_RESPONSE",502)
	var identifier: String = load("res://backend/network_health.gd").request_id(PackedStringArray(["X-Request-ID: "+str(response.get("request_id",""))]))
	if not identifier.is_empty(): failed.request_id = identifier
	return failed

func rate_track(version_id: String, score: int, key: String) -> Dictionary:
	return await request_api("/track-versions/"+version_id.uri_encode()+"/rating",HTTPClient.METHOD_PUT,{"score":score},key,true)
