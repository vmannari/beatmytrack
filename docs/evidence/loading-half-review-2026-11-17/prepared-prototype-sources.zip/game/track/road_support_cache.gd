extends RefCounted
## Pure numeric support data: no track owners, rendering dependencies or disk I/O.
const MAX_ENTRIES: int = 4
const MAX_BYTES: int = 2 * 1024 * 1024
static var entries: Dictionary = {}
static var bytes: int = 0
static var generation: int = 0
static var guard := Mutex.new()

static func read(key: String) -> Dictionary:
	_review_restore(key)
	guard.lock()
	var entry: Dictionary = entries.get(key,{})
	if not entry.is_empty():
		entries.erase(key)
		entries[key] = entry
	var result: Dictionary = {"value":entry.get("value"),"generation":generation}
	guard.unlock()
	return result

static func write(key: String, value: Dictionary, expected_generation: int) -> void:
	# Include headroom for dictionary/array containers beyond serialized numbers.
	var cost: int = var_to_bytes(value).size()*2+key.length()*4+512
	if cost > MAX_BYTES: return
	guard.lock()
	if generation != expected_generation:
		guard.unlock()
		return
	if entries.has(key):
		bytes -= int(entries[key].bytes)
		entries.erase(key)
	while not entries.is_empty() and (entries.size() >= MAX_ENTRIES or bytes+cost > MAX_BYTES):
		var oldest: String = entries.keys()[0]
		bytes -= int(entries[oldest].bytes)
		entries.erase(oldest)
	entries[key] = {"value":value,"bytes":cost}
	bytes += cost
	guard.unlock()
	_review_save(key,value)

static func trim() -> void:
	guard.lock()
	generation += 1
	entries.clear()
	bytes = 0
	guard.unlock()

static func bytes_used() -> int:
	guard.lock()
	var result: int = bytes
	guard.unlock()
	return result

static var review_disk_hits: int = 0
static var review_disk_restoring: bool = false
static func _review_digest(data: PackedByteArray) -> String:
	var hash := HashingContext.new(); hash.start(HashingContext.HASH_SHA256); hash.update(data)
	return hash.finish().hex_encode()
static func _review_restore(key: String) -> void:
	guard.lock()
	var present: bool = entries.has(key)
	var expected_generation: int = generation
	guard.unlock()
	if present: return
	var name: String = key.sha256_text()+".support"
	var path: String = "user://cache/support-prototype/"+name
	if "--bundle" in OS.get_cmdline_user_args() and FileAccess.file_exists("res://assets/prepared_half_prototype/support-prototype/"+name):
		path = "res://assets/prepared_half_prototype/support-prototype/"+name
	var file := FileAccess.open_compressed(path,FileAccess.READ,FileAccess.COMPRESSION_ZSTD)
	if file == null: return
	if file.get_length() > MAX_BYTES or file.get_length() <= 0: return
	var packet: Variant = file.get_var(false)
	if not packet is Dictionary or packet.get("key","") != key or not packet.get("value") is Dictionary: return
	if packet.get("source","") != FileAccess.get_sha256("res://track/road_surface_height.gd"): return
	if packet.get("sha","") != _review_digest(var_to_bytes(packet.value)): return
	var value: Dictionary = packet.value
	if not value.get("floors") is Array or not value.get("bins") is Dictionary: return
	for floor: Variant in value.floors:
		if not floor is PackedVector2Array: return
	review_disk_restoring = true
	write(key,value,expected_generation)
	review_disk_restoring = false
	review_disk_hits += 1
static func _review_save(key: String, value: Dictionary) -> void:
	if review_disk_restoring: return
	var directory: String = "user://cache/support-prototype"
	if DirAccess.make_dir_recursive_absolute(directory) != OK: return
	var file := FileAccess.open_compressed(directory.path_join(key.sha256_text()+".support"),FileAccess.WRITE,FileAccess.COMPRESSION_ZSTD)
	if file != null: file.store_var({"key":key,"value":value,"source":FileAccess.get_sha256("res://track/road_surface_height.gd"),"sha":_review_digest(var_to_bytes(value))},false)
