extends SceneTree
## Native menu review with isolated local data and no service connection.
var output: String
var report: Dictionary = {}
const Icons = preload("res://ui/header_car_icons.gd")

func _initialize() -> void: run.call_deferred()

func settle() -> void:
	for _frame: int in range(12): await process_frame
	await RenderingServer.frame_post_draw

func shot(label: String) -> void:
	await settle()
	root.get_texture().get_image().save_png(output.path_join(label+".png"))

func icons_ready(picker: Node) -> void:
	for _frame: int in range(2): await process_frame

func picture_ready(icon: Control) -> void:
	var deadline: int = Time.get_ticks_msec()+10000
	while Time.get_ticks_msec() < deadline and (icon.preview.texture != Icons.texture(VehicleCatalog.selected,icon.records) or icon.preview.modulate != Color.WHITE or icon.preview.position != Vector2.ZERO): await process_frame

func key(code: Key) -> void:
	var event := InputEventKey.new()
	event.keycode = code
	event.physical_keycode = code
	event.pressed = true
	root.push_input(event)
	await process_frame
	event = event.duplicate()
	event.pressed = false
	root.push_input(event)
	await process_frame

func click(point: Vector2) -> void:
	var move := InputEventMouseMotion.new()
	move.position = point
	root.push_input(move)
	var event := InputEventMouseButton.new()
	event.position = point
	event.button_index = MOUSE_BUTTON_LEFT
	event.pressed = true
	root.push_input(event)
	await process_frame
	event = event.duplicate()
	event.pressed = false
	root.push_input(event)
	await process_frame

func motion_review(picker: MenuButton) -> void:
	var popup: PopupMenu = picker.get_popup()
	var motion: Node = picker.get_node("HeaderCarMotion")
	var samples: Array[Dictionary] = []
	for extent: Vector2i in [Vector2i(960,540),Vector2i(1280,720),Vector2i(1720,900)]:
		var frames: Dictionary = {}
		popup.hide()
		root.size = extent
		await create_timer(0.25).timeout
		await click(root.get_final_transform()*picker.get_global_rect().get_center())
		await RenderingServer.frame_post_draw
		var entry: Dictionary = {"extent":str(extent),"opening_progress":motion.progress,"popup_position":str(popup.position),"popup_size":str(popup.size)}
		frames["open-start"] = root.get_texture().get_image()
		await create_timer(0.07).timeout
		await RenderingServer.frame_post_draw
		frames["open-mid"] = root.get_texture().get_image()
		await create_timer(0.23).timeout
		await RenderingServer.frame_post_draw
		entry.open_settled = popup.visible and motion.tween == null and popup.canvas_transform == Transform2D.IDENTITY
		frames["open"] = root.get_texture().get_image()
		await create_timer(0.04).timeout
		var close_begin: int = Time.get_ticks_usec()
		await key(KEY_ESCAPE)
		await RenderingServer.frame_post_draw
		entry.exit_present = not popup.visible and is_instance_valid(motion.exit_image)
		entry.close_capture_ms = (Time.get_ticks_usec()-close_begin)/1000.0
		entry.exit_alpha = motion.exit_image.modulate.a if is_instance_valid(motion.exit_image) else 0.0
		entry.exit_bounds = str(motion.exit_image.get_global_rect()) if is_instance_valid(motion.exit_image) else "none"
		frames["close-start"] = root.get_texture().get_image()
		await create_timer(0.06).timeout
		await RenderingServer.frame_post_draw
		frames["close-mid"] = root.get_texture().get_image()
		await create_timer(0.18).timeout
		await RenderingServer.frame_post_draw
		entry.exit_cleaned = motion.tween == null and motion.exit_image == null and picker.find_children("*","SubViewport",true,false).is_empty()
		frames["closed"] = root.get_texture().get_image()
		for label: String in frames:
			frames[label].save_png(output.path_join("motion-%dx%d-%s.png" % [extent.x,extent.y,label]))
		samples.append(entry)
	root.size = Vector2i(1280,720)
	await settle()
	# A rapid close/reopen must replace the outgoing visual, and hiding cancels both.
	await click(root.get_final_transform()*picker.get_global_rect().get_center())
	await create_timer(0.04).timeout
	await key(KEY_ESCAPE)
	await click(root.get_final_transform()*picker.get_global_rect().get_center())
	report.motion_reopen = popup.visible and motion.exit_image == null
	await create_timer(0.26).timeout
	report.motion_reopen_settled = popup.visible and motion.tween == null
	picker.hide()
	report.motion_hide_cleanup = not popup.visible and motion.tween == null and motion.exit_image == null
	picker.show()
	await settle()
	picker.show_popup()
	await icons_ready(picker)
	await create_timer(0.26).timeout
	report.motion_returned_open = popup.visible
	report.motion_samples = samples

func run() -> void:
	OS.set_environment("BMT_API_URL","")
	var baseline: bool = OS.get_environment("BMT_PROFILE_CAR_BASELINE") == "1"
	var destination: String = OS.get_environment("BMT_PROFILE_CAR_OUTPUT")
	if destination.is_empty(): destination = "res://../docs/evidence/profile-active-car-2026-10-25"
	output = ProjectSettings.globalize_path(destination.path_join(RenderingServer.get_current_rendering_method()))
	DirAccess.make_dir_recursive_absolute(output)
	root.size = Vector2i(1280,720)
	root.gui_embed_subwindows = true
	var source: GDScript = load("res://core/app.gd")
	if baseline:
		source = GDScript.new()
		source.source_code = FileAccess.get_file_as_string("res://../docs/evidence/profile-active-car-2026-10-25/before/app.gd.txt")
		if source.reload() != OK: quit(1); return
	var app: Node = source.new()
	var folder: String = "user://profile_car_"+TrackLibrary.unique_id()
	DirAccess.make_dir_recursive_absolute(folder)
	app.library = TrackLibrary.new(folder.path_join("tracks"))
	app.records = LocalRecords.new(folder.path_join("records.json"))
	app.cloud_root_override = folder.path_join("cloud")
	root.add_child(app)
	while not app.startup_complete: await process_frame
	app.race_area_mode = "free"
	app._show_screen("tracks")
	await settle()
	if baseline:
		await shot("before-compact")
	else:
		for id: String in VehicleCatalog.IDS:
			app._select_vehicle(VehicleCatalog.IDS.find(id))
			var icon: Control = app.account_button.get_node("MenuProfileCar")
			await picture_ready(icon)
			await shot("active-"+id)
			var image: Image = icon.preview.texture.get_image()
			var opaque: int = 0
			var low: Vector2i = image.get_size()
			var high := Vector2i(-1,-1)
			for y: int in range(image.get_height()):
				for x: int in range(image.get_width()):
					if image.get_pixel(x,y).a > 0.5:
						opaque += 1
						low = low.min(Vector2i(x,y))
						high = high.max(Vector2i(x,y))
			var center_error: Vector2 = (Vector2(low+high+Vector2i.ONE)*0.5-Vector2(image.get_size())*0.5)*icon.size/Vector2(image.get_size())
			report[id] = {"rendered_vehicle":icon.vehicle_id,"preview_bounds":str(icon.get_global_rect()),"button_bounds":str(app.account_button.get_global_rect()),"render_size":str(image.get_size()),"opaque_pixels":opaque,"visible_center_error":str(center_error),"vertical_center_error":center_error.y,"viewports":icon.find_children("*","SubViewport",true,false).size(),"nodes_3d":icon.find_children("*","Node3D",true,false).size()}
			if id == "forklift":
				app.account_button.text = "Ville"
				app.account_button.add_theme_color_override("font_color",MenuStyle.ACCENT)
				await shot("named-forklift")
				app.account_button.text = "Guest"
				app.account_button.remove_theme_color_override("font_color")
		app._select_vehicle(0)
		await picture_ready(app.account_button.get_node("MenuProfileCar"))
		var paint: Dictionary = VehicleLivery.defaults("compact")
		paint.colors.body = "c82e37"
		var parts: Dictionary = VehicleCustomisation.defaults()
		parts.hood = "cowl"
		parts.aero = "splitwing"
		app.records.settings.vehicle_liveries = {"compact":paint}
		app.records.settings.vehicle_customisation = {"compact":parts}
		report.appearance_save = app.records.save_records()
		var appearance_deadline: int = Time.get_ticks_msec()+60000
		while not app.header_car_cache.idle() and Time.get_ticks_msec()<appearance_deadline: await process_frame
		await picture_ready(app.account_button.get_node("MenuProfileCar"))
		await shot("customised-compact")
		var icon: Control = app.account_button.get_node("MenuProfileCar")
		report.equipped_picture_cached = icon.preview.texture == Icons.texture("compact",app.records) and Icons.customized.has(Icons.appearance_key("compact",app.records)) and app.records.settings.vehicle_liveries.compact == paint and app.records.settings.vehicle_customisation.compact == parts
		var preview_id: int = icon.preview.get_instance_id()
		icon.refresh()
		report.unchanged_render_retained = icon.preview.get_instance_id() == preview_id
		app.account_button.text = "Alexandria Longname"
		await shot("long-name")
		report.long_name_button_width = app.account_button.size.x
		app.account_button.text = "Guest"
		for dimensions: Vector2i in [Vector2i(960,540),Vector2i(1720,900)]:
			root.size = dimensions
			await shot("menu-%dx%d" % [dimensions.x,dimensions.y])
			var settings: Control = app.root_ui.find_child("MenuSettings",true,false)
			report[str(dimensions)] = {"profile_bounds":str(app.account_button.get_global_rect()),"settings_bounds":str(settings.get_global_rect()),"fits":root.get_visible_rect().encloses(settings.get_global_rect())}
		root.size = Vector2i(1280,720)
		await settle()
		var touch := InputEventScreenTouch.new()
		touch.index = 0
		touch.position = icon.get_global_rect().get_center()
		touch.pressed = true
		root.push_input(touch)
		await process_frame
		touch = touch.duplicate()
		touch.pressed = false
		root.push_input(touch)
		var picker: MenuButton = app.account_button.get_node("MenuCarPicker")
		var popup: PopupMenu = picker.get_popup()
		await icons_ready(picker)
		if OS.get_environment("BMT_HEADER_MOTION_REVIEW") == "1": await motion_review(picker)
		await shot("car-dropdown")
		report.car_opens_dropdown = popup.visible and app.screen == "tracks"
		report.dropdown_car_count = popup.item_count
		# Check the label pixels as well as the menu data after async icon draws.
		var screen_pixels: Image = root.get_texture().get_image()
		var label_pixels: int = 0
		var text_left: int = popup.position.x+116
		var text_top: int = popup.position.y+92
		for y: int in range(text_top,text_top+38):
			for x: int in range(text_left,popup.position.x+popup.size.x-12):
				var color: Color = screen_pixels.get_pixel(x,y)
				if minf(color.r,minf(color.g,color.b)) > 0.6: label_pixels += 1
		report.car_label_pixels = label_pixels
		report.car_labels_visible = label_pixels > 20
		report.active_car_hidden = true
		report.car_thumbnails = []
		for row: int in range(popup.item_count):
			var id: String = VehicleCatalog.IDS[popup.get_item_id(row)]
			if id == VehicleCatalog.selected: report.active_car_hidden = false
			var pixels: Image = popup.get_item_icon(row).get_image()
			report.car_thumbnails.append({"vehicle":id,"visible":pixels.get_used_rect().has_area(),"size":str(pixels.get_size())})
		report.header_viewports = app.account_button.find_children("*","SubViewport",true,false).size()
		report.header_nodes_3d = app.account_button.find_children("*","Node3D",true,false).size()
		report.picture_texture_count = Icons.images.size()
		var population_started: int = Time.get_ticks_usec()
		for _repeat: int in range(100): picker._populate()
		report.populate_100_ms = (Time.get_ticks_usec()-population_started)/1000.0
		for _step: int in range(popup.item_count-1): await key(KEY_DOWN)
		await key(KEY_ENTER)
		await picture_ready(icon)
		await shot("dropdown-selected-electric")
		report.keyboard_selects_car = VehicleCatalog.selected == "electric" and not popup.visible and app.screen == "tracks"
		var reloaded := LocalRecords.new(app.records.path)
		reloaded.load_records()
		report.selection_saved = reloaded.settings.get("selected_car") == "electric"
		# Opening then cancelling must leave the selected car intact.
		await click(icon.get_global_rect().get_center())
		await icons_ready(picker)
		await settle()
		report.new_active_car_hidden = true
		for row: int in range(popup.item_count):
			if VehicleCatalog.IDS[popup.get_item_id(row)] == "electric": report.new_active_car_hidden = false
		await key(KEY_ESCAPE)
		await settle()
		report.escape_cancels = not popup.visible and VehicleCatalog.selected == "electric"
		var loaded_before: int = Icons.texture_loads
		await click(icon.get_global_rect().get_center())
		await icons_ready(picker)
		await settle()
		report.reopen_uses_cached_icons = Icons.texture_loads == loaded_before
		var panel: StyleBox = popup.get_theme_stylebox("panel")
		var row_height: float = (popup.size.y-panel.get_minimum_size().y)/popup.item_count
		await click(Vector2(popup.position)+Vector2(80,panel.get_content_margin(SIDE_TOP)+row_height*5.5))
		await picture_ready(icon)
		await shot("dropdown-selected-forklift")
		report.mouse_selects_car = VehicleCatalog.selected == "forklift" and not popup.visible and app.screen == "tracks"
		reloaded.load_records()
		report.mouse_selection_saved = reloaded.settings.get("selected_car") == "forklift"
		report.closed_icon_worlds = picker.find_children("*","Node3D",true,false).size()
		# Only the name half navigates to the player's profile.
		touch = InputEventScreenTouch.new()
		touch.index = 0
		touch.position = app.account_button.get_global_rect().end-Vector2(36,32)
		touch.pressed = true
		root.push_input(touch)
		await process_frame
		touch = touch.duplicate()
		touch.pressed = false
		root.push_input(touch)
		await shot("profile-opened-from-name")
		report.name_opens_profile = app.screen == "profile"
		var file := FileAccess.open(output.path_join("capture-report.json"),FileAccess.WRITE)
		file.store_string(JSON.stringify(report,"\t"))
		file.close()
		print("PROFILE_CAR_REVIEW: ",JSON.stringify(report))
	root.remove_child(app)
	app.queue_free()
	await process_frame
	quit()
