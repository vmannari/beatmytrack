extends Node
## Local navigation and editor composition. Racing simulation stays in Game.

const GAME_SCENE: PackedScene = preload("res://core/game.tscn")
const AccountController = preload("res://backend/account_controller.gd")
const ProductTelemetry = preload("res://backend/product_telemetry.gd")
const RaceLoading = preload("res://ui/race_loading.gd")
const PublicationPrompt = preload("res://ui/publication_dialog.gd")
const RACE_LOAD_DEADLINE_SECONDS: float = 45.0
const RACE_LOAD_DRAW_WAIT_MSEC: int = 2000
var race_loading: RaceLoading
var tutorial: Node
var _tutorial_existing_save: bool = false
var BUILTIN_IDS: Array[String] = BuiltinTracks.ids()
var screen: String = "tracks"
var menu_open_costs: Dictionary = {}
var root_ui: Control
var menu_body: Control
var menu_body_slot: Control
var menu_body_backgrounds: Array[Control] = []
var outgoing_menu_page: Control
var menu_neighbors: Dictionary = {}
var _garage_parking: Control
var _retained_garage: GaragePage
var _garage_preloader: Node
var _retained_profile_car: Control
var race_profile_enabled: bool = false
var _rivalry_parking: Control
var _retained_rivalry_page: WeeklyRivalryPage
var _retained_rivalry_scope: String = ""
var cosmetic_economy: Node
var appearance_sync: Node
var header_car_cache: Node
var achievements: Node
var race_ad_breaks: Node
var game_configuration: Node
var _ad_input_blocker: Control
var _ad_previous_focus: WeakRef
var achievement_notification: Control
var _achievement_finale: String = ""
var _reviewed_rivalry_summaries: Dictionary = {}
var _achievement_challenges: Dictionary = {}
var _suspended_menu: Dictionary = {}
var menu_neighbor_direction: int = 0
var returning_menu_neighbor: Dictionary = {}
const MENU_PAGE_GAP: float = 64.0
var menu_page_motion: Tween
var race_mode_transition_rail: RaceModeRail
const RACE_MODE_PAGES: Array[String] = ["rivalry", "tracks", "daily", "challenges"]
var _race_mode_request: int = 0
var _rivalry_entry_pending: bool = false
var rivalry_standings_view: Dictionary = {}
var menu_edge_motion: Tween
var menu_drag_offset: float = 0.0
var content: VBoxContainer
var menu_layer: CanvasLayer
var game: Node
var selected_track: NativeTrack
var library := TrackLibrary.new()
var document: Dictionary = {}
const EDITOR_HISTORY = preload("res://editor/editor_history.gd")
var editor_session = preload("res://editor/editor_session.gd").new()
var history: Array[Dictionary]:
	get: return editor_session.undo
	set(value): editor_session.undo = value
var redo_history: Array[Dictionary]:
	get: return editor_session.redo
	set(value): editor_session.redo = value
var canvas: EditorCanvas
var editor_status: Label
var test_button: Button
var publish_button: Button
var share_button: Button
var capture_path: String = ""
var returning_to_editor: bool = false
var ui_touch_scale: float = 1.0
var ui_left_handed: bool = false
var records := LocalRecords.new()
var editor_view: Dictionary = {}
var editor_return_screen: String = "biome"
var editor_return_draft_view: Dictionary = {}
var editor_mode_buttons: Dictionary = {}
var editor_tools_open: bool = false
var editor_tools_panel: PanelContainer
var editor_map_panel: PanelContainer
var editor_undo: Button
var editor_redo: Button
var editor_world: EditorWorld
var object_browser_state: Dictionary = {}
var object_browser: ObjectBrowser
var object_population_panel: ObjectPopulationPanel
var editor_palette: Control
var editor_context: HBoxContainer
var surface_toolbar: PanelContainer
var surface_actions: HBoxContainer
var editor_issue_button: Button
var editor_issues: Array[Dictionary] = []
var editor_geometry: String = ""
var editor_inspector: VBoxContainer
var browser_state: Dictionary = {}
var discovery_provider := TrackDiscoveryProvider.new()
var track_catalog: TrackCatalog
var pending_menu_notice: String = ""
var publication_notification: PanelContainer
var _publication_request_active: bool = false
var _publication_dialog: PublicationPrompt
var _queued_track_link: String = ""
var _track_link_generation: int = 0
var editor_preview_cancel: RefCounted
var editor_preview_thread: Thread
var editor_preview_document: Dictionary = {}
var editor_raster_cache: Dictionary = {"enabled":true}
var editor_compiled_cache: Array[Dictionary] = []
const EDITOR_COMPILED_BUDGET: int = 16 * 1024 * 1024
var editor_memory = preload("res://editor/editor_memory.gd").new()
var _editor_exiting: bool = false
var editor_commits:
	get: return editor_session.commits
	set(value): editor_session.commits = value
var editor_validation_document: Dictionary:
	get: return editor_session.validated
	set(value): editor_session.validated = value
var editor_validation_errors: Array[String]:
	get: return editor_session.errors
	set(value): editor_session.errors = value
var editor_workflow_presentation: Dictionary:
	get: return editor_session.workflow
	set(value): editor_session.workflow = value
var editor_writes = preload("res://editor/write_queue.gd").new()
var editor_saved_snapshot: Dictionary = {}
var editor_route_pieces: Array = []
var editor_route_fields: Dictionary = {}
var editor_loading: PanelContainer
var editor_pending_road_bake: Dictionary = {}
var editor_save_button: Button
var editor_save_error: Error = OK
var editor_save_message: String = ""
var editor_pending_tools: Dictionary = {}
var editor_pending_id: String = ""
var editor_gesture_history: Array[Dictionary]:
	get: return editor_session.gesture_undo
	set(value): editor_session.gesture_undo = value
var editor_gesture_redo: Array[Dictionary]:
	get: return editor_session.gesture_redo
	set(value): editor_session.gesture_redo = value
var editor_issue_cursor: int = -1
var editor_hint_generation: int = 0
var editor_wip_saved: String = ""
var editor_wip_snapshot: Dictionary = {}
var editor_wip_store: TrackLibrary
var editor_saved_store: TrackLibrary
var editor_wip_disk_hash: String = ""
var editor_saved_disk_hash: String = ""
var editor_retry_original: bool = false
var online: AccountController
var account_button: Button
var _account_setup_pending: bool = false
var startup_complete: bool = false
var profile_root: String
var guest_records: LocalRecords
var guest_library: TrackLibrary
var active_profile: String = ""
var cloud: Node
var lifecycle: TrackLifecycle
var test_library_snapshot: TrackLibrary
var test_scope_snapshot: String = ""
var test_vehicle_snapshot: String = "compact"
var cloud_root_override: String = ""
var cloud_ticket: Dictionary = {}
var cloud_starting: bool = false
var _result_game_id: int = 0
var _challenge_return_ui: Control
var _challenge_return_screen: String = ""
var _navigation_generation: int = 0
var _profile_draft_recovery: Dictionary = {}
var rivalry: Node
var race_area_mode: String = "rivalry"
var rivalry_section: String = "overview"
var rivalry_track: int = 0
var rivalry_ghost_choice: int = 0
var rivalry_racing: bool = false
var rivalry_recording: Dictionary = {}
var rivalry_result_pending: bool = false
var rivalry_race_details: Dictionary = {}
var rivalry_refresh_ticks: int = 0
var challenges: ChallengesClient
var challenge_racing: bool = false
var challenge_practice: bool = false
var challenge_recording: Dictionary = {}
var challenge_result_view: bool = false
var challenge_browsing: bool = false
var challenge_seed: Dictionary = {}
var challenge_invitation: String = ""
var challenge_queued_invitation: String = ""
var challenge_links: Node
var challenge_refresh_ticks: int = 0
var product_telemetry: Node
var client_quality: Node
var _telemetry_race_started: bool = false
var _telemetry_race_finished: bool = false
const SELECTED_PREPARATION = preload("res://race/selected_track_preparation.gd")
var _selected_preparation_job: RefCounted
var _selected_preparation_track: NativeTrack
var _selected_preparation_browser: WeakRef
var _selected_preparation_scope: String = ""
var _selected_preparation_navigation: int = 0
var _selected_preparation_vehicle: String = ""
var _selected_preparation_serial: int = 0
var _selected_preparation_generation: int = 0
var _selected_preparation_pending: bool = false
var _selected_preparation_entry: Dictionary = {}
var _selected_preparation_pin: Array = []
var _selected_preparation_source: Dictionary = {}
var _selected_preparation_queued: bool = false
var _publishing_slot_check_at: int = 0
var _publishing_slots_foreground: bool = true

func _notification(what: int) -> void:
	if what == NOTIFICATION_OS_MEMORY_WARNING:
		if is_instance_valid(_garage_preloader): _garage_preloader.evict()
		editor_memory.pressure_requested = true
		editor_memory.next_sample = 0
	if what in [NOTIFICATION_APPLICATION_FOCUS_OUT,NOTIFICATION_APPLICATION_PAUSED]:
		if is_instance_valid(canvas) and canvas.active_pointer != -99: canvas.cancel_gesture()
		_flush_editor_writes()
		_publishing_slots_foreground = false
		if race_ad_breaks != null:
			race_ad_breaks.observe_time(false)
			race_ad_breaks.flush_progress()
	elif what in [NOTIFICATION_APPLICATION_FOCUS_IN,NOTIFICATION_APPLICATION_RESUMED]:
		_publishing_slots_foreground = true
		if race_ad_breaks != null: race_ad_breaks.observe_time(false)
		_refresh_creation_slots(true)
		if appearance_sync != null and _background_work_allowed() and screen == "garage": appearance_sync.refresh_if_stale()

func _background_work_allowed() -> bool:
	if cloud_starting or is_instance_valid(race_loading): return false
	if not is_instance_valid(game): return true
	var session: TrackSession = game.get("track_session")
	return session != null and session.finished

func _result_poll_allowed(area: String) -> bool:
	if not _background_work_allowed(): return false
	return (screen == "challenges" or challenge_result_view) if area == "challenges" else (screen == "rivalry" or rivalry_racing)

func _refresh_creation_slots(force: bool = false) -> void:
	if not _publishing_slots_foreground or screen not in ["create","drafts"] or is_instance_valid(game): return
	if not is_instance_valid(lifecycle) or lifecycle.cloud == null or not lifecycle.cloud.client.signed_in(): return
	var now: int = Time.get_ticks_msec()
	if not force and (not lifecycle.no_publishing_slots() or now < _publishing_slot_check_at): return
	# Studio awards can arrive while this page is open. Recheck on return and
	# at most once a minute while blocked; only explicit Publish sends a track.
	_publishing_slot_check_at = now+60000
	lifecycle.refresh_publishing_slots(true)

func _exit_tree() -> void:
	_editor_exiting = true
	_cancel_selected_preparation()
	_flush_editor_writes()
	if is_instance_valid(_challenge_return_ui): _challenge_return_ui.queue_free()
	_finish_preview_thread()

func _finish_preview_thread() -> void:
	if editor_preview_thread != null:
		if editor_preview_cancel != null: editor_preview_cancel.cancel()
		editor_preview_thread.wait_to_finish()
		editor_preview_thread = null
	editor_preview_document = {}

func _process(_delta: float) -> void:
	if race_ad_breaks != null:
		race_ad_breaks.enabled = OS.is_debug_build() and bool(records.settings.get("development_show_ads",false))
		race_ad_breaks.observe_time(_ad_play_active())
	# Hidden editor/menu state cannot supply information the active race uses.
	# A real OS pressure signal remains actionable while driving.
	if not _background_work_allowed():
		if editor_memory.pressure_requested: editor_memory.tick(self)
		return
	_poll_selected_preparation()
	editor_commits.poll()
	_apply_editor_commits()
	editor_writes.poll()
	_apply_editor_writes()
	if screen == "create" or is_instance_valid(_retained_garage) or (is_instance_valid(_garage_preloader) and _garage_preloader.has_work()) or editor_memory.pressure_requested: editor_memory.tick(self)
	if is_instance_valid(editor_loading) and is_instance_valid(canvas):
		editor_loading.visible = editor_commits.unsettled() or editor_preview_thread != null or canvas.native_preview == null or editor_world._building
	if editor_preview_thread == null or editor_preview_thread.is_alive(): return
	# Finish the detailed scene between gestures, never underneath a finger.
	if is_instance_valid(canvas) and canvas.active_pointer != -99: return
	var result: NativeTrack = editor_preview_thread.wait_to_finish()
	editor_preview_thread = null
	if result != null and not editor_pending_road_bake.is_empty() and result.metadata.get("creator_document",{}) == editor_pending_road_bake:
		NativeTrackVisual.request_saved_road_bake.call_deferred(result,get_tree())
		editor_pending_road_bake.clear()
	if not is_instance_valid(canvas) or screen != "create":
		if result != null: result.editor_roads = {}
		return
	if document != editor_preview_document:
		if result != null: result.editor_roads = {}
		_queue_editor_preview()
		return
	editor_preview_document = {}
	if result != null: canvas.show_native(result)
	_update_editor_issues()

func _queue_editor_preview() -> void:
	if editor_preview_thread != null:
		if editor_preview_cancel != null and document != editor_preview_document: editor_preview_cancel.cancel()
		return
	editor_preview_document = document.duplicate(true)
	editor_preview_thread = Thread.new()
	editor_preview_cancel = preload("res://editor/work_job.gd").new()
	var error: Error = editor_preview_thread.start(_compile_editor_preview.bind(editor_preview_document,editor_preview_cancel.cancelled))
	if error != OK:
		editor_preview_thread = null
		var track: NativeTrack = _compile_editor_preview(editor_preview_document)
		editor_preview_document = {}
		if track != null: canvas.show_native(track)
		_update_editor_issues()

func _objects_only_edit() -> bool:
	if not is_instance_valid(canvas) or canvas.native_preview == null: return false
	var previous: Dictionary = canvas.native_preview.metadata.get("creator_document",{})
	for key: Variant in document:
		if key in ["objects","hidden_scenery"]: continue
		if not previous.has(key) or previous[key] != document[key]: return false
	for key: Variant in previous:
		if key not in ["objects","hidden_scenery"] and not document.has(key): return false
	return true


func _ready() -> void:
	get_tree().node_added.connect(_popup_node_added)
	GameLanguage.instance().configure(records.path.get_base_dir().path_join("language.json"))
	var direct: bool = false
	var capture_screen: String = "tracks"
	for argument: String in OS.get_cmdline_user_args():
		if argument.begins_with("--track=") or argument == "--demo": direct = true
		if argument.begins_with("--capture="): capture_path = argument.trim_prefix("--capture=")
		if argument.begins_with("--screen="): capture_screen = argument.trim_prefix("--screen=")
	if direct:
		game = GAME_SCENE.instantiate()
		add_child(game)
		return
	guest_records = records
	guest_library = library
	_tutorial_existing_save = FileAccess.file_exists(records.path) or FileAccess.file_exists(records.path+".bak")
	profile_root = records.path.get_base_dir()
	records.load_records()
	GameSoundtrack.instance().apply_settings(records.settings)
	GameSoundtrack.instance().show_menu()
	library.owner_name = "Guest"
	online = AccountController.new()
	online.client.session_path = records.path.get_base_dir().path_join("account_session.cfg")
	if OS.is_debug_build() and OS.get_environment("BMT_PURCHASE_LAB") == "true":
		online.client.session_path = records.path.get_base_dir().path_join("purchase_lab_session.cfg")
	add_child(online)
	online.client.resume_recovery.background_allowed = _background_work_allowed
	race_ad_breaks = preload("res://platform/race_ad_breaks.gd").new()
	race_ad_breaks.client = online.client
	race_ad_breaks.storage_path = profile_root.path_join("ad_cadence.json")
	race_ad_breaks.blocking_changed.connect(_ad_blocking_changed)
	add_child(race_ad_breaks)
	cosmetic_economy = preload("res://backend/cosmetic_economy.gd").new()
	cosmetic_economy.records = records
	cosmetic_economy.client = online.client
	cosmetic_economy.background_allowed = _background_work_allowed
	add_child(cosmetic_economy)
	appearance_sync = preload("res://backend/appearance_sync.gd").new()
	appearance_sync.client = online.client
	appearance_sync.refresh_allowed = _background_work_allowed
	add_child(appearance_sync)
	appearance_sync.bind_records(records)
	appearance_sync.changed.connect(_garage_appearance_changed)
	header_car_cache = preload("res://ui/header_car_appearance_cache.gd").new()
	header_car_cache.allowed = _header_car_capture_allowed
	header_car_cache.changed.connect(_header_car_picture_ready)
	add_child(header_car_cache)
	header_car_cache.bind_records(records)
	achievements = preload("res://backend/achievements_client.gd").new()
	achievements.client = online.client
	achievements.refresh_allowed = _background_work_allowed
	achievements.records = records
	achievements.directory = profile_root.path_join("achievement_cache")
	add_child(achievements)
	achievements.sync_identity()
	product_telemetry = ProductTelemetry.new()
	product_telemetry.client = online.client
	product_telemetry.enabled = bool(records.settings.get("optional_analytics",false))
	online.client.analytics_opt_in = product_telemetry.enabled
	product_telemetry.storage_path = profile_root.path_join("product_telemetry.json")
	product_telemetry.observations_due.connect(_telemetry_observe_activity)
	add_child(product_telemetry)
	game_configuration = preload("res://backend/game_configuration.gd").new()
	game_configuration.client = online.client
	game_configuration.telemetry = product_telemetry
	product_telemetry.configuration = game_configuration
	game_configuration.storage_path = profile_root.path_join("game_configuration.json")
	online.client.game_configuration = game_configuration
	game_configuration.changed.connect(_remote_config_changed)
	game_configuration.rewarded_presented.connect(race_ad_breaks.rewarded_presented)
	add_child(game_configuration)
	race_ad_breaks.permission = game_configuration.permission
	online.account_removed.connect(_erase_removed_account)
	client_quality = preload("res://backend/client_quality.gd").new()
	client_quality.telemetry = product_telemetry
	client_quality.app = self
	add_child(client_quality)
	cloud = preload("res://backend/cloud_tracks.gd").new()
	cloud.changed.connect(_prime_free_race_comparisons)
	cloud.race_verified.connect(achievements.refresh_after_activity)
	cloud.client = online.client
	cloud.background_allowed = _background_work_allowed
	cloud.root_override = cloud_root_override
	add_child(cloud)
	cloud.load_cached()
	rivalry = preload("res://backend/weekly_rivalry_client.gd").new()
	rivalry.client = online.client
	rivalry.result_poll_allowed = _result_poll_allowed.bind("rivalry")
	rivalry.appearance_sync = appearance_sync.refresh
	rivalry.appearance_provider = func(id: String) -> Dictionary:
		return {"vehicle_id":id,"livery":VehicleLivery.for_car(records.settings,id),"customisation":VehicleCustomisation.for_car(records.settings,id)}
	rivalry.cache_directory = cloud.cache_root().path_join("menu/rivalry")
	add_child(rivalry)
	rivalry.changed.connect(_rivalry_changed)
	preload("res://backend/world_ranking_client.gd").for_client(online.client).circuit_requested.connect(_open_world_circuit)
	challenges = ChallengesClient.new()
	challenges.client = online.client
	challenges.result_poll_allowed = _result_poll_allowed.bind("challenges")
	challenges.cloud = cloud
	add_child(challenges)
	challenges.changed.connect(_challenges_changed)
	challenge_links = preload("res://platform/challenge_links.gd").new()
	add_child(challenge_links)
	challenge_links.invitation_received.connect(_receive_challenge)
	challenge_links.track_received.connect(_receive_track_link)
	challenge_links.results_share_failed.connect(_rivalry_share_failed)
	challenge_links.track_share_failed.connect(func(value: String) -> void: _notice("Couldn't open sharing. The track link was copied instead.\n"+value.get_slice("\n",value.get_slice_count("\n")-1)))
	var rivalry_timer := Timer.new()
	rivalry_timer.wait_time = 0.5
	rivalry_timer.autostart = true
	rivalry_timer.timeout.connect(func() -> void:
		if not _background_work_allowed(): return
		if challenges != null: challenges.poll_result()
		if screen == "challenges" and challenge_browsing and not is_instance_valid(game) and not challenges.busy:
			challenge_refresh_ticks += 1
			if challenge_refresh_ticks >= 60:
				challenge_refresh_ticks = 0
				challenges.refresh()
		if rivalry.busy or rivalry.model.sample or cloud_starting or is_instance_valid(race_loading): return
		if rivalry_result_pending: rivalry.poll_result()
		elif screen == "rivalry" and not is_instance_valid(game):
			rivalry_refresh_ticks += 1
			if rivalry_refresh_ticks >= 60:
				rivalry_refresh_ticks = 0
				rivalry.refresh())
	add_child(rivalry_timer)
	lifecycle = TrackLifecycle.new()
	lifecycle.cloud = cloud
	lifecycle.library = library
	lifecycle.records = records
	add_child(lifecycle)
	lifecycle.changed.connect(_lifecycle_changed)
	lifecycle.publication_accepted.connect(achievements.refresh_after_activity)
	var sync_timer := Timer.new()
	sync_timer.wait_time = 1.0
	sync_timer.autostart = true
	sync_timer.timeout.connect(func() -> void:
		if not online.busy and _background_work_allowed():
			_refresh_creation_slots()
			cloud.flush_outbox()
			if not is_instance_valid(game): lifecycle.process_jobs())
	add_child(sync_timer)
	online.changed.connect(_account_changed)
	VehicleCatalog.selected = VehicleCatalog.valid_id(str(records.settings.get("selected_car", "compact")))
	ui_touch_scale = float(records.settings.get("touch_scale", 1.0))
	ui_left_handed = bool(records.settings.get("left_handed", false))
	selected_track = NativeTrack.read("res://resources/tracks/" + BUILTIN_IDS[0] + ".json")
	var last: String = str(records.settings.get("last_track",""))
	if last in BUILTIN_IDS:
		selected_track = NativeTrack.read("res://resources/tracks/"+last+".json")
	elif last.begins_with("creator_"):
		var saved: Dictionary = library.load_document(last.trim_prefix("creator_"))
		if not saved.is_empty():
			var compiled: NativeTrack = TrackCompiler.compile(saved)
			if compiled != null: selected_track = compiled
	elif last.begins_with("cloud_"): _restore_cloud_selection(last)
	menu_layer = CanvasLayer.new()
	menu_layer.layer = 20
	add_child(menu_layer)
	publication_notification = preload("res://ui/publication_notification.gd").new()
	publication_notification.app = self
	publication_notification.open_requested.connect(_view_publication_notification)
	publication_notification.dismissed.connect(_dismiss_publication_notification)
	publication_notification.share_requested.connect(func(item: Dictionary) -> void: _share_track_link(item.receipt))
	menu_layer.add_child(publication_notification)
	publication_notification.set_entries(lifecycle.publication_notifications())
	var achievement_layer := CanvasLayer.new()
	achievement_layer.name = "AchievementOverlayLayer"
	achievement_layer.layer = 30
	add_child(achievement_layer)
	achievement_notification = preload("res://ui/achievement_notification.gd").new()
	achievement_notification.app = self
	achievement_notification.service = achievements
	achievement_layer.add_child(achievement_notification)
	_remember_publication_news()
	# Account/Race become usable without constructing an unrelated native Garage.
	# First Garage entry prepares one live showroom; carousel photos are cached.
	_show_screen("restoring")
	if not capture_path.is_empty():
		_show_screen(capture_screen)
	else:
		await online.start_session()
		_show_screen("rivalry" if online.profile_ready() else "account")
	startup_complete = true
	preload("res://ui/garage_preview_cache.gd").prefetch_catalogue(get_tree())
	_garage_preloader=preload("res://ui/garage_preloader.gd").new()
	_garage_preloader.app=self
	add_child(_garage_preloader)
	tutorial = preload("res://tutorial/tutorial_controller.gd").new()
	tutorial.app = self
	add_child(tutorial)
	if capture_path.is_empty() and online.profile_ready(): tutorial.offer()
	_telemetry_observe("menu_ready",{},"ready")
	_prefetch_discovery()
	_prefetch_rivalry()
	print("APP_READY")
	if OS.is_debug_build() and FileAccess.file_exists("user://mobile_probe.json"):
		var probe: Node = load("res://diagnostics/mobile_race_probe.gd").new()
		add_child(probe)
	if OS.is_debug_build() and FileAccess.file_exists("user://control_probe.json"):
		add_child(load("res://diagnostics/mobile_control_probe.gd").new())
	if OS.is_debug_build() and FileAccess.file_exists("user://menu_probe.json"):
		add_child(load("res://diagnostics/mobile_menu_probe.gd").new())
	if not capture_path.is_empty(): _capture()

func _show_screen(next: String) -> void:
	if next != "tracks" and discovery_provider != null: discovery_provider.comparisons.cancel_speculation()
	if appearance_sync != null and (next == "garage" or appearance_sync._needs_recovery()): appearance_sync.refresh_if_stale()
	if achievements != null: achievements.resume_pending()
	if game_configuration != null:
		game_configuration.set_transport_allowed(not is_instance_valid(game) or (game.get("track_session") != null and bool(game.get("track_session").finished)))
		game_configuration.enter_menu()
	# Normalize before deciding whether the retained shell can be promoted.
	if next == "play": next = "tracks"
	# Rebuilding the editor or returning from practice keeps its original parent.
	if next == "create" and screen != "create":
		editor_return_screen = "drafts" if screen == "drafts" else "biome"
		editor_return_draft_view = {}
		if screen == "drafts" and is_instance_valid(root_ui):
			var browser: Node = root_ui.find_child("DraftBrowser",true,false)
			if browser != null:
				editor_return_draft_view = {"directory":library.directory,"query":browser.query,"page":browser.page,"selected_id":str(browser.selection.get("id",""))}
				if browser.get_parent() is ScrollContainer: editor_return_draft_view.scroll = browser.get_parent().scroll_vertical
	if not _suspended_menu.is_empty() and _suspended_menu.records != records: _discard_suspended_menu()
	if next not in ["settings","profile","account","restoring","tracks","rivalry","challenges","daily","biome","garage","store"]: _discard_suspended_menu()
	if screen == "create" and next != "create": _flush_editor_writes()
	if next != "challenge_create" and is_instance_valid(_challenge_return_ui):
		_challenge_return_ui.queue_free()
		_challenge_return_ui = null
	if screen == "rivalry" and is_instance_valid(content): _remember_rivalry_standings(content)
	_close_race_loading()
	if challenge_racing and challenge_result_view and next not in ["challenges","challenge_create"] and is_instance_valid(game):
		remove_child(game)
		game.queue_free()
		game = null
		challenge_racing = false
		challenge_result_view = false
	if not is_instance_valid(game): GameSoundtrack.instance().show_menu()
	if rivalry_racing and rivalry_section in ["race_results", "result"] and next not in ["rivalry","challenge_create"] and is_instance_valid(game):
		remove_child(game)
		game.queue_free()
		game = null
		rivalry_racing = false
	if next in ["tracks","rivalry","challenges","daily","biome","garage","store"] and _restore_suspended_menu(next): return
	if next in ["settings","profile"] and is_instance_valid(menu_body_slot): _suspend_menu()
	_navigation_generation += 1
	_cancel_rivalry_entry()
	var drag_offset: float = menu_body.position.x if is_instance_valid(menu_body) and not is_zero_approx(menu_drag_offset) else 0.0
	_stop_menu_page_motion()
	menu_neighbors.clear()
	menu_neighbor_direction = 0
	var pages: Array[String] = ["tracks", "biome", "garage", "store"]
	var previous_page: String = "biome" if screen == "drafts" else "tracks" if screen in ["rivalry","challenges","daily"] else screen
	var next_page: String = "biome" if next == "drafts" else "tracks" if next in ["rivalry","challenges","daily"] else next
	var vertical_slide: bool = is_instance_valid(menu_body) and screen in RACE_MODE_PAGES and next in RACE_MODE_PAGES and screen != next
	var race_slide_height: float = menu_body_slot.size.y if vertical_slide else 0.0
	var rail_rect := Rect2()
	if vertical_slide:
		var old_rail: Control = menu_body.find_child("RaceModes",true,false)
		if old_rail != null: rail_rect = Rect2(old_rail.get_global_position()-menu_body_slot.get_global_position(),old_rail.size)
	var slide: bool = is_instance_valid(root_ui) and root_ui.is_visible_in_tree() and previous_page in pages and next_page in pages and previous_page != next_page
	slide = slide or vertical_slide
	var slide_direction: int = 1 if pages.find(next_page) > pages.find(previous_page) else -1
	if vertical_slide: slide_direction = signi(RACE_MODE_PAGES.find(next)-RACE_MODE_PAGES.find(screen))
	if drag_offset * slide_direction > 0.0: drag_offset = 0.0
	# A departing page does not need its preview. The single worker retires in
	# _process; a newly opened document supersedes its output without joining.
	if is_instance_valid(object_browser):
		object_browser_state={"category":object_browser.category,"recent":object_browser.recent.duplicate(),"current":object_browser.current,"placement":object_browser.placement,"stamp_scale":object_browser.stamp_scale,"stamp_span":object_browser.stamp_span}
	if is_instance_valid(canvas):
		if canvas.document.get("id","") == document.get("id",""): _stash_pending_tool()
		editor_view = {"zoom":canvas.zoom,"pan":canvas.pan,"mode":canvas.mode,"selected":canvas.selected,"selected_object":canvas.selected_object,"stamp_kind":canvas.stamp_kind,"stamp_scale":canvas.stamp_scale,"stamp_span":canvas.stamp_span,"stamp_container_color":canvas.stamp_container_color,"run_shape":canvas.run_shape,"free_run":canvas.free_run,"brush_surface":canvas.brush_surface,"brush_width":canvas.brush_width,"paint_mode":canvas.paint_mode,"brush_shape":canvas.brush_shape,"selected_piece":canvas.selected_piece}
	screen = next
	if screen == "store": _telemetry_observe("store_opened",{},str(_navigation_generation))
	canvas = null
	editor_status = null
	test_button = null
	share_button = null
	if is_instance_valid(root_ui):
		if is_instance_valid(_retained_profile_car) and root_ui.is_ancestor_of(_retained_profile_car):
			_retained_profile_car.hide()
			_retained_profile_car.reparent(self,false)
		if slide:
			outgoing_menu_page = menu_body
			var departing_size: Vector2 = outgoing_menu_page.size
			outgoing_menu_page.set_anchors_preset(Control.PRESET_TOP_LEFT)
			outgoing_menu_page.size = departing_size
			outgoing_menu_page.position.x = drag_offset
			outgoing_menu_page.get_parent().remove_child(outgoing_menu_page)
			outgoing_menu_page.process_mode = Node.PROCESS_MODE_DISABLED
			_disable_outgoing_menu(outgoing_menu_page)
		if is_instance_valid(_retained_garage) and root_ui.is_ancestor_of(_retained_garage): _park_garage()
		_park_rivalry_page(root_ui)
		menu_layer.remove_child(root_ui)
		root_ui.queue_free()
	menu_body = null
	menu_body_slot = null
	menu_body_backgrounds = []
	root_ui = Control.new()
	root_ui.clip_contents = true
	MenuStyle.fill(root_ui)
	root_ui.theme = MenuStyle.theme()
	menu_layer.add_child(root_ui)
	if screen in ["tracks", "rivalry", "challenges", "daily", "biome", "drafts", "garage", "store"]:
		var swipe := preload("res://ui/menu_page_swipe.gd").new()
		swipe.name = "MenuPageSwipe"
		swipe.menu = root_ui
		swipe.modal_root = self
		swipe.page_requested.connect(_swipe_menu_page)
		swipe.gesture_started.connect(_stop_menu_edge_motion)
		swipe.drag_changed.connect(_drag_menu_edge)
		swipe.drag_finished.connect(_settle_menu_edge)
		swipe.settle_requested.connect(_settle_menu_before_touch)
		root_ui.add_child(swipe)
	if screen == "restoring":
		account_button = null
		var backdrop := ColorRect.new()
		backdrop.color = Color("101a26")
		MenuStyle.fill(backdrop)
		root_ui.add_child(backdrop)
		var center := CenterContainer.new()
		MenuStyle.fill(center)
		root_ui.add_child(center)
		var column := VBoxContainer.new()
		column.add_theme_constant_override("separation", 24)
		center.add_child(column)
		column.add_child(MenuBrand.new())
		var loading := MenuStyle.label("Loading...", 20, true)
		loading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		column.add_child(loading)
		return
	if screen == "account":
		account_button = null
		_account()
		return
	if screen == "create":
		_editor()
		return
	var background := MenuBackdrop.new()
	MenuStyle.fill(background)
	root_ui.add_child(background)
	var scenery: Array[Control] = []
	var margin := MarginContainer.new()
	MenuStyle.fill(margin)
	for side: String in ["left", "right", "top", "bottom"]: margin.add_theme_constant_override("margin_" + side, 20)
	if OS.has_feature("mobile"):
		var safe: Rect2i = DisplayServer.get_display_safe_area()
		var window: Vector2i = DisplayServer.window_get_size()
		var factor: float = get_viewport().get_visible_rect().size.y / maxf(1.0, window.y)
		margin.add_theme_constant_override("margin_left", maxi(24, ceili(safe.position.x * factor)))
		margin.add_theme_constant_override("margin_right", maxi(24, ceili((window.x - safe.end.x) * factor)))
		margin.add_theme_constant_override("margin_top", maxi(20, ceili(safe.position.y * factor)))
		margin.add_theme_constant_override("margin_bottom", maxi(20, ceili((window.y - safe.end.y) * factor)))
	root_ui.add_child(margin)
	var layout := VBoxContainer.new()
	layout.add_theme_constant_override("separation", 12)
	margin.add_child(layout)
	var nav := HBoxContainer.new()
	nav.name = "MenuHeader"
	layout.add_child(nav)
	var menu_brand := MenuBrand.new()
	menu_brand.logo_scale = 0.84
	nav.add_child(menu_brand)
	var tabs := HBoxContainer.new()
	tabs.name = "MenuNavigation"
	tabs.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tabs.add_theme_constant_override("separation", 4)
	nav.add_child(tabs)
	for item: Array in [["tracks","RACE"],["create","CREATE"],["garage","GARAGE"],["store","STORE"]]:
		var id: String = item[0]
		var button: Button = MenuStyle.tab(item[1], _new_document if id == "create" else _open_race_area if id == "tracks" else _navigate_menu_page.bind(id), screen == id or (id == "tracks" and screen in ["rivalry","challenges","daily","challenge_create"]) or (id == "create" and screen in ["biome","drafts"]))
		button.name = "Tab_" + id
		button.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
		button.custom_minimum_size.y = 64
		button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		tabs.add_child(button)
	account_button = MenuStyle.button(online.player_name() if online.client.signed_in() else "Guest", _show_screen.bind("profile"))
	if online.client.signed_in(): GameText.user_text(account_button)
	account_button.name = "MenuAccount"
	account_button.tooltip_text = "Profile"
	account_button.alignment = HORIZONTAL_ALIGNMENT_LEFT
	account_button.custom_minimum_size = Vector2(240, 64)
	var profile_style: StyleBoxFlat = MenuStyle.box(MenuStyle.PANEL)
	profile_style.content_margin_left = 104
	profile_style.content_margin_right = 16
	if screen == "profile":
		profile_style.bg_color = Color(1, 1, 1, 0.07)
		account_button.add_theme_color_override("font_color", MenuStyle.ACCENT)
	account_button.add_theme_stylebox_override("normal", profile_style)
	for state: String in ["hover", "pressed", "disabled", "focus"]:
		var state_style: StyleBoxFlat = root_ui.theme.get_stylebox(state, "Button").duplicate() as StyleBoxFlat
		state_style.content_margin_left = 104
		state_style.content_margin_right = 16
		account_button.add_theme_stylebox_override(state, state_style)
	var car_picker := preload("res://ui/header_car_picker.gd").new()
	if header_car_cache != null: header_car_cache.bind_records(records)
	car_picker.records = records
	car_picker.vehicle_selected.connect(_select_header_vehicle)
	account_button.add_child(car_picker)
	car_picker.set_anchors_and_offsets_preset(Control.PRESET_LEFT_WIDE)
	car_picker.offset_right = 100
	if is_instance_valid(_retained_profile_car) and _retained_profile_car.records != records:
		_retained_profile_car.free()
	if not is_instance_valid(_retained_profile_car):
		_retained_profile_car = preload("res://ui/profile_car.gd").new()
	var profile_car: Control = _retained_profile_car
	profile_car.name = "MenuProfileCar"
	profile_car.records = records
	_attach_profile_car(account_button)
	account_button.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	# Let the name contribute to the minimum width; expanding tabs yield space.
	account_button.clip_text = false
	nav.add_child(account_button)
	var settings: Button = MenuStyle.button("",_show_screen.bind("settings"))
	settings.icon = MenuIcon.texture("gear")
	settings.tooltip_text = "Settings"
	if screen == "settings":
		var selected_style: StyleBoxFlat = MenuStyle.box(Color(1, 1, 1, 0.07))
		settings.add_theme_stylebox_override("normal", selected_style)
		settings.add_theme_color_override("icon_normal_color", MenuStyle.ACCENT)
	settings.name = "MenuSettings"
	settings.custom_minimum_size = Vector2(54,54)
	settings.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	nav.add_child(settings)
	layout.add_child(HSeparator.new())
	content = VBoxContainer.new()
	content.size_flags_vertical = Control.SIZE_EXPAND_FILL
	if screen in ["tracks", "rivalry", "challenges", "daily", "biome", "drafts", "garage", "store"]:
		menu_body_slot = Control.new()
		menu_body_slot.name = "MenuContentViewport"
		menu_body_slot.clip_contents = true
		menu_body_slot.size_flags_vertical = Control.SIZE_EXPAND_FILL
		layout.add_child(menu_body_slot)
		if is_instance_valid(outgoing_menu_page): menu_body_slot.add_child(outgoing_menu_page)
		menu_body = Control.new()
		menu_body.name = "MenuContentPage"
		menu_body.clip_contents = true
		MenuStyle.fill(menu_body)
		menu_body_slot.add_child(menu_body)
		var body_background := MenuBackdrop.new()
		menu_body.add_child(body_background)
		menu_body_backgrounds.append(body_background)
		for item: Control in scenery:
			item.reparent(menu_body, false)
			menu_body_backgrounds.append(item)
		MenuStyle.fill(content)
		menu_body.add_child(content)
		menu_body_slot.resized.connect(_layout_menu_body)
		_layout_menu_body()
	else: layout.add_child(content)
	match screen:
		"drafts": _drafts()
		"biome": _choose_biome()
		"tracks": _tracks()
		"daily": _track_of_day()
		"rivalry": _rivalry()
		"challenges": _challenges()
		"challenge_create": pass
		"create": _editor()
		"garage": _garage()
		"settings": _settings()
		"store":
			var store := preload("res://ui/store_page.gd").new()
			store.client = online.client
			if game_configuration != null: store.offer_order = game_configuration.settings.store_order.duplicate()
			store.sign_in_requested.connect(_open_account)
			_connect_store_telemetry(store)
			content.add_child(store)
		"profile":
			content.add_child(MenuStyle.label("PROFILE",36))
			var manage := MenuStyle.button("Manage account" if online.client.signed_in() else "Sign in",_open_account)
			manage.name = "ManageAccount"
			content.add_child(manage)
			if online.client.signed_in(): content.add_child(MenuStyle.button("Race uploads",cloud.show_uploads.bind(root_ui)))
			if online.client.signed_in() and preload("res://backend/world_ranking_client.gd").supported(online.client):
				content.add_child(MenuStyle.button("World Ranking",func() -> void: preload("res://ui/world_ranking.gd").open(root_ui,online.client)))
			var featured_text: String = ""
			for f: Dictionary in AchievementProgress.catalog().families:
				if achievements != null and f.id in achievements.featured(): featured_text += ("  ·  " if not featured_text.is_empty() else "")+str(f.title)
			var badges: Label = MenuStyle.label(featured_text if not featured_text.is_empty() else "Choose featured achievements in your Trophy Room",22,true)
			badges.name = "ProfileAchievements"
			badges.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			content.add_child(badges)
			content.add_child(MenuStyle.button("Trophy Room",func() -> void:
				_show_screen("garage")
				if is_instance_valid(_retained_garage): _retained_garage._show_section("trophies")))
		"account": _account()
		_: _tracks()
	var page_swipe: Node = root_ui.get_node_or_null("MenuPageSwipe")
	_remote_menu_notice()
	# _input visits children in reverse order: settle before the carousel hit-tests.
	if page_swipe != null: root_ui.move_child(page_swipe, root_ui.get_child_count() - 1)
	if vertical_slide: _slide_race_mode_page(slide_direction,rail_rect,race_slide_height)
	elif slide: _slide_menu_page(slide_direction, drag_offset)
	else: _prepare_menu_neighbors.call_deferred(_navigation_generation)

func _attach_profile_car(parent: Control) -> void:
	var view: Control = _retained_profile_car
	if view.get_parent() != null: view.reparent(parent,false)
	else: parent.add_child(view)
	# Resolve anchors against the destination button. While parked beneath App,
	# a Control resolves its anchors against the entire viewport instead.
	view.set_anchors_preset(Control.PRESET_CENTER_LEFT)
	view.offset_left = 6
	view.offset_right = 94
	view.offset_top = -28
	view.offset_bottom = 28
	view.clip_contents = true
	view.show()
	view.refresh()
	if is_instance_valid(view.preview): MenuStyle.fill(view.preview)

func _layout_menu_body() -> void:
	if not is_instance_valid(menu_body_slot): return
	# Keep the established full-screen scenic framing, clipped below the header.
	var inset: Vector2 = menu_body_slot.get_global_position() - root_ui.get_global_position()
	var backgrounds: Array[Control] = menu_body_backgrounds.duplicate()
	for neighbor: Dictionary in menu_neighbors.values(): backgrounds.append_array(neighbor.backgrounds)
	for background: Control in backgrounds:
		background.set_anchors_preset(Control.PRESET_TOP_LEFT)
		background.position = -inset
		background.size = root_ui.size

func _suspend_menu() -> void:
	if not _suspended_menu.is_empty(): return
	_stop_menu_page_motion()
	_suspended_menu = {"root":root_ui,"body":menu_body,"slot":menu_body_slot,"backgrounds":menu_body_backgrounds,"neighbors":menu_neighbors.duplicate(),"content":content,"screen":screen,"records":records}
	root_ui.hide()
	root_ui.process_mode = Node.PROCESS_MODE_DISABLED
	_hide_outgoing_layers(root_ui)
	root_ui = null
	menu_body = null
	menu_body_slot = null
	menu_body_backgrounds = []
	menu_neighbors = {}
	content = null

func _discard_suspended_menu() -> void:
	if _suspended_menu.is_empty(): return
	var previous: Control = _suspended_menu.root
	if is_instance_valid(previous):
		if is_instance_valid(_retained_garage) and previous.is_ancestor_of(_retained_garage): _park_garage()
		_park_rivalry_page(previous)
		previous.queue_free()
	_suspended_menu = {}

func _restore_suspended_menu(destination: String) -> bool:
	if _suspended_menu.is_empty(): return false
	_navigation_generation += 1
	_cancel_rivalry_entry()
	_stop_menu_page_motion()
	if is_instance_valid(root_ui):
		if is_instance_valid(_retained_profile_car) and root_ui.is_ancestor_of(_retained_profile_car):
			_retained_profile_car.hide()
			_retained_profile_car.reparent(self,false)
		_park_rivalry_page(root_ui)
		root_ui.get_parent().remove_child(root_ui)
		root_ui.queue_free()
	root_ui = _suspended_menu.root
	menu_body = _suspended_menu.body
	menu_body_slot = _suspended_menu.slot
	menu_body_backgrounds = _suspended_menu.backgrounds
	menu_neighbors = _suspended_menu.neighbors
	content = _suspended_menu.content
	screen = _suspended_menu.screen
	_suspended_menu = {}
	root_ui.process_mode = Node.PROCESS_MODE_INHERIT
	root_ui.show()
	content.queue_sort()
	account_button = root_ui.find_child("MenuAccount",true,false)
	if is_instance_valid(account_button):
		account_button.text = online.player_name() if online.client.signed_in() else "Guest"
		if is_instance_valid(_retained_profile_car):
			_attach_profile_car(account_button)
	_layout_menu_body()
	_navigate_menu_page(destination)
	_activate_menu_page.call_deferred(_navigation_generation)
	_prepare_menu_neighbors.call_deferred(_navigation_generation)
	return true

func _disable_outgoing_menu(node: Node) -> void:
	_set_menu_preview_input(node,true)
	_hide_outgoing_layers(node)

func _hide_outgoing_layers(node: Node) -> void:
	if node is CanvasLayer: node.hide()
	for child: Node in node.get_children(): _hide_outgoing_layers(child)

func _stop_menu_page_motion() -> void:
	_stop_menu_edge_motion()
	if menu_page_motion != null:
		menu_page_motion.kill()
		menu_page_motion = null
	if is_instance_valid(race_mode_transition_rail):
		race_mode_transition_rail.get_parent().remove_child(race_mode_transition_rail)
		race_mode_transition_rail.queue_free()
		race_mode_transition_rail = null
	if is_instance_valid(menu_body):
		var rail: Control = menu_body.find_child("RaceModes",true,false)
		if rail != null: rail.modulate.a = 1.0
	if is_instance_valid(outgoing_menu_page):
		if not returning_menu_neighbor.is_empty():
			outgoing_menu_page.hide()
			menu_neighbors[int(returning_menu_neighbor.direction)] = returning_menu_neighbor
		else:
			if is_instance_valid(_retained_garage) and outgoing_menu_page.is_ancestor_of(_retained_garage): _park_garage()
			_park_rivalry_page(outgoing_menu_page)
			if outgoing_menu_page.get_parent() != null:
				outgoing_menu_page.get_parent().remove_child(outgoing_menu_page)
			outgoing_menu_page.queue_free()
		outgoing_menu_page = null
	returning_menu_neighbor = {}
	if is_instance_valid(root_ui):
		if is_instance_valid(menu_body): menu_body.position = Vector2.ZERO
		var swipe: Node = root_ui.get_node_or_null("MenuPageSwipe")
		if swipe != null: swipe.set_process_input(true)

func _slide_menu_page(direction: int, drag_offset: float = 0.0) -> void:
	# A freshly built shell has not had its first container layout yet.
	var width: float = menu_body_slot.size.x
	if width <= 0.0:
		var margin: MarginContainer = menu_body_slot.get_parent().get_parent()
		width = get_viewport().get_visible_rect().size.x - margin.get_theme_constant("margin_left") - margin.get_theme_constant("margin_right")
	var gap: float = _menu_page_gap(drag_offset) if not is_zero_approx(drag_offset) else MENU_PAGE_GAP
	var distance: float = (width + gap) * direction
	menu_body.position.x = distance + drag_offset
	# A new press settles this tween before any content hit-test, so rapid swipes
	# remain responsive and the track carousel still owns its final rectangle.
	menu_page_motion = create_tween().set_parallel(true)
	menu_page_motion.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	var duration: float = clampf(0.32 * (1.0 - absf(drag_offset) / absf(distance)), 0.18, 0.32)
	menu_page_motion.tween_property(menu_body, "position:x", 0.0, duration)
	menu_page_motion.tween_property(outgoing_menu_page, "position:x", -distance, duration)
	menu_page_motion.chain().tween_callback(_finish_menu_page_slide)

func _slide_race_mode_page(direction: int, rail_rect: Rect2, height: float) -> void:
	# The rail stays anchored while the two real page bodies roll vertically.
	for body: Control in [menu_body,outgoing_menu_page]:
		var rail: Control = body.find_child("RaceModes",true,false)
		if rail != null: rail.modulate.a = 0.0
	if rail_rect.has_area():
		race_mode_transition_rail = RaceModeRail.new()
		race_mode_transition_rail.selected = "free" if screen == "tracks" else screen
		race_mode_transition_rail.mode_requested.connect(_request_race_mode)
		menu_body_slot.add_child(race_mode_transition_rail)
		race_mode_transition_rail.name = "RaceModeTransitionRail"
		race_mode_transition_rail.position = rail_rect.position
		race_mode_transition_rail.size = rail_rect.size
	# Capture the departing viewport before reparenting clears anchored sizes.
	var distance: float = (height+MENU_PAGE_GAP)*direction
	menu_body.position.y = distance
	menu_page_motion = create_tween().set_parallel(true)
	menu_page_motion.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	menu_page_motion.tween_property(menu_body,"position:y",0.0,0.32)
	menu_page_motion.tween_property(outgoing_menu_page,"position:y",-distance,0.32)
	menu_page_motion.chain().tween_callback(_finish_menu_page_slide)
	var page: WeeklyRivalryPage = content.find_child("WeeklyRivalryPage",true,false)
	if page != null and not page.standings_ready:
		menu_page_motion.pause()
		_start_prepared_race_mode.call_deferred(_navigation_generation,menu_page_motion)

func _start_prepared_race_mode(generation: int, motion: Tween) -> void:
	# Set the initial table scroll while the incoming page is still offscreen.
	while generation == _navigation_generation and motion == menu_page_motion:
		var page: WeeklyRivalryPage = content.find_child("WeeklyRivalryPage",true,false)
		if page == null or page.standings_ready:
			motion.play()
			return
		await get_tree().process_frame

func _request_race_mode(mode: String) -> void:
	if mode == "rivalry": _open_rivalry()
	elif mode == "challenges": _open_challenges()
	elif mode == "free": _open_free_race()
	elif mode == "daily": _open_track_of_day()

func _open_track_of_day() -> void:
	_cancel_rivalry_entry()
	race_area_mode = "daily"
	_navigate_menu_page("daily")

func _track_of_day(parent: Control = null, preview: bool = false) -> void:
	if parent == null: parent = content
	var page := preload("res://ui/track_of_day_page.gd").new()
	page.client = online.client
	page.cloud = cloud
	page.page_preview = preview
	page.mode_requested.connect(_request_race_mode)
	page.vehicle_selected.connect(_select_vehicle)
	page.race_requested.connect(func(entry: Dictionary) -> void:
		selected_track = cloud.presentation_track(entry)
		_start_race(selected_track,false))
	parent.add_child(page)
	_keep_race_mode_rail_fixed(page)

func _keep_race_mode_rail_fixed(page: Control) -> void:
	if not is_instance_valid(race_mode_transition_rail) or not menu_body.is_ancestor_of(page): return
	var rail: Control = page.find_child("RaceModes",true,false)
	if rail != null: rail.modulate.a = 0.0

func _open_free_race() -> void:
	_cancel_rivalry_entry()
	race_area_mode = "free"
	_navigate_menu_page("tracks")

func _stop_menu_edge_motion() -> void:
	if menu_edge_motion != null:
		menu_edge_motion.kill()
		menu_edge_motion = null
	if is_instance_valid(menu_body):
		menu_body.position.x = 0.0
		_set_menu_preview_input(menu_body, false)
	menu_drag_offset = 0.0
	menu_neighbor_direction = 0
	for neighbor: Dictionary in menu_neighbors.values():
		if is_instance_valid(neighbor.body): neighbor.body.hide()

func _drag_menu_edge(distance: float) -> void:
	if not is_instance_valid(menu_body): return
	# The page owns this horizontal gesture until it settles. No button on its
	# moving content may accept a parallel platform input and rebuild the page.
	_set_menu_preview_input(menu_body, true)
	var direction: int = 1 if distance < 0.0 else -1
	menu_neighbor_direction = direction
	for neighbor_direction: int in menu_neighbors:
		menu_neighbors[neighbor_direction].body.visible = neighbor_direction == direction
	if (screen in ["tracks", "rivalry", "challenges", "daily"] and distance > 0.0) or (screen == "store" and distance < 0.0):
		# Match the track carousel's bounded resistance, followed by its spring return.
		menu_body.position.x = signf(distance) * 64.0 * (1.0 - exp(-absf(distance) / 160.0))
		menu_drag_offset = 0.0
	else:
		var width: float = menu_body_slot.size.x
		menu_drag_offset = clampf(distance, -width, width)
		menu_body.position.x = menu_drag_offset
		if menu_neighbors.has(direction):
			menu_neighbors[direction].body.position.x = (width + _menu_page_gap(menu_drag_offset)) * direction + menu_drag_offset

func _menu_page_gap(distance: float) -> float:
	# A growing gutter leaves the next page visible even on the first small pull.
	return minf(MENU_PAGE_GAP, absf(distance) * 0.5)

func _settle_menu_edge() -> void:
	if not is_instance_valid(menu_body): return
	if is_zero_approx(menu_body.position.x):
		_set_menu_preview_input(menu_body, false)
		return
	if menu_edge_motion != null: menu_edge_motion.kill()
	menu_edge_motion = create_tween().set_parallel(true)
	var edge: bool = is_zero_approx(menu_drag_offset)
	if edge:
		menu_edge_motion.tween_property(menu_body, "position:x", 0.0, 0.38).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	else:
		# One progress value keeps both pages and their gutter together. Smootherstep
		# has zero velocity and acceleration at each end, avoiding a release kick.
		var duration: float = 0.42 + 0.10 * minf(1.0, absf(menu_drag_offset) / menu_body_slot.size.x)
		var neighbor: Control = menu_neighbors[menu_neighbor_direction].body if menu_neighbors.has(menu_neighbor_direction) else null
		var neighbor_start: float = neighbor.position.x if is_instance_valid(neighbor) else 0.0
		menu_edge_motion.tween_method(_return_menu_drag.bind(menu_body.position.x, neighbor, neighbor_start, menu_body_slot.size.x * menu_neighbor_direction), 0.0, 1.0, duration)
	menu_edge_motion.chain().tween_callback(func() -> void:
		menu_edge_motion = null
		_set_menu_preview_input(menu_body, false)
		menu_drag_offset = 0.0
		menu_neighbor_direction = 0
		for neighbor: Dictionary in menu_neighbors.values(): neighbor.body.hide())

func _return_menu_drag(progress: float, start: float, neighbor: Control, neighbor_start: float, neighbor_end: float) -> void:
	var blend: float = progress * progress * progress * (progress * (progress * 6.0 - 15.0) + 10.0)
	if is_instance_valid(menu_body): menu_body.position.x = lerpf(start, 0.0, blend)
	if is_instance_valid(neighbor): neighbor.position.x = lerpf(neighbor_start, neighbor_end, blend)

func _prepare_menu_neighbors(generation: int) -> void:
	# A signal callback drops safely with its owner; a suspended method cannot
	# resume after app teardown. Race loading also cancels unnecessary page work.
	if generation != _navigation_generation or not is_inside_tree(): return
	var callback: Callable = _prepare_menu_neighbors_frame.bind(generation)
	if not get_tree().process_frame.is_connected(callback):
		get_tree().process_frame.connect(callback,CONNECT_ONE_SHOT)

func _prepare_menu_neighbors_frame(generation: int) -> void:
	if cloud_starting or is_instance_valid(game) or not root_ui.visible: return
	if generation != _navigation_generation or not is_instance_valid(menu_body_slot): return
	if menu_page_motion != null: return
	var swipe: Node = root_ui.get_node_or_null("MenuPageSwipe")
	if swipe == null: return
	if swipe.pointer != -1:
		_prepare_menu_neighbors.call_deferred(generation)
		return
	var pages: Array[String] = ["tracks", "biome", "garage", "store"]
	var current: String = "biome" if screen == "drafts" else "tracks" if screen in ["rivalry","challenges","daily"] else screen
	var index: int = pages.find(current)
	if index < 0: return
	# Publish at most one real swipe neighbor per frame. Only retained Garage
	# pages participate; entering a cold Garage uses the
	# normal menu transition, without a separate restoring/loading screen.
	for destination: int in range(pages.size()):
		var direction: int = destination - index
		if direction == 0: continue
		if menu_neighbors.has(direction): continue
		var next: String = pages[destination]
		# Preparing an offscreen neighbor must not construct the native Garage.
		# Its first visible entry uses the ordinary cover; subsequent visits reuse it.
		if next == "garage" and (not is_instance_valid(_retained_garage) or _retained_garage.records != records): continue
		if next == "tracks" and race_area_mode == "rivalry": next = "rivalry"
		elif next == "tracks" and race_area_mode == "challenges": next = "challenges"
		elif next == "tracks" and race_area_mode == "daily": next = "daily"
		var body := Control.new()
		body.name = "AdjacentMenuPage"
		MenuStyle.fill(body)
		body.clip_contents = true
		body.process_mode = Node.PROCESS_MODE_DISABLED
		menu_body_slot.add_child(body)
		body.position.x = menu_body_slot.size.x * direction
		var backgrounds: Array[Control] = []
		var background := MenuBackdrop.new()
		body.add_child(background)
		backgrounds.append(background)
		var column := VBoxContainer.new()
		MenuStyle.fill(column)
		body.add_child(column)
		match next:
			"tracks": _tracks(column, true)
			"daily": _track_of_day(column, true)
			"rivalry": _rivalry(column)
			"challenges": _challenges(column)
			"biome": _choose_biome(column, true)
			"garage": _garage(column)
			"store":
				var store := preload("res://ui/store_page.gd").new()
				store.page_preview = true
				store.client = online.client
				store.sign_in_requested.connect(_open_account)
				_connect_store_telemetry(store)
				column.add_child(store)
		_set_menu_preview_input(body, true)
		menu_neighbors[direction] = {"body":body,"content":column,"backgrounds":backgrounds,"screen":next}
		body.position.x = menu_body_slot.size.x * direction
		_layout_menu_body()
		_prepare_menu_neighbors.call_deferred(generation)
		break
	_hide_warmed_menu_neighbors.call_deferred(generation)

func _hide_warmed_menu_neighbors(generation: int) -> void:
	if generation != _navigation_generation or not is_inside_tree(): return
	var callback: Callable = _hide_warmed_menu_neighbors_frame.bind(generation)
	if not get_tree().process_frame.is_connected(callback):
		get_tree().process_frame.connect(callback,CONNECT_ONE_SHOT)

func _hide_warmed_menu_neighbors_frame(generation: int) -> void:
	if generation != _navigation_generation: return
	var swipe: Node = root_ui.get_node_or_null("MenuPageSwipe")
	if swipe != null and swipe.pointer != -1: return
	for neighbor: Dictionary in menu_neighbors.values(): neighbor.body.hide()

func _set_menu_preview_input(node: Node, disabled: bool) -> void:
	var control := node as Control
	if control == null: return
	# The pinned engine propagates these overrides natively. Keep descendant
	# mouse/focus preferences intact instead of rewriting hundreds of controls.
	control.mouse_behavior_recursive = Control.MOUSE_BEHAVIOR_DISABLED if disabled else Control.MOUSE_BEHAVIOR_INHERITED
	control.focus_behavior_recursive = Control.FOCUS_BEHAVIOR_DISABLED if disabled else Control.FOCUS_BEHAVIOR_INHERITED
	if disabled and not control.has_meta("page_mouse_filter"):
		var garage: GaragePage = control.find_child("GaragePage",true,false) as GaragePage
		if garage != null and is_instance_valid(garage._preview_service): garage._preview_service.suspend_previews()
		control.set_meta("page_mouse_filter",control.mouse_filter)
		control.mouse_filter = Control.MOUSE_FILTER_IGNORE
	elif not disabled and control.has_meta("page_mouse_filter"):
		control.mouse_filter = control.get_meta("page_mouse_filter")
		control.remove_meta("page_mouse_filter")

func _commit_menu_neighbor(direction: int) -> void:
	if screen == "rivalry": _remember_rivalry_standings(content)
	var neighbor: Dictionary = menu_neighbors[direction]
	if neighbor.screen == "rivalry": _reset_rivalry_entry_view()
	_refresh_cached_menu_page(neighbor.screen, neighbor.content)
	var offset: float = menu_body.position.x
	_stop_menu_page_motion()
	menu_neighbors.erase(direction)
	# Keep the prepared page and the header alive. Commitment only changes ownership
	# and animates the remaining distance; no page construction runs under the finger.
	outgoing_menu_page = menu_body
	outgoing_menu_page.position.x = offset
	outgoing_menu_page.process_mode = Node.PROCESS_MODE_DISABLED
	_set_menu_preview_input(outgoing_menu_page, true)
	returning_menu_neighbor = {"body":menu_body,"content":content,"backgrounds":menu_body_backgrounds,"screen":screen,"direction":-direction}
	var outgoing_browser: TrackBrowser = outgoing_menu_page.find_child("TrackBrowser", true, false)
	if outgoing_browser != null: outgoing_browser.page_preview = true
	menu_body = neighbor.body
	menu_body.show()
	menu_body.process_mode = Node.PROCESS_MODE_INHERIT
	_set_menu_preview_input(menu_body, false)
	content = neighbor.content
	menu_body_backgrounds = neighbor.backgrounds
	var remaining: Dictionary = {}
	for old_direction: int in menu_neighbors:
		remaining[old_direction - direction] = menu_neighbors[old_direction]
	menu_neighbors = remaining
	_navigation_generation += 1
	if rivalry_racing and rivalry_section in ["race_results", "result"] and neighbor.screen != "rivalry" and is_instance_valid(game):
		remove_child(game)
		game.queue_free()
		game = null
		rivalry_racing = false
	if challenge_racing and challenge_result_view and neighbor.screen != "challenges" and is_instance_valid(game):
		_clear_challenge_game()
		challenge_result_view = false
	screen = neighbor.screen
	if screen == "store": _telemetry_observe("store_opened",{},str(_navigation_generation))
	if screen == "biome" and document.is_empty():
		document = TrackDocument.create_blank()
		document.id = TrackLibrary.unique_id()
		_stamp_creator()
		history.clear()
		redo_history.clear()
	for id: String in ["tracks", "create", "garage", "store"]:
		var tab: Button = root_ui.find_child("Tab_" + id, true, false)
		var selected: bool = (id == "tracks" and screen in ["tracks", "rivalry"]) or (id == "create" and screen == "biome") or id == screen
		tab.add_theme_stylebox_override("normal", MenuStyle.box(Color(1,1,1,0.07) if selected else Color.TRANSPARENT,16))
		tab.add_theme_color_override("font_color", MenuStyle.ACCENT if selected else MenuStyle.MUTED)
	var browser: TrackBrowser = menu_body.find_child("TrackBrowser", true, false)
	if browser != null:
		browser_state = browser.state
	_slide_menu_page(signi(direction), offset)

func _refresh_cached_menu_page(destination: String, column: VBoxContainer) -> void:
	if game_configuration != null and column == content and destination == screen:
		game_configuration.enter_menu()
		_remote_menu_notice()
	if destination == "store":
		var store: Node = column.find_child("StorePage",true,false)
		if store != null: store.activate()
	elif destination == "rivalry":
		_rivalry(column)
	elif destination == "challenges":
		_challenges(column)
	elif destination == "daily":
		var daily: Node = column.find_child("TrackOfDayPage",true,false)
		if daily != null: daily.activate()
	elif destination == "garage":
		var garage: GaragePage = column.find_child("GaragePage",true,false) as GaragePage
		if garage != null:
			garage.refresh_selection()
			garage.circuit_title = track_title(selected_track).to_upper()
		var circuit: MenuFeature = column.find_child("GarageCircuit",true,false)
		if circuit != null:
			var title: String = track_title(selected_track).to_upper()
			if circuit.heading != title:
				circuit.heading = title
				circuit.tooltip_text = title+". "+circuit.description
				circuit.queue_redraw()
	elif destination == "biome" and str(column.get_meta("biome_theme","")) != str(document.get("theme",TrackDocument.THEMES[0])):
		_update_creation_biome(column,str(document.get("theme",TrackDocument.THEMES[0])))

func _navigate_menu_page(next: String) -> void:
	# Explicit refreshes still use _show_screen. User navigation promotes the same
	# already warmed controls as swipes, avoiding shell/layout rebuilding on taps.
	if next == "rivalry": _reset_rivalry_entry_view()
	if menu_page_motion != null: _finish_menu_page_slide()
	if not is_instance_valid(menu_body) or not menu_body.is_inside_tree() or not root_ui.is_ancestor_of(menu_body):
		_show_screen(next)
		return
	if next == screen and is_instance_valid(menu_body):
		_refresh_cached_menu_page(next,content)
		_set_menu_preview_input(menu_body,false)
		return
	for direction: int in menu_neighbors:
		if menu_neighbors[direction].screen == next:
			_commit_menu_neighbor(direction)
			return
	_show_screen(next)

func _finish_menu_page_slide() -> void:
	_stop_menu_page_motion()
	_activate_menu_page.call_deferred(_navigation_generation)
	_prepare_menu_neighbors.call_deferred(_navigation_generation)

func _settle_menu_before_touch() -> void:
	if menu_page_motion != null: _finish_menu_page_slide()
	if menu_edge_motion != null: _stop_menu_edge_motion()

func _activate_menu_page(generation: int) -> void:
	if generation != _navigation_generation or not is_instance_valid(menu_body): return
	var swipe: Node = root_ui.get_node_or_null("MenuPageSwipe")
	if menu_page_motion != null or (swipe != null and swipe.pointer != -1):
		await get_tree().process_frame
		if is_inside_tree(): _activate_menu_page.call_deferred(generation)
		return
	var browser: TrackBrowser = menu_body.find_child("TrackBrowser", true, false)
	if browser != null and browser.page_preview:
		browser.activate_page()
	if screen == "rivalry" and not cloud_starting and not is_instance_valid(race_loading) and not rivalry.model.sample and online.client.signed_in(): rivalry.refresh(false)
	if screen == "rivalry": _maybe_rivalry_summary.call_deferred()
	if screen == "challenges" and challenge_browsing: challenges.refresh()
	if screen == "daily":
		var daily: Node = menu_body.find_child("TrackOfDayPage",true,false)
		if daily != null: daily.activate()
	if screen == "store":
		var store: Node = menu_body.find_child("StorePage",true,false)
		if store != null: store.activate()

func _account_changed() -> void:
	if is_instance_valid(publication_notification):
		var empty_publications: Array[Dictionary] = []
		publication_notification.set_entries(empty_publications)
	if product_telemetry != null:
		product_telemetry.update_identity()
		if startup_complete: _telemetry_observe("menu_ready",{},"ready")
	var previous_profile: String = active_profile
	_select_player_storage()
	if cloud != null and previous_profile != active_profile: cloud.invalidate_outbox()
	if cosmetic_economy != null:
		cosmetic_economy.bind_records(records)
		cosmetic_economy.refresh()
	if appearance_sync != null:
		appearance_sync.bind_records(records)
		appearance_sync.refresh()
	if header_car_cache != null: header_car_cache.bind_records(records)
	if achievements != null:
		achievements.records = records
		achievements.sync_identity()
		achievements.refresh()
	if online.client.signed_in() and not bool(online.client.player.get("analytics_enabled",true)) and bool(records.settings.get("optional_analytics",false)):
		records.settings.optional_analytics = false
		records.save_records()
	_apply_privacy_choice(bool(records.settings.get("optional_analytics",false)))
	if not challenge_invitation.is_empty() and not is_instance_valid(game):
		_open_challenges(true)
		challenges.open(challenge_invitation)
	if lifecycle != null:
		lifecycle.library = library
		lifecycle.records = records
		if is_instance_valid(publication_notification): publication_notification.set_entries(lifecycle.publication_notifications())
		_remember_publication_news()
	if is_instance_valid(account_button):
		account_button.text = online.player_name() if online.client.signed_in() else "Guest"
		account_button.auto_translate_mode = Node.AUTO_TRANSLATE_MODE_DISABLED if online.client.signed_in() else Node.AUTO_TRANSLATE_MODE_INHERIT
	var completed_sign_in: bool = screen == "account" and _account_setup_pending and not online.busy and online.profile_ready()
	if previous_profile != active_profile and startup_complete and not is_instance_valid(game) and is_instance_valid(root_ui):
		_rebuild_profile_menu("rivalry" if completed_sign_in else "account" if not online.client.signed_in() else "drafts" if screen == "create" else screen)
	elif completed_sign_in:
		_show_screen("rivalry")
	if completed_sign_in and tutorial != null: tutorial.offer()
	_prefetch_discovery()
	_prefetch_rivalry()

func _prefetch_discovery() -> void:
	if cloud == null or is_instance_valid(game) or not cloud.paged_discovery_available(): return
	# Prime the visible page during sign-in/startup, before Free Race is opened.
	# The adapter coalesces this with menu activation and retains its scoped cache.
	cloud.query_discovery(browser_state,records.settings.get("favorites",[]),records.settings.get("raced_tracks",[]))
	_prime_free_race_comparisons()

func _prime_free_race_comparisons() -> void:
	if cloud == null or is_instance_valid(game) or not online.client.signed_in(): return
	if screen != "tracks":
		discovery_provider.comparisons.cancel_speculation()
		return
	if screen == "tracks" and startup_complete: return # Visible carousel owns its warming window.
	var scope: String = online.client.base_url()+"/"+str(online.client.player.get("id",""))+"/"+str(online.client.test_drivers_available())
	discovery_provider.configure_cache(cloud.cache_root().path_join("menu/"+scope.sha256_text()+".json"),scope)
	var entries: Array = []
	if selected_track != null and selected_track.metadata.has("cloud_version"):
		entries.append({"version_id":selected_track.metadata.cloud_version})
	for entry: Dictionary in cloud.entries.slice(0,6): entries.append(entry)
	discovery_provider.prime_comparisons(online.client,entries,VehicleCatalog.selected)

func _configure_result_comparisons() -> void:
	var scope: String = online.client.base_url()+"/"+str(online.client.player.get("id",""))+"/"+str(online.client.test_drivers_available())
	discovery_provider.configure_cache(cloud.cache_root().path_join("menu/"+scope.sha256_text()+".json"),scope)
	discovery_provider.comparisons.configure(online.client,discovery_provider.snapshot_cache.path+".comparisons.json",scope)

func _select_player_storage() -> void:
	var identity: String = str(online.client.player.get("id", "")) if online.client.signed_in() else ""
	var scope: String = (online.client._base_url + "/" + identity).sha256_text() if not identity.is_empty() else ""
	if scope == active_profile:
		library.owner_name = online.player_name() if not identity.is_empty() else "Guest"
		return
	# Save the outgoing editor under its original owner before selecting Guest or
	# another account. A running race already retains its preference_records.
	var profile_save_error: String = ""
	if not document.is_empty() and library != null:
		var binding: Dictionary = cloud._read(library.directory.path_join(".backend").path_join(str(document.id)+".json")) if cloud != null else {}
		if binding.get("source_fingerprint") != TrackLibrary.draft_fingerprint(document):
			if library.save_wip(document) != OK:
				_profile_draft_recovery[active_profile] = document.duplicate(true)
				profile_save_error = "The previous draft could not be saved. It remains in memory for that account; check available storage."
			else: _profile_draft_recovery.erase(active_profile)
	_flush_editor_writes()
	_navigation_generation += 1
	_finish_preview_thread()
	active_profile = scope
	if challenges != null:
		challenges.reset()
		challenge_seed = {}
		challenge_result_view = false
	if rivalry != null:
		rivalry.test_population = false
		rivalry.reset()
		rivalry_result_pending = false
	if scope.is_empty():
		records = guest_records
		library = guest_library
	else:
		var directory: String = profile_root.path_join("players").path_join(scope)
		DirAccess.make_dir_recursive_absolute(directory)
		records = LocalRecords.new(directory.path_join("records.json"))
		library = TrackLibrary.new(directory.path_join("tracks"))
	records.load_records()
	GameSoundtrack.instance().apply_settings(records.settings)
	library.owner_name = online.player_name() if not identity.is_empty() else "Guest"
	document = {}
	if _profile_draft_recovery.has(scope): document = _profile_draft_recovery[scope].duplicate(true)
	history.clear()
	redo_history.clear()
	editor_view.clear()
	object_browser_state.clear()
	browser_state.clear()
	track_catalog = null
	discovery_provider = TrackDiscoveryProvider.new()
	if not is_instance_valid(game): test_document_snapshot = {}
	test_return_to_drafts = false
	returning_to_editor = false
	pending_menu_notice = profile_save_error
	selected_track = NativeTrack.read("res://resources/tracks/" + BUILTIN_IDS[0] + ".json")
	var last: String = str(records.settings.get("last_track", ""))
	if last in BUILTIN_IDS:
		selected_track = NativeTrack.read("res://resources/tracks/" + last + ".json")
	elif last.begins_with("creator_"):
		var saved: Dictionary = library.load_document(last.trim_prefix("creator_"))
		if not saved.is_empty():
			var track: NativeTrack = TrackCompiler.compile(saved)
			if track != null: selected_track = track
	elif last.begins_with("cloud_"): _restore_cloud_selection(last)
	VehicleCatalog.selected = VehicleCatalog.valid_id(str(records.settings.get("selected_car", "compact")))
	ui_touch_scale = float(records.settings.get("touch_scale", 1.0))
	ui_left_handed = bool(records.settings.get("left_handed", false))

func _stamp_creator() -> void:
	if not document.is_empty(): document["creator"] = library.owner_name

func _restore_cloud_selection(identity: String) -> void:
	if cloud == null: return
	var catalog := TrackCatalog.new(library)
	cloud.add_to_catalog(catalog,null,[identity])
	for entry: Dictionary in catalog.entries:
		if entry.id == identity or "cloud_"+str(entry.version_id) == identity:
			selected_track = cloud.presentation_track(entry)
			records.settings.last_track = entry.id
			return

func _open_account() -> void:
	_show_screen("account")
	online.refresh_options()

func _account() -> void:
	_account_setup_pending = not online.profile_ready()
	var background := preload("res://ui/account_backdrop.gd").new()
	MenuStyle.fill(background)
	root_ui.add_child(background)
	var margin := MarginContainer.new()
	MenuStyle.fill(margin)
	for side: String in ["left", "right", "top", "bottom"]: margin.add_theme_constant_override("margin_" + side, 16)
	root_ui.add_child(margin)
	var center := CenterContainer.new()
	center.size_flags_vertical = Control.SIZE_EXPAND_FILL
	center.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	margin.add_child(center)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 8)
	center.add_child(column)
	var brand_space := Control.new()
	brand_space.custom_minimum_size.y = 64
	column.add_child(brand_space)
	var brand := MenuBrand.new()
	brand_space.add_child(brand)
	brand_space.resized.connect(func() -> void: brand.position = Vector2((brand_space.size.x - 196) * 0.5, 0))
	var panel := preload("res://ui/account_panel.gd").new()
	panel.account = online
	panel.custom_minimum_size.x = 600
	# Finish the guest button's input dispatch before replacing its menu tree.
	# Otherwise that same release can activate the newly created car picker.
	panel.continue_requested.connect(_continue_from_account,CONNECT_DEFERRED)
	column.add_child(panel)
	# Extra status copy takes priority over decorative space above the card.
	var fit_brand := func() -> void:
		brand_space.visible = panel.get_combined_minimum_size().y + 72 <= root_ui.size.y - 32
	panel.minimum_size_changed.connect(fit_brand)
	root_ui.resized.connect(fit_brand)
	fit_brand.call_deferred()

func _continue_from_account() -> void:
	if screen != "account": return
	_open_rivalry()
	if tutorial != null: tutorial.offer()

func _heading(eyebrow: String, title: String, parent: VBoxContainer = null) -> void:
	if parent == null: parent = content
	parent.add_child(MenuStyle.label(eyebrow, 15, true))
	parent.add_child(MenuStyle.label(title, 32))

func _feature(parent: HBoxContainer, title: String, description: String, action: Callable) -> void:
	var feature := MenuFeature.new()
	feature.heading = title
	feature.description = description
	feature.pressed.connect(action)
	parent.add_child(feature)

func _open_library(section: String) -> void:
	browser_state.section = "all" if section == "random" else section
	browser_state.page = 0
	if section == "random": browser_state.random_on_open = true
	_show_screen("tracks")

func _ensure_track_catalog() -> void:
	if track_catalog == null:
		track_catalog = TrackCatalog.new(library)
		if cloud != null: return # Race uses backend publications and their caches.
		if library.directory != guest_library.directory:
			track_catalog.shared_directories.append(guest_library.directory.path_join(".published"))
		var profiles := DirAccess.open(profile_root.path_join("players"))
		if profiles != null:
			for profile: String in profiles.get_directories():
				if profile == active_profile: continue
				track_catalog.shared_directories.append(profile_root.path_join("players").path_join(profile).path_join("tracks/.published"))

func _tracks(parent: VBoxContainer = null, preview: bool = false) -> void:
	if parent == null: parent = content
	var began: int = Time.get_ticks_usec()
	var browser := TrackBrowser.new()
	var created: int = Time.get_ticks_usec()
	browser.name = "TrackBrowser"
	browser.library = library
	_ensure_track_catalog()
	browser.catalog = track_catalog
	browser.cloud = cloud
	browser.discovery = discovery_provider
	if cloud != null and online.client.signed_in():
		var comparison_scope: String = online.client.base_url()+"/"+str(online.client.player.get("id",""))+"/"+str(online.client.test_drivers_available())
		discovery_provider.configure_cache(cloud.cache_root().path_join("menu/"+comparison_scope.sha256_text()+".json"),comparison_scope)
	browser.records = records
	browser.builtin_ids = BUILTIN_IDS
	browser.selected_track = selected_track
	browser.page_preview = preview
	browser.state = browser_state.duplicate(true) if preview else browser_state
	browser.race_requested.connect(func(track: NativeTrack) -> void: _start_race(track,false))
	browser.track_selected.connect(_menu_track_selected)
	browser.preparation_requested.connect(_prepare_selected_track.bind(browser))
	browser.home_requested.connect(func() -> void: _show_screen("tracks"))
	browser.import_requested.connect(_import_dialog)
	browser.delete_requested.connect(_confirm_delete_track)
	browser.notice.connect(_notice)
	browser.share_requested.connect(_share_track_link)
	browser.rivalry_requested.connect(_open_rivalry)
	browser.challenges_requested.connect(_open_challenges)
	browser.daily_requested.connect(_open_track_of_day)
	browser.edit_requested.connect(func(doc: Dictionary) -> void:
		document = doc.duplicate(true)
		editor_view.clear()
		history.clear()
		redo_history.clear()
		_show_screen("create"))
	parent.add_child(browser)
	if not preview: menu_open_costs = {"browser_new_ms":(created-began)/1000.0,"browser_ready_ms":(Time.get_ticks_usec()-created)/1000.0}

func _menu_track_selected(track: NativeTrack) -> void:
	selected_track = track
	if screen == "tracks":
		var properties: Dictionary = _telemetry_track_properties(track)
		properties.mode = "free"
		properties.car_id = VehicleCatalog.selected
		properties.erase("ticket_id")
		_telemetry_observe("track_selected",properties)
	if screen == "garage" and is_instance_valid(content): _refresh_cached_menu_page("garage",content)
	for neighbor: Dictionary in menu_neighbors.values():
		if neighbor.screen == "garage": _refresh_cached_menu_page("garage",neighbor.content)

func _prepare_selected_track(track: NativeTrack, browser: TrackBrowser) -> void:
	if screen != "tracks" or selected_track != track or cloud_starting or is_instance_valid(game): return
	_cancel_selected_preparation()
	_selected_preparation_track = track
	_selected_preparation_browser = weakref(browser)
	_selected_preparation_scope = lifecycle.scope()
	_selected_preparation_navigation = _navigation_generation
	_selected_preparation_vehicle = VehicleCatalog.selected
	_selected_preparation_serial = browser._selection_serial
	_selected_preparation_entry = track.metadata.get("cloud_entry",{}).duplicate(true)
	_selected_preparation_pin = [track.identity,track.content_hash,track.metadata.get("cloud_version",""),track.metadata.get("cloud_entry",{}).get("content_hash","")]
	_selected_preparation_pending = true
	var generation: int = _selected_preparation_generation
	if _selected_preparation_obsolete(generation): _cancel_selected_preparation(); return
	if track.metadata.get("metadata_only",false):
		if cloud == null or not cloud.has_method("download_document") or _selected_preparation_entry.is_empty(): _cancel_selected_preparation(); return
		SELECTED_PREPARATION.download(weakref(self),generation,cloud,_selected_preparation_entry)
	else:
		_begin_selected_geometry(generation,_selected_preparation_entry,{})

func _selected_preparation_obsolete(generation: int) -> bool:
	if generation != _selected_preparation_generation or not is_inside_tree() or not _selected_preparation_pending: return true
	if screen != "tracks" or _navigation_generation != _selected_preparation_navigation or lifecycle == null or lifecycle.scope() != _selected_preparation_scope: return true
	if VehicleCatalog.selected != _selected_preparation_vehicle or selected_track != _selected_preparation_track or _selected_preparation_browser == null: return true
	if [selected_track.identity,selected_track.content_hash,selected_track.metadata.get("cloud_version",""),selected_track.metadata.get("cloud_entry",{}).get("content_hash","")] != _selected_preparation_pin: return true
	var browser: TrackBrowser = _selected_preparation_browser.get_ref()
	if not is_instance_valid(browser) or not browser.is_inside_tree() or browser.page_preview or browser.list_open or browser.selected_track != selected_track or browser._selection_serial != _selected_preparation_serial: return true
	if not _selected_preparation_entry.is_empty() and str(selected_track.metadata.get("cloud_version","")) != str(_selected_preparation_entry.get("version_id","")): return true
	if cloud != null and is_instance_valid(online.client.get("safety")) and not online.client.safety.allows(_selected_preparation_entry): return true
	return false

func _begin_selected_geometry(generation: int, entry: Dictionary, source: Dictionary) -> void:
	if _selected_preparation_obsolete(generation): return
	if _selected_preparation_track.metadata.get("metadata_only",false) and source.is_empty():
		_cancel_selected_preparation(); return
	if not _selected_preparation_track.metadata.get("metadata_only",false) and not NativeTrackVisual.race_roads_need_preparation(_selected_preparation_track):
		_cancel_selected_preparation(); return
	_selected_preparation_entry = entry.duplicate(true)
	_selected_preparation_source = source
	_selected_preparation_queued = true
	_poll_selected_preparation()

func _poll_selected_preparation() -> void:
	if not _selected_preparation_pending: return
	if _selected_preparation_obsolete(_selected_preparation_generation): _cancel_selected_preparation(); return
	if _selected_preparation_job == null:
		if _selected_preparation_queued and SELECTED_PREPARATION.ready_for_job():
			_selected_preparation_job = SELECTED_PREPARATION.start(_selected_preparation_track,_selected_preparation_entry,_selected_preparation_source,get_tree())
			_selected_preparation_source = {}; _selected_preparation_queued = false
		return
	if not _selected_preparation_job.done: return
	var job: RefCounted = _selected_preparation_job
	_selected_preparation_job = null
	var result: Dictionary = job.result if job.result is Dictionary else {}
	job.result = null
	var ready: NativeTrack = result.get("track")
	if ready != null:
		if not result.get("winter_cover",{}).is_empty(): ready.editor_winter_cover = result.winter_cover
		var receipt: Dictionary = result.get("receipt",{})
		if not receipt.is_empty(): NativeTrackVisual.ROAD_DISK_CACHE.publish_arrays(receipt)
		if ready != _selected_preparation_track:
			for property: Dictionary in ready.get_property_list():
				if int(property.usage) & PROPERTY_USAGE_SCRIPT_VARIABLE: _selected_preparation_track.set(property.name,ready.get(property.name))
			cloud.remember_compiled_entry(_selected_preparation_entry,_selected_preparation_track)
			track_catalog.remember_track(_selected_preparation_entry,_selected_preparation_track)
	else:
		NativeTrackVisual.ROAD_DISK_CACHE.discard_arrays(result.get("receipt",{}))
	_selected_preparation_pending = false
	_selected_preparation_track = null
	_selected_preparation_browser = null
	_selected_preparation_entry = {}
	_selected_preparation_pin = []
	_selected_preparation_source = {}; _selected_preparation_queued = false

func _cancel_selected_preparation() -> void:
	_selected_preparation_generation += 1
	SELECTED_PREPARATION.cancel(_selected_preparation_job)
	_selected_preparation_job = null
	_selected_preparation_pending = false
	_selected_preparation_track = null
	_selected_preparation_browser = null
	_selected_preparation_entry = {}
	_selected_preparation_pin = []
	_selected_preparation_source = {}; _selected_preparation_queued = false

func _await_selected_preparation(track: NativeTrack, loading_id: int, scope: String, navigation: int, starting_screen: String, vehicle: String, selection: NativeTrack) -> bool:
	while _selected_preparation_pending and _selected_preparation_track == track:
		_poll_selected_preparation()
		if not _selected_preparation_pending: break
		await get_tree().process_frame
		if _race_preparation_changed(loading_id,scope,navigation,starting_screen,vehicle,selection): return false
	return not _race_preparation_changed(loading_id,scope,navigation,starting_screen,vehicle,selection)

func _open_race_area() -> void:
	if race_area_mode == "rivalry": _open_rivalry()
	elif race_area_mode == "challenges": _open_challenges()
	elif race_area_mode == "daily": _open_track_of_day()
	else: _navigate_menu_page("tracks")

func _open_challenges(browse: bool = false) -> void:
	_cancel_rivalry_entry()
	challenge_browsing = browse
	race_area_mode = "challenges"
	_navigate_menu_page("challenges")
	if browse and not challenges.busy: challenges.refresh()

func _browse_challenges() -> void:
	challenge_browsing = true
	if challenges.folder not in ["discover","friends","received"]:
		challenges.select_folder("discover")
		return
	_challenges()
	if not challenges.busy: challenges.refresh()

func _challenges_changed() -> void:
	if achievements != null and not challenges.busy:
		var completed: Array = challenges.items.duplicate()
		if not challenges.selected.is_empty(): completed.append(challenges.selected)
		var activity: bool = false
		for item: Dictionary in completed:
			if item.get("state") != "complete" or not item.get("joined",false): continue
			var key: String = achievements.scope+"/"+str(item.get("id",item.get("code","")))
			if _achievement_challenges.has(key): continue
			if _achievement_challenges.size() >= 128: _achievement_challenges.erase(_achievement_challenges.keys()[0])
			_achievement_challenges[key] = true
			activity = true
		if activity: achievements.refresh_after_activity()
	if not challenges.selected.is_empty():
		var identity: String = str(challenges.selected.get("id",""))
		_telemetry_observe("challenge_opened",{"challenge_id":identity,"reason":"open"},identity)
	if screen == "challenges" and is_instance_valid(content) and (not is_instance_valid(game) or challenge_result_view): _challenges()

func _challenges(parent: VBoxContainer = null) -> void:
	if parent == null: parent = content
	var detail_tab: int = 0
	var inbox_scroll: int = 0
	var draft_query: String = challenges.search
	var query_focus: bool = false
	var query_caret: int = 0
	var previous: ChallengesPage = parent.find_child("ChallengesPage",true,false)
	if previous != null and previous.browser_scope == challenges.scope():
		if str(previous.selected.get("code","")) == str(challenges.selected.get("code","")):
			var views: TabContainer = previous.find_child("ChallengeRaceViews",true,false)
			if views != null: detail_tab = views.current_tab
		if [previous.folder,previous.search,previous.mode_filter,previous.vehicle_filter,previous.sort_order] == [challenges.folder,challenges.search,challenges.mode_filter,challenges.vehicle_filter,challenges.sort_order]:
			var inbox: ScrollContainer = previous.find_child("ChallengeInboxScroll",true,false)
			if inbox != null: inbox_scroll = inbox.scroll_vertical
			if previous._search != null:
				draft_query = previous._search.text
				query_focus = previous._search.has_focus()
				query_caret = previous._search.caret_column
	for child: Node in parent.get_children():
		parent.remove_child(child)
		child.queue_free()
	var page := ChallengesPage.new()
	page.safety_client = online.client
	page.items = challenges.items
	page.selected = challenges.selected
	page.detail_tab = detail_tab
	page.browser_scope = challenges.scope()
	page.inbox_scroll = inbox_scroll
	page.selected_stage = challenges.selected_stage
	page.stage_requested.connect(challenges.select_stage)
	page.folder = challenges.folder
	page.search = challenges.search
	page.mode_filter = challenges.mode_filter
	page.vehicle_filter = challenges.vehicle_filter
	page.sort_order = challenges.sort_order
	page.signed_in = online.client.signed_in()
	page.busy = challenges.busy or cloud_starting
	page.error = challenges.error
	page.has_more = not challenges.next_cursor.is_empty()
	page.result_view = challenge_result_view
	page.landing_view = not challenge_browsing
	page.result_state = challenges.result_state
	page.outcome = challenges.outcome
	page.mode_requested.connect(_request_race_mode)
	page.folder_requested.connect(func(folder: String) -> void:
		challenges.select_folder(folder))
	page.selected_requested.connect(func(code: String) -> void: challenges.open(code))
	page.filters_requested.connect(challenges.set_filters)
	page.create_requested.connect(func() -> void: _create_challenge_dialog())
	page.browse_requested.connect(_browse_challenges)
	page.landing_requested.connect(_open_challenges)
	page.code_requested.connect(_challenge_code_dialog)
	page.race_requested.connect(_start_challenge_race)
	page.share_requested.connect(_share_challenge)
	page.rematch_requested.connect(func() -> void:
		await challenges.rematch()
		if challenges.error.is_empty():
			challenge_result_view = false
			_clear_challenge_game()
			_open_challenges(true)
			_share_challenge())
	page.cancel_requested.connect(_cancel_challenge_dialog)
	page.refresh_requested.connect(func() -> void:
		if challenges.folder == "sent" and not challenges.selected.is_empty(): challenges.open(str(challenges.selected.code))
		else: challenges.refresh())
	page.more_requested.connect(func() -> void: challenges.refresh(true))
	page.sign_in_requested.connect(_open_account)
	page.back_requested.connect(func() -> void:
		challenge_result_view = false
		_clear_challenge_game()
		_open_challenges(true))
	parent.add_child(page)
	if page._search != null:
		page._search.text = draft_query
		if query_focus:
			page._search.grab_focus()
			page._search.caret_column = mini(query_caret,draft_query.length())
	_keep_race_mode_rail_fixed(page)

func _clear_challenge_game() -> void:
	if is_instance_valid(game):
		remove_child(game)
		game.queue_free()
		game = null
	challenge_racing = false
	challenge_practice = false

func _receive_challenge(value: String) -> void:
	challenge_invitation = ChallengesClient.code_from(value)
	if challenge_invitation.is_empty(): return
	_track_link_generation += 1
	if not startup_complete:
		await get_tree().process_frame
		_receive_challenge.call_deferred(value)
		return
	if is_instance_valid(game):
		_queued_track_link = ""
		challenge_queued_invitation = challenge_invitation
		return
	_open_challenges(true)
	challenges.open(challenge_invitation)

func _receive_track_link(value: String) -> void:
	var version: String = preload("res://platform/track_links.gd").version_from(value)
	if version.is_empty(): return
	_track_link_generation += 1
	var generation: int = _track_link_generation
	_queued_track_link = value
	if not startup_complete:
		await get_tree().process_frame
		if _queued_track_link == value: _receive_track_link.call_deferred(value)
		return
	if is_instance_valid(game):
		challenge_queued_invitation = ""
		return
	_queued_track_link = ""
	var owner_scope: String = lifecycle.scope()
	var navigation: int = _navigation_generation
	# Resolve only through our configured service, never the incoming URL's host.
	var response: Dictionary = await online.client.request_api("/track-versions/"+version)
	if generation != _track_link_generation or owner_scope != lifecycle.scope() or navigation != _navigation_generation: return
	if is_instance_valid(game):
		_queued_track_link = value
		return
	if not response.get("ok",false) or not response.get("data") is Dictionary:
		_notice("This track link could not be opened. Connect and try again.")
		return
	var entry: Dictionary = response.data
	if not cloud._valid_entry(entry) or str(entry.get("version_id","")) != version or entry.get("state") != "published" or (is_instance_valid(online.client.safety) and not online.client.safety.allows(entry)):
		_notice("This track is no longer available.")
		return
	if not cloud.remember_publication(entry):
		_notice("Could not save the track link on this device. Check available storage and try again.")
		return
	_open_published_track(entry)

func _share_track_link(metadata: Dictionary) -> void:
	var link: String = preload("res://platform/track_links.gd").share_url(metadata,online.client.base_url())
	if link.is_empty(): return
	var title: String = str(metadata.get("name",metadata.get("track_name","Track")))
	if challenge_links.share_track(title+"\n"+link): return
	_notice("Track link copied.\n"+link)

func _challenge_code_dialog() -> void:
	var dialog := ConfirmationDialog.new()
	dialog.title = "Open challenge"
	dialog.ok_button_text = "Open"
	var field := LineEdit.new()
	field.name = "ChallengeCode"
	field.placeholder_text = "Challenge code or invitation link"
	field.custom_minimum_size = Vector2(460,52)
	field.max_length = 2048
	dialog.add_child(field)
	_own_dialog(dialog)
	dialog.confirmed.connect(func() -> void:
		challenge_invitation = ChallengesClient.code_from(field.text)
		challenges.open(field.text))
	dialog.popup_centered(Vector2i(500,150))
	preload("res://ui/keyboard_dialog.gd").attach(dialog, field)
	field.grab_focus()

func _share_challenge(invitation: Dictionary = {}) -> void:
	var value: Dictionary = challenges.selected if invitation.is_empty() else invitation
	if value.is_empty(): return
	_telemetry_observe("share_clicked",{"challenge_id":str(value.get("id","")),"reason":"share"})
	var time: String = GameText.message("%.3f s") % (float(value.target_ms)/1000.0) if value.get("target_ms") != null else "Join my group challenge"
	var text: String = GameText.message("%s · %s · 5 laps · %s\n%s\nCode: %s") % [str(value.entry.name),time,VehicleCatalog.title(str(value.vehicle_id)),str(value.share_url),str(value.code)]
	if ChallengesClient.is_series(value):
		var names: PackedStringArray = []
		for stage: Dictionary in value.get("stages",[]): names.append(str(stage.entry.name))
		var limit: Variant = value.stages[0].attempt_limit
		var tries: String = "Unlimited tries" if limit == null else str(int(limit))+" tries each"
		text = ("3×3" if value.get("mode") == "3x3" else "Custom challenge")+" · "+str(value.stages.size())+" tracks · "+tries+" · Lowest total time wins\n"+" / ".join(names)+"\n"+str(value.share_url)+"\nCode: "+str(value.code)
	if challenge_links.share(text): return
	var dialog := AcceptDialog.new()
	dialog.title = "Challenge invitation copied"
	dialog.dialog_text = text
	_own_dialog(dialog)
	dialog.popup_centered(Vector2i(560,240))

func _cancel_challenge_dialog() -> void:
	var dialog := ConfirmationDialog.new()
	dialog.title = "Cancel challenge?"
	dialog.dialog_text = "Participants will no longer be able to submit challenge times."
	dialog.ok_button_text = "Cancel challenge"
	_own_dialog(dialog)
	dialog.confirmed.connect(func() -> void: challenges.cancel())
	dialog.popup_centered()

func _create_challenge_dialog(version: String = "", vehicle: String = "", ticket_id: String = "", duration_seconds: int = 604800, finished: Dictionary = {}, attempt_limit: int = 0, configuration: Dictionary = {}, results_only: bool = false) -> void:
	if game_configuration != null and not game_configuration.settings.get("features.challenge_creation",true):
		_notice("New challenges are temporarily unavailable.")
		return
	if not online.client.signed_in():
		_open_account()
		return
	var dialog := ChallengeCreate.new()
	dialog.adapter = challenges
	dialog.library = library
	dialog.records = records
	dialog.selected_track = selected_track
	dialog.browser_state = browser_state.duplicate(true)
	dialog.entries = cloud.entries.duplicate(true)
	dialog.initial_version = version if not version.is_empty() else str(selected_track.metadata.get("cloud_version",""))
	dialog.initial_vehicle = VehicleCatalog.selected if vehicle.is_empty() else vehicle
	dialog.initial_ticket = ticket_id
	dialog.initial_duration = duration_seconds
	dialog.initial_attempt_limit = attempt_limit
	dialog.initial_configuration = configuration.duplicate(true)
	dialog.results_only = results_only
	if not ticket_id.is_empty():
		if finished.is_empty() and is_instance_valid(game) and game.preparation_complete and game.get("track_session").finished:
			finished = _challenge_finished_context(game.get("native_track"),game.get("track_session").race_time_seconds(),game.get("track_session").completed_laps,ticket_id,str(game.get("vehicle_id")))
		dialog.result_context = finished.duplicate(true)
		if not finished.is_empty():
			dialog.initial_version = str(finished.entry.version_id)
			dialog.initial_vehicle = str(finished.vehicle_id)
			dialog.initial_ticket = str(finished.ticket_id)
	var retained: Dictionary = cloud.retained_entry(selected_track.identity)
	if not retained.is_empty() and not dialog.entries.any(func(entry: Dictionary) -> bool: return str(entry.version_id) == str(retained.version_id)):
		dialog.entries.push_front(retained)
	if not challenges.selected.is_empty() and not dialog.entries.any(func(entry: Dictionary) -> bool: return str(entry.version_id) == str(challenges.selected.entry.version_id)):
		dialog.entries.push_front(challenges.selected.entry)
	dialog.created_callback = func() -> void:
		var race_now: bool = dialog.start_after_create
		_telemetry_observe("challenge_created",{"challenge_id":str(challenges.selected.get("id","")),"reason":"create"})
		_clear_challenge_game()
		challenge_result_view = false
		challenges.folder = "sent"
		_open_challenges(true)
		if race_now: _race_created_challenge.call_deferred(str(challenges.selected.code),challenges.scope())
		else: _show_challenge_ready()
	dialog.race_to_set_requested.connect(_race_for_challenge)
	if not ticket_id.is_empty() and is_instance_valid(game) and not is_instance_valid(content):
		_challenge_return_ui = root_ui
		_challenge_return_screen = screen
		menu_layer.remove_child(root_ui)
		root_ui = null
	_show_screen("challenge_create")
	content.add_child(dialog)
	dialog.canceled.connect(_close_challenge_create)
	dialog.popup_centered()

func _race_created_challenge(code: String, scope: String) -> void:
	# The Created folder refresh owns its request first. Retain the explicit race
	# intent across that read, while navigation/account/selection changes cancel it.
	var navigation: int = _navigation_generation
	var deadline: int = Time.get_ticks_msec()+30000
	while is_inside_tree() and screen == "challenges" and navigation == _navigation_generation and challenges.scope() == scope and str(challenges.selected.get("code","")) == code:
		if not challenges.busy:
			_start_challenge_race()
			return
		if Time.get_ticks_msec() >= deadline: return
		await get_tree().process_frame

func _show_challenge_ready() -> void:
	if challenges.selected.is_empty(): return
	var invitation: Dictionary = challenges.selected.duplicate(true)
	var scope: String = challenges.scope()
	var dialog := preload("res://ui/challenge_ready_dialog.gd").new()
	dialog.snapshot = invitation
	dialog.context_current = func() -> bool: return challenges.scope() == scope
	_own_dialog(dialog)
	dialog.share_requested.connect(func() -> void:
		if challenges.scope() == scope: _share_challenge(invitation))
	dialog.popup_centered(Vector2i(mini(700,int(get_viewport().get_visible_rect().size.x)-32),mini(460,int(get_viewport().get_visible_rect().size.y)-32)))

func _close_challenge_create() -> void:
	if is_instance_valid(_challenge_return_ui):
		menu_layer.remove_child(root_ui)
		root_ui.queue_free()
		root_ui = _challenge_return_ui
		_challenge_return_ui = null
		screen = _challenge_return_screen
		content = null
		menu_layer.add_child(root_ui)
		return
	_open_challenges(challenge_browsing)

func _challenge_finished_context(track: NativeTrack, total: float, laps: int, ticket_id: String, vehicle: String) -> Dictionary:
	var version: String = str(track.metadata.get("cloud_version",""))
	var entry: Dictionary = {}
	for candidate: Dictionary in cloud.entries:
		if str(candidate.get("version_id","")) == version:
			entry = candidate.duplicate(true)
			break
	if entry.is_empty():
		var points: Array = []
		for point: Vector2 in track.route: points.append([point.x,point.y])
		entry = {"version_id":version,"track_id":str(track.metadata.get("cloud_track_id","")),"content_hash":track.content_hash,"name":track_title(track),"creator":str(track.metadata.get("cloud_creator","")),"theme":str(track.metadata.get("theme","pine")),"points":points}
	return {"entry":entry,"ticket_id":ticket_id,"vehicle_id":vehicle,"total":total,"laps":laps,"scope":challenges.scope()}

func _race_for_challenge(metadata: Dictionary, vehicle: String, duration_seconds: int = 604800, attempt_limit: int = 0, configuration: Dictionary = {}) -> void:
	var original: String = challenges.scope()
	var navigation: int = _navigation_generation
	var entry: Dictionary = cloud.entry_from_metadata(metadata)
	if not await cloud.download(entry):
		_notice(cloud.last_error)
		return
	if navigation != _navigation_generation or original != challenges.scope(): return
	var track: NativeTrack = cloud.compile_entry(entry)
	if track == null:
		_notice("Track could not be prepared. Try again.")
		return
	_clear_challenge_game()
	VehicleCatalog.selected = vehicle
	selected_track = track
	challenge_seed = {"version_id":str(metadata.version_id),"vehicle_id":vehicle,"duration_seconds":duration_seconds,"attempt_limit":attempt_limit,"configuration":configuration.duplicate(true)}
	await _start_race(track,false)

func _start_challenge_race() -> void:
	if cloud_starting or challenges.busy or challenges.selected.is_empty(): return
	if online.client.signed_in() and not _result_capacity_available(): return
	var original: String = challenges.scope()
	var navigation: int = _navigation_generation
	var selected: Dictionary = challenges.selected.duplicate(true)
	var stage_index: int = challenges.selected_stage
	var stage: Dictionary = challenges.race_stage().duplicate(true)
	var guest: bool = not online.client.signed_in()
	# Joining is also part of this start; a second press must not reserve a try.
	cloud_starting = true
	if not guest and not selected.joined:
		await challenges.join()
		if not challenges.error.is_empty():
			_abort_challenge_start()
			return
		_telemetry_observe("challenge_joined",{"challenge_id":str(selected.get("id","")),"reason":"join"})
	if not _challenge_selection_current(original,navigation,str(selected.code),stage_index):
		_abort_challenge_start()
		return
	_challenges()
	var loading: RaceLoading = _open_race_loading()
	var loading_id: int = loading.get_instance_id()
	var points := PackedVector2Array()
	for point: Array in stage.entry.points: points.append(Vector2(point[0],point[1]))
	loading.configure(str(stage.entry.name),str(stage.entry.get("theme","pine")),points)
	loading.stage("Connecting race…")
	await _present_race_loading()
	if not _race_loading_matches(loading_id): return
	if not _challenge_selection_current(original,navigation,str(selected.code),stage_index):
		_abort_challenge_start(loading_id)
		return
	var issued: Dictionary = await challenges.ticket(stage_index) if not guest else {}
	if not _race_loading_matches(loading_id): return
	if not _challenge_selection_current(original,navigation,str(selected.code),stage_index):
		_abort_challenge_start(loading_id)
		return
	var entry: Dictionary = cloud.entry_from_metadata(stage.entry)
	var downloaded: bool = await cloud.download(entry) if guest or not issued.is_empty() else false
	if not _race_loading_matches(loading_id): return
	var track: NativeTrack = cloud.compile_entry(entry) if downloaded else null
	if not _challenge_selection_current(original,navigation,str(selected.code),stage_index):
		_abort_challenge_start(loading_id)
		return
	var recording: Dictionary = await challenges.ghost(stage_index) if track != null else {}
	if not _race_loading_matches(loading_id): return
	cloud_starting = false
	_close_race_loading(loading_id)
	if not _challenge_selection_current(original,navigation,str(selected.code),stage_index):
		_abort_challenge_start()
		return
	if track == null or (not guest and issued.is_empty()):
		if challenges.error.is_empty(): challenges.error = cloud.last_error if not cloud.last_error.is_empty() else "Track could not be prepared. Try again."
		_challenges()
		return
	_clear_challenge_game()
	VehicleCatalog.selected = str(selected.vehicle_id)
	selected_track = track
	challenge_recording = recording
	challenge_result_view = false
	await _start_race(track,false,guest,issued)

func _challenge_selection_current(owner_scope: String, navigation: int, code: String, stage_index: int) -> bool:
	return navigation == _navigation_generation and owner_scope == challenges.scope() and str(challenges.selected.get("code","")) == code and challenges.selected_stage == stage_index

func _abort_challenge_start(loading_id: int = 0) -> void:
	cloud_starting = false
	if loading_id != 0: _close_race_loading(loading_id)
	if screen == "challenges" and is_instance_valid(content): _challenges()

func _reset_rivalry_entry_view() -> void:
	if rivalry_racing and rivalry_section in ["race_results","result"] and is_instance_valid(game):
		remove_child(game)
		game.queue_free()
		game = null
		rivalry_racing = false
	rivalry_section = "overview"

func _open_world_circuit() -> void:
	if is_instance_valid(game) or cloud_starting: return
	if online != null and not preload("res://backend/world_ranking_client.gd").circuit_open(online.client):
		_notice("The Compact Circuit has not opened. Check World Ranking for the launch date.")
		return
	rivalry.set_circuit_mode(true)
	rivalry_section = "overview"
	_open_rivalry()

func _open_rivalry() -> void:
	if game_configuration != null and not game_configuration.settings.get("features.rivalry_entry",true) and not rivalry_racing:
		_notice("Weekly Rivalry entry is temporarily unavailable.")
		return
	if _rivalry_entry_pending: return
	_race_mode_request += 1
	var request: int = _race_mode_request
	var navigation: int = _navigation_generation
	if not rivalry.model.sample: rivalry.refresh(false)
	var original: String = rivalry.scope()
	if online.client.signed_in() and not rivalry.has_snapshot() and rivalry.busy:
		_rivalry_entry_pending = true
		_update_rivalry_entry_button()
		while rivalry.busy and request == _race_mode_request and navigation == _navigation_generation and original == rivalry.scope():
			await get_tree().process_frame
	if request != _race_mode_request: return
	_rivalry_entry_pending = false
	_update_rivalry_entry_button()
	if navigation != _navigation_generation or original != rivalry.scope(): return
	race_area_mode = "rivalry"
	_navigate_menu_page("rivalry")

func _prefetch_rivalry() -> void:
	if rivalry == null or rivalry.model.sample or not online.client.signed_in() or is_instance_valid(game): return
	if rivalry.has_snapshot(): return
	rivalry.refresh(false)

func _cancel_rivalry_entry() -> void:
	_race_mode_request += 1
	_rivalry_entry_pending = false
	_update_rivalry_entry_button()

func _update_rivalry_entry_button() -> void:
	var parent: Control = race_mode_transition_rail if is_instance_valid(race_mode_transition_rail) else menu_body
	if not is_instance_valid(parent): return
	var button: Button = parent.find_child("Mode_trophy",true,false)
	if button == null: return
	button.disabled = _rivalry_entry_pending
	button.icon = MenuIcon.texture("clock") if _rivalry_entry_pending else preload("res://ui/race_mode_icons.gd").texture("trophy")

func _rivalry_changed() -> void:
	if achievements != null and rivalry.model.completed and not rivalry.model.sample and not rivalry.busy and not rivalry.cached_snapshot:
		var finale: String = rivalry.snapshot_scope+"/"+rivalry.model.group_id
		if finale != _achievement_finale:
			_achievement_finale = finale
			achievements.refresh_after_activity()
	if rivalry.result_ticket.is_empty() or rivalry.result_state in ["verified","skipped","failed","rejected","expired"]: rivalry_result_pending = false
	if screen == "rivalry" and is_instance_valid(content) and (not is_instance_valid(game) or rivalry_section == "result"):
		_rivalry()
	# Swipe previews must follow the same membership state as the visible page.
	for neighbor: Dictionary in menu_neighbors.values():
		if neighbor.screen == "rivalry": _rivalry(neighbor.content)
	if returning_menu_neighbor.get("screen","") == "rivalry" and is_instance_valid(returning_menu_neighbor.get("content")):
		_rivalry(returning_menu_neighbor.content)

func _park_rivalry_page(branch: Node) -> void:
	if not is_instance_valid(_retained_rivalry_page) or not branch.is_ancestor_of(_retained_rivalry_page): return
	if not is_instance_valid(_rivalry_parking):
		_rivalry_parking = VBoxContainer.new()
		_rivalry_parking.name = "RetainedRivalry"
		_rivalry_parking.process_mode = Node.PROCESS_MODE_DISABLED
		_rivalry_parking.hide()
		menu_layer.add_child(_rivalry_parking)
		_set_menu_preview_input(_rivalry_parking,true)
	# Keep one actual page, including the three one-shot car viewports. It stays
	# visible in its departing body until that body's slide has completed.
	_retained_rivalry_page.reparent(_rivalry_parking,false)
	for viewport: SubViewport in _retained_rivalry_page.find_children("*","SubViewport",true,false):
		viewport.render_target_update_mode = SubViewport.UPDATE_DISABLED

func _rivalry(parent: VBoxContainer = null) -> void:
	if parent == null: parent = content
	if parent == content and screen == "rivalry": _remember_rivalry_standings(parent)
	var page: WeeklyRivalryPage = parent.find_child("WeeklyRivalryPage",true,false) as WeeklyRivalryPage
	var parked: bool = false
	if page == null and is_instance_valid(_retained_rivalry_page) and _retained_rivalry_page.get_parent() == _rivalry_parking:
		if _retained_rivalry_scope == rivalry.scope():
			page = _retained_rivalry_page
			parked = true
		else:
			_retained_rivalry_page.get_parent().remove_child(_retained_rivalry_page)
			_retained_rivalry_page.queue_free()
			_retained_rivalry_page = null
	var retained: bool = page != null
	if not retained or parked:
		for child: Node in parent.get_children():
			parent.remove_child(child)
			child.queue_free()
	if not retained:
		page = WeeklyRivalryPage.new()
	_retained_rivalry_page = page
	_retained_rivalry_scope = rivalry.scope()
	page.safety_client = online.client
	page.circuit_mode = rivalry.circuit_mode
	page.model = rivalry.model
	page.finale_livery = VehicleLivery.for_car(records.settings,rivalry.model.vehicle_id)
	page.finale_customisation = VehicleCustomisation.for_car(records.settings,rivalry.model.vehicle_id)
	page.finale_condition = VehicleCondition.read(records,rivalry.model.vehicle_id)
	page.standings_identity = rivalry.scope()+"/"+rivalry.model.group_id+"/"+str(rivalry.model.week)
	if rivalry_standings_view.get("key","") == page.standings_identity:
		page.standings_scroll_offset = int(rivalry_standings_view.offset)
	page.section = rivalry_section
	page.selected = rivalry_track
	page.ghost_choice = rivalry_ghost_choice
	page.busy = rivalry.busy or rivalry.cached_snapshot or cloud_starting
	page.background_refresh = rivalry.busy and not rivalry.model.sample and not rivalry.cached_snapshot and not cloud_starting and rivalry.has_snapshot()
	page.error = rivalry.error
	page.signed_in = online.client.signed_in()
	page.pending_result = rivalry_result_pending
	page.race_details = rivalry_race_details
	if retained:
		var rebuilt: bool = page.refresh_presentation()
		if parked:
			page.reparent(parent,false)
			var rail: Control = page.find_child("RaceModes",true,false)
			if rail != null: rail.modulate.a = 1.0
		_keep_race_mode_rail_fixed(page)
		if rebuilt and page.section == "detail" and not rivalry.model.sample and not rivalry.model.tracks.is_empty(): _prepare_rivalry_track_preview(page,rivalry_track)
		if parent == content and screen == "rivalry": _maybe_rivalry_summary.call_deferred()
		return
	page.section_requested.connect(func(section: String) -> void:
		if is_instance_valid(game):
			remove_child(game)
			game.queue_free()
			game = null
			rivalry_racing = false
		rivalry_section = section
		_rivalry()
		if not rivalry.model.sample: rivalry.refresh(false))
	page.track_requested.connect(func(index: int) -> void:
		rivalry_track = index
		rivalry_section = "detail"
		_rivalry())
	page.track_selected.connect(func(index: int) -> void: rivalry_track = index)
	page.race_requested.connect(_start_rivalry_race)
	page.free_race_requested.connect(func() -> void:
		if is_instance_valid(game):
			remove_child(game)
			game.queue_free()
			game = null
			rivalry_racing = false
		_open_free_race())
	page.join_requested.connect(func() -> void:
		if online.client.signed_in(): rivalry.join()
		else: _open_account())
	page.refresh_requested.connect(func() -> void: rivalry.refresh())
	page.circuit_requested.connect(_open_world_circuit)
	page.car_rivalry_requested.connect(func() -> void:
		rivalry.set_circuit_mode(false)
		_open_rivalry())
	page.challenges_requested.connect(_open_challenges)
	page.daily_requested.connect(_open_track_of_day)
	page.continue_requested.connect(func() -> void:
		if rivalry.model.sample:
			rivalry.model.next_week()
			_rivalry()
		else: rivalry.continue_week())
	page.share_requested.connect(_share_rivalry_results)
	page.retry_requested.connect(_retry_race)
	parent.add_child(page)
	_keep_race_mode_rail_fixed(page)
	if page.section == "detail" and not rivalry.model.sample and not rivalry.model.tracks.is_empty():
		_prepare_rivalry_track_preview(page,rivalry_track)
	if parent == content and screen == "rivalry": _maybe_rivalry_summary.call_deferred()

func _rivalry_summary_key() -> String:
	if rivalry == null or screen != "rivalry" or rivalry_section != "overview" or is_instance_valid(game): return ""
	if not is_instance_valid(root_ui) or not root_ui.is_visible_in_tree(): return ""
	if rivalry.model.sample or not rivalry.model.completed or rivalry.cached_snapshot or rivalry.model.tracks.size() != 5: return ""
	if rivalry.snapshot_scope != rivalry.scope() or rivalry.model.group_id.is_empty(): return ""
	return JSON.stringify([rivalry.scope(),rivalry.model.group_id,rivalry.model.week,rivalry.model.vehicle_id,rivalry.circuit_mode])

func _maybe_rivalry_summary() -> void:
	var key: String = _rivalry_summary_key()
	if key.is_empty() or _reviewed_rivalry_summaries.has(key) or rivalry.busy or cloud_starting: return
	if menu_page_motion != null or is_instance_valid(race_loading): return
	var payload: String = rivalry.model.finale_share_text()
	var existing: Window = root_ui.get_node_or_null("RivalrySummaryDialog") as Window
	if existing != null:
		if existing.receipt_key == key and existing.payload == payload: return
		existing.hide()
		root_ui.remove_child(existing)
		existing.queue_free()
	for child: Node in root_ui.get_children():
		if child is Window and child.visible:
			if not child.visibility_changed.is_connected(_maybe_rivalry_summary): child.visibility_changed.connect(_maybe_rivalry_summary,CONNECT_ONE_SHOT | CONNECT_DEFERRED)
			return
	var dialog := preload("res://ui/rivalry_summary_dialog.gd").new()
	dialog.summary = rivalry.model.finale_summary()
	dialog.summary.personal_bests = rivalry.model.personal_best_slots.size()
	var opponent: Dictionary = {}
	for driver: Dictionary in rivalry.model.standing():
		if driver.id != WeeklyRivalry.SELF:
			opponent = driver
			break
	dialog.summary.opponent_points = opponent.get("points")
	dialog.summary.lead = int(dialog.summary.points)-int(opponent.get("points",0))
	var own: Dictionary = WeeklyRivalry.self_row(rivalry.model.standing())
	dialog.player_name = online.player_name() if online.client.signed_in() else str(own.get("name",GameText.message("You")))
	if dialog.player_name.is_empty(): dialog.player_name = str(own.get("name",GameText.message("You")))
	dialog.vehicle_id = rivalry.model.vehicle_id
	dialog.livery = VehicleLivery.for_car(records.settings,rivalry.model.vehicle_id)
	dialog.customisation = VehicleCustomisation.for_car(records.settings,rivalry.model.vehicle_id)
	dialog.condition = VehicleCondition.read(records,rivalry.model.vehicle_id)
	dialog.week = rivalry.model.week
	dialog.circuit = rivalry.circuit_mode
	dialog.receipt_key = key
	dialog.payload = payload
	var owner_id: int = root_ui.get_instance_id()
	dialog.context_current = func() -> bool: return is_instance_valid(root_ui) and root_ui.get_instance_id() == owner_id and _rivalry_summary_key() == key
	dialog.continue_available = func() -> bool: return dialog.context_current.call() and not rivalry.busy and not cloud_starting
	var reviewed: Callable = func() -> void:
		if is_instance_valid(root_ui) and root_ui.get_instance_id() == owner_id and _rivalry_summary_key() == key and rivalry.model.finale_share_text() == payload: _reviewed_rivalry_summaries[key] = true
	dialog.confirmed.connect(reviewed)
	dialog.canceled.connect(reviewed)
	dialog.continue_requested.connect(func() -> void:
		if not dialog.context_current.call() or rivalry.busy or cloud_starting or rivalry.model.finale_share_text() != payload: return
		reviewed.call()
		dialog.hide()
		dialog.queue_free()
		rivalry.continue_week())
	_own_dialog(dialog)
	dialog.present()

func _share_rivalry_results() -> void:
	if rivalry.busy or rivalry.cached_snapshot or not rivalry.model.completed: return
	if not rivalry.model.sample and rivalry.snapshot_scope != rivalry.scope(): return
	var text: String = rivalry.model.finale_share_text()
	if text.is_empty(): return
	if root_ui.get_node_or_null("RivalryShareDialog") != null: return
	var dialog := preload("res://ui/rivalry_share_dialog.gd").new()
	dialog.model = rivalry.model
	dialog.native_sharing = challenge_links.can_share_results()
	dialog.player_name = online.player_name() if online.client.signed_in() else ""
	dialog.livery = VehicleLivery.for_car(records.settings,rivalry.model.vehicle_id)
	dialog.customisation = VehicleCustomisation.for_car(records.settings,rivalry.model.vehicle_id)
	dialog.condition = VehicleCondition.read(records,rivalry.model.vehicle_id)
	if not dialog.native_sharing: DisplayServer.clipboard_set(text)
	var context: Dictionary = {"scope":rivalry.scope(),"group":rivalry.model.group_id,"week":rivalry.model.week,"text":text,"screen":screen}
	dialog.share_requested.connect(_share_rivalry_card.bind(weakref(dialog),context))
	dialog.save_requested.connect(_save_rivalry_card.bind(weakref(dialog),context))
	_own_dialog(dialog)
	var bounds: Vector2 = root_ui.get_viewport().get_visible_rect().size
	dialog.popup_centered(Vector2i(minf(1120,bounds.x-48),minf(620,bounds.y-48)))
	if dialog.native_sharing: _share_rivalry_card.call_deferred(weakref(dialog),context)

func _rivalry_card_valid(dialog: AcceptDialog, context: Dictionary) -> bool:
	return is_instance_valid(dialog) and not dialog.is_queued_for_deletion() and dialog.visible \
		and screen == context.screen and rivalry.scope() == context.scope and not rivalry.cached_snapshot \
		and (rivalry.model.sample or rivalry.snapshot_scope == context.scope) \
		and rivalry.model.completed and rivalry.model.group_id == context.group and rivalry.model.week == context.week \
		and rivalry.model.finale_share_text() == context.text

func _share_rivalry_card(dialog_ref: WeakRef, context: Dictionary) -> void:
	var dialog: AcceptDialog = dialog_ref.get_ref() as AcceptDialog
	if not _rivalry_card_valid(dialog,context) or dialog.sharing: return
	dialog.set_sharing(true,"Preparing image…")
	dialog.request_id = ""
	var png: PackedByteArray = await _prepare_rivalry_card(dialog_ref,context)
	dialog = dialog_ref.get_ref() as AcceptDialog
	if not _rivalry_card_valid(dialog,context):
		if is_instance_valid(dialog): dialog.set_sharing(false,"Results changed. Close and share again.")
		return
	if png.is_empty():
		dialog.set_sharing(false,"Couldn't prepare the image. Try again.")
		return
	dialog.request_id = TrackLibrary.unique_id()
	dialog.set_sharing(false,"Ready to share")
	var opened: bool = challenge_links.share_results(dialog.request_id,png,str(context.text))
	if not opened: dialog.set_sharing(false,"Couldn't open sharing. Try again.")

func _prepare_rivalry_card(dialog_ref: WeakRef, context: Dictionary) -> PackedByteArray:
	var dialog: AcceptDialog = dialog_ref.get_ref() as AcceptDialog
	if not _rivalry_card_valid(dialog,context): return PackedByteArray()
	if not dialog.prepared_png.is_empty(): return dialog.prepared_png
	var values: Dictionary = dialog.image_values()
	values.owner = dialog_ref
	var renderer: Callable = dialog.image_renderer
	var png: PackedByteArray
	if renderer.is_valid(): png = await renderer.call(root_ui,values)
	else: png = await load("res://ui/rivalry_share_image.gd").render(root_ui,values)
	dialog = dialog_ref.get_ref() as AcceptDialog
	if not _rivalry_card_valid(dialog,context): return PackedByteArray()
	dialog.prepared_png = png
	return png

func _rivalry_share_failed(request_id: String, message: String) -> void:
	var dialog: AcceptDialog = root_ui.get_node_or_null("RivalryShareDialog") as AcceptDialog
	if is_instance_valid(dialog) and dialog.request_id == request_id: dialog.set_sharing(false,message)

func _save_rivalry_card(dialog_ref: WeakRef, context: Dictionary) -> void:
	var dialog: AcceptDialog = dialog_ref.get_ref() as AcceptDialog
	if not _rivalry_card_valid(dialog,context) or dialog.sharing: return
	dialog.set_sharing(true,"Preparing image…")
	var png: PackedByteArray = await _prepare_rivalry_card(dialog_ref,context)
	dialog = dialog_ref.get_ref() as AcceptDialog
	if not _rivalry_card_valid(dialog,context):
		if is_instance_valid(dialog): dialog.set_sharing(false,"Results changed. Close and share again.")
		return
	if png.is_empty():
		dialog.set_sharing(false,"Couldn't prepare the image. Try again.")
		return
	var picker := FileDialog.new()
	picker.title = "Save results card"
	picker.access = FileDialog.ACCESS_FILESYSTEM
	picker.file_mode = FileDialog.FILE_MODE_SAVE_FILE
	picker.use_native_dialog = true
	picker.theme = MenuStyle.theme()
	picker.filters = PackedStringArray(["*.png ; PNG image"])
	picker.current_file = GameText.message("Beat my track - Rivalry - Week %02d.png") % int(context.week)
	dialog.add_child(picker)
	picker.file_selected.connect(func(path: String) -> void:
		if _rivalry_card_valid(dialog,context):
			var file := FileAccess.open(path,FileAccess.WRITE)
			if file != null:
				file.store_buffer(png)
				file.flush()
				var error: Error = file.get_error()
				file.close()
				dialog.set_sharing(false,"Image saved" if error == OK else "Couldn't save the image. Try again.")
			else: dialog.set_sharing(false,"Couldn't save the image. Try again.")
		picker.queue_free())
	picker.canceled.connect(func() -> void:
		if is_instance_valid(dialog): dialog.set_sharing(false,"Results copied")
		picker.queue_free())
	picker.popup_centered_ratio(0.8)

func _remember_rivalry_standings(parent: Control) -> void:
	if not is_instance_valid(parent): return
	var page: WeeklyRivalryPage = parent.find_child("WeeklyRivalryPage",true,false)
	if page == null or not page.standings_ready or not is_instance_valid(page.standings_scroll): return
	rivalry_standings_view = {"key":page.standings_identity,"offset":page.standings_scroll.scroll_vertical}

func _prepare_rivalry_track_preview(page: WeeklyRivalryPage, index: int) -> void:
	var entry: Dictionary = cloud.entry_from_metadata(rivalry.model.tracks[index].entry)
	var document: Dictionary = cloud.cached_document(entry)
	if document.is_empty():
		if not bool(rivalry.model.tracks[index].get("available",true)): return
		if not await cloud.download(entry): return
		document = cloud.cached_document(entry)
	if is_instance_valid(page) and page.is_inside_tree(): page.apply_track_preview(document)

func _rivalry_ghost(index: int, choice: int, wait_for_recording: bool = false) -> Dictionary:
	if choice == 3: return {}
	var target: Dictionary = rivalry.model.ghost_target(index,choice)
	var driver: String = str(target.get("driver_id",""))
	if wait_for_recording: return await rivalry.ghost(index,driver)
	rivalry.prefetch_ghost(index,driver)
	return rivalry.cached_ghost(index,driver)

func _start_rivalry_race(index: int, choice: int) -> void:
	if cloud_starting or not online.client.signed_in() or rivalry.model.sample: return
	if not _result_capacity_available(): return
	if index < 0 or index >= rivalry.model.tracks.size(): return
	var navigation: int = _navigation_generation
	var original_scope: String = rivalry.scope()
	var original_group: String = rivalry.model.group_id
	var original_week: int = rivalry.model.week
	var original_version: String = str(rivalry.model.tracks[index].entry.get("version_id",""))
	cloud_starting = true
	_rivalry()
	var loading: RaceLoading = _open_race_loading()
	var loading_id: int = loading.get_instance_id()
	var metadata: Dictionary = rivalry.model.tracks[index].entry
	var points := PackedVector2Array()
	for point: Array in metadata.get("points", []): points.append(Vector2(point[0], point[1]))
	loading.configure(str(metadata.get("name", "Weekly Rivalry")), str(metadata.get("theme", "pine")), points)
	loading.stage("Connecting race…")
	await _present_race_loading()
	if not _race_loading_matches(loading_id): return
	if navigation != _navigation_generation or original_scope != rivalry.scope():
		cloud_starting = false
		_close_race_loading(loading_id)
		return
	# A background refresh can be syncing appearance before it emits changed.
	# Retain this explicit start instead of silently losing its first tap.
	while rivalry.busy:
		await get_tree().process_frame
		if not _race_loading_matches(loading_id): return
		if navigation != _navigation_generation or original_scope != rivalry.scope():
			_close_race_loading(loading_id)
			return
	var same_track: bool = index < rivalry.model.tracks.size() and str(rivalry.model.tracks[index].entry.get("version_id","")) == original_version
	var same_week: bool = rivalry.model.group_id == original_group and rivalry.model.week == original_week
	var available: bool = same_track and bool(rivalry.model.tracks[index].get("available",true))
	if rivalry.cached_snapshot or rivalry.snapshot_scope != original_scope or not same_week or not available or rivalry.model.completed or rivalry.model.status != "active":
		_close_race_loading(loading_id)
		_rivalry()
		_notice(rivalry.error if not rivalry.error.is_empty() else "Rivalry changed while preparing the race. Open the track and try again.")
		return
	_rivalry_ghost(index,choice) # Fetch presentation in parallel with required race data.
	var issued: Dictionary = await rivalry.ticket(index)
	if not _race_loading_matches(loading_id): return
	if navigation != _navigation_generation or original_scope != rivalry.scope():
		cloud_starting = false
		_close_race_loading(loading_id)
		return
	if issued.is_empty():
		cloud_starting = false
		_close_race_loading(loading_id)
		if rivalry.error.is_empty(): rivalry.error = "Could not connect the race. Refresh Rivalry and try again."
		_rivalry()
		_notice(rivalry.error)
		return
	var entry: Dictionary = cloud.entry_from_metadata(rivalry.model.tracks[index].entry)
	loading.stage("Downloading track…")
	var downloaded: Dictionary = await cloud.download_document(entry)
	if not _race_loading_matches(loading_id): return
	if navigation != _navigation_generation or original_scope != rivalry.scope():
		cloud_starting = false
		_close_race_loading(loading_id)
		return
	if downloaded.is_empty():
		cloud_starting = false
		_close_race_loading(loading_id)
		rivalry.error = cloud.last_error if not cloud.last_error.is_empty() else "Track download failed. Check your connection and try again."
		_rivalry()
		_notice(rivalry.error)
		return
	loading.stage("Preparing track…")
	await _present_race_loading()
	if not _race_loading_matches(loading_id): return
	if navigation != _navigation_generation or original_scope != rivalry.scope():
		cloud_starting = false
		_close_race_loading(loading_id)
		return
	var track: NativeTrack = await online.client._background(cloud.compile_document.bind(entry,downloaded))
	if not _race_loading_matches(loading_id): return
	if navigation != _navigation_generation or original_scope != rivalry.scope():
		cloud_starting = false
		_close_race_loading(loading_id)
		return
	if track == null:
		cloud_starting = false
		_close_race_loading(loading_id)
		rivalry.error = "Track could not be prepared. Try again."
		_rivalry()
		_notice(rivalry.error)
		return
	loading.stage("Loading ghost…")
	var recording: Dictionary = await _rivalry_ghost(index,choice,true)
	if not _race_loading_matches(loading_id): return
	cloud_starting = false
	_close_race_loading(loading_id)
	if navigation != _navigation_generation or original_scope != rivalry.scope(): return
	rivalry_track = index
	rivalry_ghost_choice = choice
	rivalry_recording = recording
	rivalry_result_pending = false
	rivalry_race_details = {}
	rivalry.result_ticket = ""
	rivalry.result_state = ""
	selected_track = track
	await _start_race(track,false,false,issued)

func _ensure_garage_parking() -> void:
	if not is_instance_valid(_garage_parking):
		_garage_parking = VBoxContainer.new()
		_garage_parking.name = "RetainedGarage"
		_garage_parking.process_mode = Node.PROCESS_MODE_DISABLED
		menu_layer.add_child(_garage_parking)
		menu_layer.move_child(_garage_parking,0)
		MenuStyle.fill(_garage_parking)
		_set_menu_preview_input(_garage_parking,true)
		_garage_parking.hide()

func _park_garage() -> void:
	if not is_instance_valid(_retained_garage): return
	if is_instance_valid(_retained_garage.get("_preview_service")): _retained_garage._preview_service.suspend_previews()
	_ensure_garage_parking()
	_garage_parking.hide()
	if _retained_garage.get_parent() != _garage_parking:
		_retained_garage.reparent(_garage_parking,false)
	# Reparenting between inherited hidden branches need not emit visibility_changed.
	_retained_garage.showroom._reflection_visibility()

func _garage_residency() -> Dictionary:
	var result: Dictionary = {"image_gpu_bytes":0,"viewport_gpu_bytes":0,"scene_bytes":0,"preview_io_cpu_bytes":0}
	if is_instance_valid(_garage_preloader): result.merge(_garage_preloader.residency())
	if not is_instance_valid(_retained_garage): return result
	var seen: Dictionary = {}
	for card: CarShowroom in _retained_garage.thumbnails.values():
		var image: TextureRect = card.get("_image")
		if image == null or image.texture == null or seen.has(image.texture.get_instance_id()): continue
		seen[image.texture.get_instance_id()] = true
		result.image_gpu_bytes += image.texture.get_width()*image.texture.get_height()*4
	for viewport: SubViewport in _retained_garage.find_children("*","SubViewport",true,false):
		result.viewport_gpu_bytes += viewport.size.x*viewport.size.y*8
	result.scene_bytes = preload("res://track/prepared_world_cache.gd")._resource_bytes(_retained_garage,{})
	if is_instance_valid(_retained_garage.get("_preview_service")) and _retained_garage._preview_service.worker != null: result.preview_io_cpu_bytes = 16*1024*1024
	return result

func _trim_hidden_garage() -> void:
	if is_instance_valid(_garage_preloader): _garage_preloader.evict()
	if not is_instance_valid(_retained_garage) or _retained_garage.is_visible_in_tree(): return
	var retired: GaragePage = _retained_garage
	_retained_garage = null
	retired.get_parent().remove_child(retired)
	retired.queue_free()

func _rebuild_profile_menu(destination: String) -> void:
	# Garage owns its account fence in _garage, like the other menu pages.
	if destination == "garage":
		_show_screen(destination)
		return
	_show_screen("restoring")
	var generation: int = _navigation_generation
	var owner_records: LocalRecords = records
	if is_instance_valid(_retained_garage) and _retained_garage.records != records:
		_retained_garage.get_parent().remove_child(_retained_garage)
		_retained_garage.queue_free()
		_retained_garage = null
	if not is_inside_tree() or generation != _navigation_generation or owner_records != records or is_instance_valid(game): return
	_show_screen(destination)

func _garage_appearance_changed() -> void:
	if is_instance_valid(_garage_preloader): _garage_preloader.invalidate()
	_refresh_account_car()
	if is_instance_valid(_retained_garage) and _retained_garage.records == records:
		_retained_garage.refresh_cosmetics()

func _header_car_capture_allowed() -> bool:
	return startup_complete and not is_instance_valid(game) and _background_work_allowed() and screen not in ["account","restoring"]

func _header_car_picture_ready(vehicle: String) -> void:
	if not is_instance_valid(account_button): return
	var header: Control = account_button.get_node_or_null("MenuProfileCar")
	if header != null and header.records == header_car_cache.records and vehicle == VehicleCatalog.selected: header.refresh()
	var picker: Control = account_button.get_node_or_null("MenuCarPicker")
	if picker != null and picker.records == header_car_cache.records: picker.refresh_picture(vehicle)

func _refresh_account_car() -> void:
	if not is_instance_valid(account_button): return
	var preview: Control = account_button.get_node_or_null("MenuProfileCar")
	if preview != null: preview.refresh()

func _garage(parent: Control = null) -> void:
	if parent == null: parent = content
	if is_instance_valid(_retained_garage) and _retained_garage.records != records:
		_retained_garage.get_parent().remove_child(_retained_garage)
		_retained_garage.queue_free()
		_retained_garage = null
	if is_instance_valid(_retained_garage) and _retained_garage.records == records:
		if _retained_garage.get_parent() != parent: _retained_garage.reparent(parent,false)
		_retained_garage.showroom._reflection_visibility()
		_retained_garage.refresh_selection()
		_retained_garage.circuit_title = track_title(selected_track).to_upper()
		return
	var page := GaragePage.new()
	_retained_garage = page
	# Use the original interactive showroom with the saved appearance on entry.
	page.cached_carousel = true
	if is_instance_valid(_garage_preloader): page.preloaded_showroom=_garage_preloader.take()
	page.achievements = achievements
	page.news_client = online.client.news
	page.account_requested.connect(_open_account)
	page.records = records
	page.economy = cosmetic_economy
	page.circuit_title = track_title(selected_track).to_upper()
	page.size_flags_vertical = Control.SIZE_EXPAND_FILL
	page.vehicle_selected.connect(_select_vehicle)
	page.race_requested.connect(func() -> void: _start_race(selected_track,false))
	page.free_drive_requested.connect(_start_garage_free_drive)
	page.news_race_requested.connect(_race_news_story)
	page.news_share_requested.connect(_share_track_link)
	page.circuit_requested.connect(_open_library.bind("all"))
	page.save_failed.connect(func() -> void: _notice("Garage changes could not be saved. Check free storage space."))
	parent.add_child(page)

func _start_garage_free_drive() -> void:
	if screen != "garage" or cloud_starting or is_instance_valid(game) or is_instance_valid(race_loading): return
	var original_scope: String = lifecycle.scope()
	var navigation: int = _navigation_generation
	var vehicle: String = VehicleCatalog.selected
	var selection: NativeTrack = selected_track
	var loading: RaceLoading = _open_race_loading()
	var loading_id: int = loading.get_instance_id()
	loading.configure("Parking hall","night_city",PackedVector2Array(),true)
	loading.facts_label.text = "P1 parking hall · Free drive · 120 × 72 m"
	loading.stage("Opening parking hall…")
	cloud_starting = true
	await _present_race_loading()
	if _race_preparation_changed(loading_id,original_scope,navigation,"garage",vehicle,selection): return
	_stop_menu_page_motion()
	_race_menu_visible(false)
	game = preload("res://garage/parking_hall_drive.tscn").instantiate()
	game.process_mode = Node.PROCESS_MODE_DISABLED
	game.cooperative_preparation = true
	game.preparation_current = _race_installation_current.bind(loading_id,original_scope,navigation,"garage",vehicle,selection)
	game.vehicle_id = vehicle
	game.preference_records = records
	game.exit_requested.connect(_leave_race)
	add_child(game)
	var prepared_game: Node = game
	while is_instance_valid(prepared_game) and game == prepared_game and not prepared_game.preparation_complete:
		await get_tree().process_frame
		if _race_preparation_changed(loading_id,original_scope,navigation,"garage",vehicle,selection):
			_discard_preparing_game(prepared_game)
			return
	if not is_instance_valid(prepared_game) or game != prepared_game: return
	if is_instance_valid(prepared_game.world_render_preparation):
		loading.stage("Preparing graphics...")
		var stage_current: Callable = _race_installation_current.bind(loading_id,original_scope,navigation,"garage",vehicle,selection)
		if not await prepared_game.world_render_preparation.prepare(_present_race_loading,stage_current):
			if is_queued_for_deletion(): return
			_race_preparation_changed(loading_id,original_scope,navigation,"garage",vehicle,selection)
			if is_instance_valid(prepared_game): _discard_preparing_game(prepared_game)
			_close_race_loading(loading_id)
			return
	var touch: TouchControls = game.hud.touch
	touch.control_scale = ui_touch_scale
	touch.left_handed = ui_left_handed
	touch.haptic_strength = float(records.settings.get("steering_haptics",0.2))
	touch.layout = ControlLayout.from_settings(records.settings)
	touch.show_labels = bool(records.settings.get("control_labels",true))
	game.call("_process",0.0)
	await _present_race_loading()
	if _race_preparation_changed(loading_id,original_scope,navigation,"garage",vehicle,selection):
		_discard_preparing_game(prepared_game)
		return
	game.preparation_current = Callable()
	game.process_mode = Node.PROCESS_MODE_INHERIT
	_close_race_loading(loading_id)

func _leave_garage_free_drive() -> void:
	var previous_game: Node = game
	game = null
	previous_game.cancel_preparation()
	remove_child(previous_game)
	previous_game.queue_free()
	if product_telemetry != null: product_telemetry.set_transport_allowed(true)
	_race_menu_visible(true)
	GameSoundtrack.instance().show_menu()
	if not _queued_track_link.is_empty():
		var value: String = _queued_track_link
		_queued_track_link = ""
		_receive_track_link.call_deferred(value)
	elif not challenge_queued_invitation.is_empty():
		var value: String = challenge_queued_invitation
		challenge_queued_invitation = ""
		_receive_challenge.call_deferred(value)

func _race_news_story(story: Dictionary) -> void:
	if screen != "garage" or not is_instance_valid(_retained_garage) or _retained_garage.section != "news" or cloud_starting or is_instance_valid(race_loading): return
	if str(story.get("version_id","")).is_empty() and str(story.get("authoring_id","")).is_empty(): return
	var scope: String = lifecycle.scope()
	var navigation: int = _navigation_generation
	var vehicle: String = VehicleCatalog.selected
	var selection: NativeTrack = selected_track
	var preview_track := NativeTrack.new()
	preview_track.metadata = {"title":str(story.get("track_name","Track"))}
	var points: Variant = story.get("track_points",[])
	if points is Array:
		for point: Variant in points.slice(0,96):
			if point is Array and point.size() >= 2 and (point[0] is float or point[0] is int) and (point[1] is float or point[1] is int):
				var p := Vector2(float(point[0]),float(point[1]))
				if is_finite(p.x) and is_finite(p.y) and absf(p.x) <= 100000 and absf(p.y) <= 100000: preview_track.route.append(p)
	var loading: RaceLoading = _open_race_loading(preview_track)
	var loading_id: int = loading.get_instance_id()
	# The article has no biome metadata; show only known facts until it arrives.
	loading.scenery.texture = null
	loading.facts_label.text = "5 laps  ·  "+VehicleCatalog.title()
	loading.stage("Opening track...")
	cloud_starting = true
	await _present_race_loading()
	if _news_race_changed(loading_id,scope,navigation,vehicle,selection): return
	var cancelled: Callable = _news_race_changed.bind(loading_id,scope,navigation,vehicle,selection)
	var entry: Dictionary = await cloud.news_story_entry(story,cancelled)
	if _news_race_changed(loading_id,scope,navigation,vehicle,selection): return
	if entry.is_empty():
		_close_race_loading(loading_id)
		_notice(cloud.last_error)
		return
	loading.configure(str(entry.name),str(entry.get("theme","pine")),cloud.metadata_track(entry).route)
	loading.stage("Downloading track...")
	var downloaded: Dictionary = await cloud.download_document(entry,cancelled)
	if _news_race_changed(loading_id,scope,navigation,vehicle,selection): return
	if downloaded.is_empty():
		_close_race_loading(loading_id)
		_notice(cloud.last_error)
		return
	loading.stage("Preparing track...")
	var ready: Variant = await online.client._background(cloud.compile_document.bind(entry,downloaded))
	if _news_race_changed(loading_id,scope,navigation,vehicle,selection): return
	if not ready is NativeTrack:
		_close_race_loading(loading_id)
		_notice("Track could not be prepared. Try again.")
		return
	cloud.remember_compiled_entry(entry,ready)
	_ensure_track_catalog()
	track_catalog.remember_track(entry,ready)
	selected_track = ready
	cloud_starting = false
	await _start_race(ready,false,false,{},loading)
	# Standard admission can reject a newly blocked creator before starting.
	if not cloud_starting: _close_race_loading(loading_id)

func _news_race_changed(loading_id: int, scope: String, navigation: int, vehicle: String, selection: NativeTrack) -> bool:
	if _race_preparation_changed(loading_id,scope,navigation,"garage",vehicle,selection): return true
	if not is_instance_valid(_retained_garage) or _retained_garage.section != "news":
		_close_race_loading(loading_id)
		return true
	return false

func _settings() -> void:
	var page := SettingsPage.new()
	page.records = records
	page.purchase_client = online.client
	page.signed_in = online.client.signed_in()
	page.player_name = online.player_name() if page.signed_in else "Guest"
	page.country_code = str(online.client.player.get("country_code","")) if page.signed_in else ""
	page.customize_requested.connect(_customize_controls)
	page.account_requested.connect(_open_account)
	page.privacy_changed.connect(_apply_privacy_choice)
	page.tutorial_requested.connect(func() -> void:
		if tutorial != null: tutorial.replay())
	page.help_requested.connect(func(topic: String) -> void:
		if tutorial != null: tutorial.show_help(topic))
	content.add_child(page)

func _apply_privacy_choice(enabled: bool) -> void:
	if product_telemetry == null: return
	online.client.analytics_opt_in = enabled
	product_telemetry.set_enabled(enabled)
	if online.client.signed_in() and online.client.deletion_supported() and bool(online.client.player.get("analytics_enabled",true)) != enabled:
		var result: Dictionary = await online.client.request_api("/privacy/preferences",HTTPClient.METHOD_POST,{"analytics_enabled":enabled},"",true)
		if result.ok:
			online.client.player.analytics_enabled = enabled
			product_telemetry.update_identity()
		elif not enabled: _notice("Sharing is off on this device. The server preference could not be saved; retry when connected.")

func _erase_removed_account(origin: String, player_id: String) -> void:
	product_telemetry.erase_account(origin,player_id)
	if achievements != null and not achievements.erase_account(origin,player_id):
		_notice("Account removed. Achievement cache could not be erased; check storage.")
	if cosmetic_economy != null and not cosmetic_economy.erase_account(origin,player_id):
		_notice("Account removed. Coin recovery files could not be erased; check writable storage.")
	if not online.client.session_path.is_empty():
		var safety_path: String = online.client.session_path.get_base_dir().path_join("community/"+(origin+"/"+player_id).sha256_text()+".json")
		for path: String in [safety_path,safety_path+".tmp"]:
			if FileAccess.file_exists(path): DirAccess.remove_absolute(path)
	var paths: Array[String] = [
		(root_cloud_path(origin)).path_join("players").path_join(player_id.sha256_text()),
		online.client.resume_recovery._directory(player_id,origin),
		library.directory.path_join(".workflow").path_join((origin+"/"+player_id).sha256_text())]
	# Let pending replay/file preparations settle before a separate menu IO task
	# removes their old scope. No scene tree or canonical step enters that task.
	while not online.client._encoding_threads.is_empty(): await get_tree().process_frame
	var cleaned: Variant = await online.client._background(preload("res://backend/privacy_local.gd").erase_roots.bind(paths))
	if cleaned != true and is_inside_tree(): _notice("Account removed. Some local recovery files could not be erased; check writable storage.")

func root_cloud_path(origin: String) -> String:
	return (cloud.root_override if not cloud.root_override.is_empty() else "user://cloud").path_join(origin.sha256_text())

func _customize_controls() -> void:
	var editor := ControlLayoutEditor.new()
	editor.records = records
	root_ui.visible = false
	add_child(editor)
	editor.closed.connect(func() -> void: _show_screen("settings"))

func _swipe_menu_page(direction: int) -> void:
	var pages: Array[String] = ["tracks", "biome", "garage", "store"]
	var current: String = "biome" if screen == "drafts" else "tracks" if screen in ["rivalry","challenges","daily"] else screen
	var index: int = pages.find(current)
	if index < 0: return
	var destination: int = index + direction
	if destination < 0 or destination >= pages.size(): return
	if menu_neighbors.has(direction):
		_commit_menu_neighbor(direction)
		return
	# Revisit the current creation choices without replacing an in-progress draft.
	if pages[destination] == "biome" and document.is_empty(): _new_document()
	elif pages[destination] == "tracks": _open_race_area()
	else: _show_screen(pages[destination])

func _new_document() -> void:
	if screen == "create" and _editor_has_unsaved_changes():
		_confirm_editor_departure(_start_new_document)
		return
	_start_new_document()

func _start_new_document() -> void:
	_flush_editor_writes()
	_finish_preview_thread()
	editor_view.clear()
	object_browser_state.clear()
	canvas = null
	document = TrackDocument.create_blank()
	document.id = TrackLibrary.unique_id()
	editor_saved_snapshot = {}
	_stamp_creator()
	history.clear()
	redo_history.clear()
	_navigate_menu_page("biome")
	object_browser = null
	object_browser_state.clear()

func _editor() -> void:
	_stamp_creator()
	if document.is_empty():
		document = TrackDocument.create_blank()
		document.id = TrackLibrary.unique_id()
		_stamp_creator()
	if editor_pending_id != str(document.id):
		editor_pending_tools.clear()
		editor_pending_id = str(document.id)
		editor_save_error = OK
		editor_retry_original = false
		editor_save_message = ""
		editor_wip_saved = ""
		editor_wip_snapshot.clear()
		editor_wip_store = null
		editor_wip_disk_hash = ""
		editor_issue_cursor = -1
	editor_world = EditorWorld.new()
	editor_world.theme_id = str(document.theme)
	root_ui.add_child(editor_world)
	MenuStyle.fill(editor_world)
	canvas = EditorCanvas.new()
	canvas.stamp_kind = "rock" if document.theme == "desert" else "light" if document.theme == "night_city" else "tree"
	canvas.document = document
	if not editor_view.is_empty():
		canvas.zoom = editor_view.zoom
		canvas.pan = editor_view.pan
		canvas.mode = editor_view.mode
		canvas.selected = mini(int(editor_view.get("selected",-1)),document.points.size()-1)
		canvas.selected_object = mini(int(editor_view.get("selected_object",-1)),document.objects.size()-1)
		canvas.selected_piece = mini(int(editor_view.get("selected_piece",-1)),document.pieces.size()-1)
		canvas.stamp_kind = str(editor_view.get("stamp_kind","tree"))
		canvas.stamp_scale = float(editor_view.get("stamp_scale",1.0))
		canvas.stamp_span = float(editor_view.get("stamp_span",8.0))
		canvas.run_shape = str(editor_view.get("run_shape","line"))
		canvas.free_run = bool(editor_view.get("free_run",false))
		canvas.brush_surface = int(editor_view.get("brush_surface",0))
		canvas.brush_width = float(editor_view.get("brush_width",10))
		canvas.brush_shape = str(editor_view.get("brush_shape","round"))
		canvas.paint_mode = str(editor_view.get("paint_mode","free"))
		canvas.fitted = true
	root_ui.add_child(canvas)
	MenuStyle.fill(canvas)
	editor_world.follow_canvas(canvas)
	canvas.native_changed.connect(editor_world.show_track)
	canvas.edit_started.connect(func() -> void:
		editor_session.begin_gesture(document)
		if canvas.mode in ["move","add"]: document.route_override = true)
	canvas.document_changed.connect(func() -> void:
		canvas.refresh()
		test_button.disabled = true
		publish_button.disabled = true
		share_button.disabled = true)
	canvas.edit_finished.connect(func() -> void:
		_save_draft(true)
		editor_session.finish_gesture())
	canvas.edit_cancelled.connect(func() -> void:
		editor_session.cancel_gesture()
		canvas.selected_object = mini(canvas.selected_object,document.objects.size()-1)
		_save_draft(true)
		_update_editor_issues()
		_build_editor_tools())
	canvas.hint_changed.connect(_editor_hint)
	var overlay := Control.new()
	overlay.name = "EditorOverlay"
	overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root_ui.add_child(overlay)
	MenuStyle.fill(overlay)
	var close: Button = EditorButton.make("","close",func() -> void:
		_request_editor_exit())
	close.name="CloseEditor"
	close.tooltip_text="Close editor"
	overlay.add_child(close)
	close.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	close.offset_left=-68; close.offset_right=-16; close.offset_top=16; close.offset_bottom=68
	var header_left := HBoxContainer.new()
	header_left.name="EditorIdentityAndHistory"
	header_left.position=Vector2(16,16)
	header_left.add_theme_constant_override("separation",12)
	overlay.add_child(header_left)
	var title := HBoxContainer.new()
	var title_panel := PanelContainer.new()
	var title_style: StyleBoxFlat=EditorStyle.panel()
	title_style.content_margin_top=0
	title_style.content_margin_bottom=0
	title_panel.add_theme_stylebox_override("panel",title_style)
	header_left.add_child(title_panel)
	title_panel.add_child(title)
	title.add_theme_constant_override("separation",4)
	var track_name := Label.new()
	track_name.name="TrackName"
	track_name.text=str(document.name)
	track_name.custom_minimum_size=Vector2(220,52)
	track_name.clip_text=true
	track_name.text_overrun_behavior=TextServer.OVERRUN_TRIM_ELLIPSIS
	track_name.vertical_alignment=VERTICAL_ALIGNMENT_CENTER
	track_name.add_theme_font_override("font",EditorStyle.FONT)
	track_name.add_theme_font_size_override("font_size",20)
	track_name.add_theme_color_override("font_color",EditorStyle.INK)
	title.add_child(track_name)
	var creator_label := MenuStyle.label("by " + library.owner_name, 16, true)
	creator_label.name = "TrackCreator"
	creator_label.custom_minimum_size.x = 160
	creator_label.clip_text = true
	creator_label.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	title.add_child(creator_label)
	var pencil: Button=EditorButton.make("","pencil",_rename_track)
	EditorStyle.transparent_button(pencil)
	pencil.name="RenameTrack"
	pencil.tooltip_text="Rename track"
	title.add_child(pencil)
	var history_panel := PanelContainer.new()
	history_panel.name="EditorHistory"
	history_panel.add_theme_stylebox_override("panel",title_style.duplicate())
	header_left.add_child(history_panel)
	var history := HBoxContainer.new()
	history.add_theme_constant_override("separation",4)
	history_panel.add_child(history)
	editor_undo=EditorButton.make("","undo",_undo)
	editor_undo.text="Undo"
	EditorStyle.integrated(editor_undo)
	editor_undo.tooltip_text="Undo"
	history.add_child(editor_undo)
	editor_redo=EditorButton.make("","redo",_redo)
	editor_redo.text="Redo"
	EditorStyle.integrated(editor_redo)
	editor_redo.tooltip_text="Redo"
	history.add_child(editor_redo)
	var top := HBoxContainer.new()
	top.alignment = BoxContainer.ALIGNMENT_END
	overlay.add_child(top)
	top.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	top.offset_left = -516; top.offset_right = -80; top.offset_top = 16
	top.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	top.add_theme_constant_override("separation",8)
	editor_issue_button = EditorStyle.button("",_focus_issue)
	editor_issue_button.custom_minimum_size = Vector2(112,52)
	top.add_child(editor_issue_button)
	var settings: Button = EditorButton.make("","more",func() -> void:
		canvas.cancel_gesture()
		editor_map_panel.visible = not editor_map_panel.visible
		editor_tools_panel.hide())
	settings.text = "Map"
	settings.tooltip_text = "Map settings"
	top.add_child(settings)
	test_button = EditorButton.action("Test","play",_test_document)
	test_button.custom_minimum_size=Vector2(104,52)
	top.add_child(test_button)
	EditorStyle.apply(test_button)
	var disabled_play: StyleBoxFlat=EditorStyle.box()
	disabled_play.bg_color=Color("252d30")
	disabled_play.border_color=Color("586369")
	disabled_play.shadow_size=0
	test_button.add_theme_stylebox_override("disabled",disabled_play)
	for state: String in ["normal","hover","pressed","hover_pressed"]:
		var play_style: StyleBoxFlat=EditorStyle.box()
		play_style.bg_color=Color("29412e") if state=="hover" else Color(0.075,0.14,0.095,0.94)
		play_style.border_color=Color(0.65,0.82,0.43,0.45)
		play_style.set_border_width_all(1)
		test_button.add_theme_stylebox_override(state,play_style)
	publish_button = EditorButton.action("Publish","publish",_publish_current_document,true)
	publish_button.name = "PublishTrack"
	publish_button.tooltip_text = "Complete a test drive before publishing this version."
	publish_button.custom_minimum_size=Vector2(132,52)
	top.add_child(publish_button)
	var rail := VBoxContainer.new()
	rail.name = "EditorRail"
	var rail_panel := PanelContainer.new()
	rail_panel.name = "EditorRailPanel"
	rail_panel.anchor_top=0.5; rail_panel.anchor_bottom=0.5
	rail_panel.offset_left=16
	rail_panel.grow_vertical=Control.GROW_DIRECTION_BOTH
	rail_panel.resized.connect(func() -> void: rail_panel.offset_top=-rail_panel.size.y*0.5; rail_panel.offset_bottom=rail_panel.size.y*0.5)
	rail_panel.add_theme_stylebox_override("panel",EditorStyle.panel())
	overlay.add_child(rail_panel)
	rail_panel.add_child(rail)
	rail.add_theme_constant_override("separation",6)
	editor_mode_buttons.clear()
	for pair: Array in [["road","Track","road"],["paint","Surfaces","surface"],["objects","Objects","objects"]]:
		var value: String = pair[0]
		var button: Button = EditorButton.make(pair[1],pair[2],_editor_category.bind(value))
		button.name = "Editor"+({"road":"Road","paint":"Surface"}.get(value,pair[1]))
		button.custom_minimum_size=Vector2(86,76)
		button.toggle_mode = true
		EditorStyle.integrated(button)
		editor_mode_buttons[value] = button
		rail.add_child(button)
	var bottom := CenterContainer.new()
	editor_palette = bottom
	bottom.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay.add_child(bottom)
	bottom.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	bottom.offset_left = 108; bottom.offset_right = -112; bottom.offset_top = -98; bottom.offset_bottom = -16
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel",_editor_box())
	bottom.add_child(panel)
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.custom_minimum_size = Vector2(360,68)
	panel.add_child(scroll)
	editor_context = HBoxContainer.new()
	editor_context.add_theme_constant_override("separation",6)
	scroll.add_child(editor_context)
	surface_toolbar = PanelContainer.new()
	surface_toolbar.name = "SurfacePlacementToolbar"
	surface_toolbar.add_theme_stylebox_override("panel",StyleBoxEmpty.new())
	overlay.add_child(surface_toolbar)
	surface_toolbar.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	surface_toolbar.offset_left = -270
	surface_toolbar.offset_right = 270
	surface_toolbar.offset_top = 78
	surface_toolbar.offset_bottom = 180
	surface_toolbar.resized.connect(func() -> void:
		surface_toolbar.offset_left = -surface_toolbar.size.x*0.5
		surface_toolbar.offset_right = surface_toolbar.size.x*0.5)
	surface_actions = HBoxContainer.new()
	surface_actions.add_theme_constant_override("separation",8)
	surface_toolbar.add_child(surface_actions)
	editor_status = MenuStyle.label("",17)
	editor_status.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay.add_child(editor_status)
	editor_status.name = "EditorFeedback"
	editor_status.position = Vector2(16,128)
	editor_status.size = Vector2(280,64)
	editor_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	# Retain status text for internal feedback consumers, without a canvas-wide hint bar.
	editor_status.hide()
	editor_save_button = EditorStyle.button("Draft",_retry_editor_save)
	editor_save_button.name = "EditorSaveState"
	editor_save_button.position = Vector2(16,78)
	editor_save_button.custom_minimum_size = Vector2(260,42)
	overlay.add_child(editor_save_button)
	_update_editor_save_state()
	editor_loading = PanelContainer.new()
	editor_loading.name = "EditorPreparation"
	editor_loading.mouse_filter = Control.MOUSE_FILTER_IGNORE
	editor_loading.add_theme_stylebox_override("panel",EditorStyle.panel())
	overlay.add_child(editor_loading)
	editor_loading.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	editor_loading.offset_left = -110; editor_loading.offset_right = 110
	editor_loading.offset_top = 198; editor_loading.offset_bottom = 240
	var preparing: Label = MenuStyle.label("Preparing track…",17)
	preparing.mouse_filter = Control.MOUSE_FILTER_IGNORE
	preparing.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	editor_loading.add_child(preparing)
	object_browser = ObjectBrowser.new()
	object_browser.visible = false
	for key: String in object_browser_state: object_browser.set(key,object_browser_state[key])
	object_browser.current = canvas.stamp_kind
	object_browser.stamp_span = canvas.stamp_span
	object_browser.stamp_container_color = canvas.stamp_container_color
	object_browser.biome = str(document.get("biome",document.theme))
	overlay.add_child(object_browser)
	object_browser.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	object_browser.offset_left = 108; object_browser.offset_right = -112
	object_browser.offset_top = -160; object_browser.offset_bottom = -16
	object_browser.hide()
	object_browser.asset_chosen.connect(_choose_object)
	object_browser.mode_chosen.connect(_object_placement)
	object_browser.size_chosen.connect(func(value: float) -> void: canvas.stamp_scale=value)
	object_browser.span_chosen.connect(func(value: float) -> void: canvas.stamp_span=value)
	object_browser.container_color_chosen.connect(_container_colour)
	object_browser.rotation_requested.connect(_object_rotation_dialog)
	object_browser.select_requested.connect(func() -> void:
		canvas.cancel_gesture(); canvas.mode="objects"; _build_editor_tools())
	object_browser.populate_requested.connect(_open_object_population)
	editor_tools_panel = _editor_panel(overlay,"EditorTools")
	editor_inspector = VBoxContainer.new()
	editor_tools_panel.add_child(editor_inspector)
	editor_map_panel = _editor_panel(overlay,"EditorMap")
	editor_map_panel.anchor_bottom=0
	editor_map_panel.offset_bottom=82
	editor_map_panel.offset_left=-268
	var metadata := VBoxContainer.new()
	editor_map_panel.add_child(metadata)
	for entry: Array in [["New",_new_document],["Load",_load_track_dialog],["Save",_save_track_explicit]]:
		var command: Button=EditorStyle.button(entry[0],entry[1])
		command.name=entry[0]+"Track"
		metadata.add_child(command)
	share_button=EditorStyle.button("Share",_share_dialog)
	metadata.add_child(share_button)
	metadata.add_child(EditorStyle.button("Help",_editor_help))
	canvas.selection_changed.connect(_build_editor_tools)
	_restore_pending_tool(_editor_tool())
	_build_editor_tools()
	_refresh_editor()
	_update_editor_save_state()
	# Reuse an exact completed preview if the worker is idle; otherwise let the
	# existing single worker prepare the newest document while controls render.
	var cached_preview: NativeTrack
	if editor_preview_thread == null:
		for entry: Dictionary in editor_compiled_cache:
			if entry.document == document: cached_preview = entry.track; break
	if cached_preview != null: canvas.show_native(cached_preview)
	else: _queue_editor_preview()
	_update_editor_issues()
	if editor_view.is_empty(): canvas.call_deferred("fit")
	_apply_editor_safe_area(overlay)
	root_ui.resized.connect(_apply_editor_safe_area.bind(overlay))

func _editor_box() -> StyleBoxFlat:
	return EditorStyle.panel()


func _editor_panel(parent: Control, node_name: String) -> PanelContainer:
	var panel := PanelContainer.new()
	panel.name = node_name
	parent.add_child(panel)
	panel.set_anchors_and_offsets_preset(Control.PRESET_RIGHT_WIDE)
	panel.offset_left = -322; panel.offset_right = -16
	panel.offset_top = 82; panel.offset_bottom = -146
	panel.add_theme_stylebox_override("panel",_editor_box())
	panel.hide()
	return panel

func _apply_editor_safe_area(overlay: Control) -> void:
	if not OS.has_feature("mobile"): return
	var safe: Rect2i = DisplayServer.get_display_safe_area()
	var window: Vector2i = DisplayServer.window_get_size()
	var factor: float = get_viewport().get_visible_rect().size.y/maxf(1,window.y)
	overlay.offset_left = maxf(0,safe.position.x*factor)
	overlay.offset_top = maxf(0,safe.position.y*factor)
	overlay.offset_right = -maxf(0,(window.x-safe.end.x)*factor)
	overlay.offset_bottom = -maxf(0,(window.y-safe.end.y)*factor)

func _editor_hint(message: String) -> void:
	if not is_instance_valid(editor_status): return
	editor_status.text = message
	editor_status.show()
	editor_hint_generation += 1
	var generation: int = editor_hint_generation
	var label_id: int = editor_status.get_instance_id()
	get_tree().create_timer(4.0).timeout.connect(func() -> void:
		if generation == editor_hint_generation and is_instance_valid(editor_status) and editor_status.get_instance_id() == label_id and editor_save_error == OK: editor_status.hide())

func _update_editor_save_state() -> void:
	if not is_instance_valid(editor_save_button): return
	if editor_save_error != OK:
		editor_save_button.text = "Save failed · Retry"
		editor_save_button.disabled = false
		editor_save_button.tooltip_text = editor_save_message
		editor_save_button.add_theme_color_override("font_color",Color("ffbc8b"))
		if is_instance_valid(editor_status):
			editor_status.text = editor_save_message
			editor_status.show()
	elif editor_commits.unsettled() or editor_writes.unsettled(library,str(document.get("id",""))):
		editor_save_button.text = "Saving..."
		editor_save_button.disabled = true
		editor_save_button.tooltip_text = "Saving changes on this device."
	elif _has_pending_editor_work():
		editor_save_button.text = "Preview pending"
		editor_save_button.disabled = true
		editor_save_button.tooltip_text = "Switching tools retains previews. Save confirms valid previews; Discard cancels them."
	elif not editor_saved_snapshot.is_empty() and document == editor_saved_snapshot:
		editor_save_button.text = "Saved on device"
		editor_save_button.disabled = true
		editor_save_button.tooltip_text = "The saved original matches this document."
	else:
		editor_save_button.text = "WIP recovery saved" if (editor_wip_store == library and document == editor_wip_snapshot) else "Unsaved draft"
		editor_save_button.disabled = true
		editor_save_button.tooltip_text = "Recovery is separate from the saved original. Use Map → Save or Ctrl+S to keep it."

func _retry_editor_save() -> void:
	if editor_retry_original: _save_track_now()
	else: _save_draft(true)

func _editor_tool() -> String:
	if not is_instance_valid(canvas): return "road"
	if canvas.mode in ["paint","pan"] or (canvas.mode == "place" and canvas.stamp_kind in ["puddle","water","dirt"]): return "paint"
	return "objects" if canvas.mode in ["objects","place","run"] else "road"

func _capture_pending_tool() -> Dictionary:
	var state: Dictionary = {"mode":canvas.mode}
	var keys: Array = {"road":["ghost","piece_kind","snap_matched"],"paint":["paint_points","paint_mode","brush_surface","brush_width","brush_shape","protect_road","stamp_kind","stamp_scale"],"objects":["run_start","run_preview","run_draw","run_shape","free_run","stamp_kind","stamp_scale","stamp_span","stamp_rotation","stamp_container_color"]}[_editor_tool()]
	for key: String in keys:
		var value: Variant = canvas.get(key)
		state[key] = value.duplicate(true) if value is Array or value is Dictionary else value
	return state

func _stash_pending_tool() -> void:
	if is_instance_valid(canvas): editor_pending_tools[_editor_tool()] = _capture_pending_tool()

func _restore_pending_tool(tool: String) -> void:
	canvas.ghost = {}
	canvas.paint_points = []
	canvas.run_start = Vector2.INF
	canvas.run_preview = []
	canvas.run_draw = PackedVector2Array()
	canvas.mode = tool
	for key: String in editor_pending_tools.get(tool,{}): canvas.set(key,editor_pending_tools[tool][key])

func _pending_state_has_work(tool: String, state: Dictionary) -> bool:
	if tool == "road": return not state.get("ghost",{}).is_empty()
	if tool == "paint": return not state.get("paint_points",[]).is_empty()
	return state.get("run_start",Vector2.INF) != Vector2.INF or not state.get("run_preview",[]).is_empty() or state.get("run_draw",PackedVector2Array()).size() > 1

func _has_pending_editor_work() -> bool:
	var active: String = _editor_tool()
	for tool: String in ["road","paint","objects"]:
		var state: Dictionary = _capture_pending_tool() if is_instance_valid(canvas) and active == tool else editor_pending_tools.get(tool,{})
		if _pending_state_has_work(tool,state): return true
	return false

func _discard_editor_previews() -> void:
	editor_pending_tools.clear()
	if not is_instance_valid(canvas): return
	canvas.changed_in_gesture = false
	canvas.cancel_gesture()
	_restore_pending_tool(_editor_tool())
	canvas.queue_redraw()

func _commit_editor_previews() -> bool:
	_stash_pending_tool()
	var active: String = _editor_tool()
	for tool: String in ["road","paint","objects"]:
		if not _pending_state_has_work(tool,editor_pending_tools.get(tool,{})): continue
		canvas.changed_in_gesture = false
		canvas.cancel_gesture()
		_restore_pending_tool(tool)
		if tool == "road": canvas.confirm_piece()
		elif tool == "paint": canvas.confirm_paint()
		elif canvas.run_preview.is_empty():
			_editor_hint("Finish the object run, or cancel it before saving.")
		else:
			_remember()
			document.objects.append_array(preload("res://editor/creator_limits.gd").take(document.objects,canvas.run_preview,str(document.theme)))
			canvas.run_preview.clear(); canvas.run_draw.clear(); canvas.run_start = Vector2.INF
			_save_draft(true)
		_stash_pending_tool()
		if _pending_state_has_work(tool,editor_pending_tools[tool]):
			_build_editor_tools()
			_notice("Complete or cancel this preview before saving. Your pending work is retained.")
			return false
	_restore_pending_tool(active)
	_build_editor_tools()
	return true

func _resolve_editor_previews(after: Callable) -> void:
	if root_ui.find_child("PendingPreviewDialog",true,false) != null: return
	var dialog := ConfirmationDialog.new()
	dialog.name = "PendingPreviewDialog"
	dialog.title = "Pending previews"
	dialog.dialog_text = "Confirm or discard the pending previews before selecting an issue."
	dialog.ok_button_text = "Confirm previews"
	dialog.add_button("Discard previews",true,"discard")
	dialog.confirmed.connect(func() -> void:
		dialog.hide()
		if _commit_editor_previews(): after.call()
		dialog.queue_free())
	dialog.custom_action.connect(func(action: StringName) -> void:
		if action == &"discard":
			_discard_editor_previews()
			dialog.queue_free()
			after.call())
	dialog.canceled.connect(dialog.queue_free)
	root_ui.add_child(dialog)
	dialog.popup_centered_clamped(Vector2i(510,200))

func _editor_category(value: String) -> void:
	_stash_pending_tool()
	canvas.cancel_gesture()
	_restore_pending_tool(value)
	canvas.selected_piece = -1
	canvas.selected_object = -1
	canvas.selected = -1
	editor_geometry = ""
	editor_tools_panel.hide()
	editor_map_panel.hide()
	_build_editor_tools()
	canvas.queue_redraw()

func _context_button(label: String, glyph: String, action: Callable, chosen: bool = false) -> Button:
	var button: Button = EditorButton.make(label,glyph,action,chosen)
	EditorStyle.card(button,chosen)
	editor_context.add_child(button)
	return button

func _build_editor_tools() -> void:
	if not is_instance_valid(editor_context) or not is_instance_valid(canvas): return
	_update_test_access()
	_update_editor_save_state()
	canvas.road_action = editor_geometry if editor_geometry != "" else "move"
	for child: Node in editor_context.get_children():
		editor_context.remove_child(child)
		child.queue_free()
	for child: Node in editor_inspector.get_children():
		editor_inspector.remove_child(child)
		child.queue_free()
	var category: String = "objects" if canvas.mode in ["objects","place","run"]  else "paint" if canvas.mode in ["paint","pan"] else "road"
	if canvas.mode == "place" and canvas.stamp_kind in ["puddle","water","dirt"]: category="paint"
	var biome: String = str(document.get("biome",document.theme))
	if object_browser.biome!=biome:
		object_browser.biome=biome
		object_browser.refresh()
	var browsing: bool = category=="objects" and not (canvas.selected_object>=0 and canvas.mode=="objects")
	object_browser.visible = browsing
	object_browser.set_stamp_rotation(canvas.stamp_rotation)
	object_browser.rotation_button.disabled = canvas.mode == "run"
	editor_palette.visible = not browsing
	for key: String in editor_mode_buttons: (editor_mode_buttons[key] as Button).set_pressed_no_signal(key == category)
	surface_toolbar.visible = category == "paint"
	var track_title: Label = root_ui.find_child("TrackName",true,false)
	if track_title != null: track_title.custom_minimum_size.x = 220
	if category == "paint":
		if canvas.brush_surface == 0: canvas.brush_surface = 2
		_build_surface_toolbar()
	if category == "road":
		var piece: Dictionary = canvas.ghost if not canvas.ghost.is_empty() else document.pieces[canvas.selected_piece] if canvas.selected_piece >= 0 else {}
		if piece.is_empty():
			_context_button("Start line","race",canvas.choose_start_line)
			for kind: String in RoadPieces.KINDS:
				_context_button(preload("res://editor/road_piece_catalog.gd").title(kind),kind,canvas.choose_piece.bind(kind))
			editor_status.text = "Choose a section · drag empty ground to pan · pinch to zoom"
		elif editor_geometry != "" and piece.kind == "bridge":
			_context_button("Back","back",func() -> void:
				editor_geometry = ""
				_build_editor_tools())
			var key: String = "radius" if piece.kind == "s_bend" and editor_geometry == "length" else editor_geometry
			_context_button("- 5 deg" if key == "angle" else "- 1 m","minus",_change_piece.bind(key,-5.0 if key == "angle" else -1.0))
			_context_button(("Straight length" if key == "length" and piece.kind == "hairpin" else "Lead-in" if key == "length" and piece.kind not in ["straight","bridge"] else key.capitalize())+(" %.0f deg" if key == "angle" else " %.1f m") % (RoadPieces.height(piece) if key == "height" else float(piece.get(key,90.0))),"width",func() -> void: pass)
			_context_button("+ 5 deg" if key == "angle" else "+ 1 m","plus",_change_piece.bind(key,5.0 if key == "angle" else 1.0))
			if key != "width" and piece.kind == "hairpin": _context_button("Radius" if key == "length" else "Straight length" if piece.kind == "hairpin" else "Lead-in","curve",func() -> void:
				editor_geometry = "radius" if key == "length" else "length"
				_build_editor_tools())
			if piece.kind == "s_bend" and key != "height": _context_button("Height","width",func() -> void:
				editor_geometry = "height"
				_build_editor_tools())
			if piece.kind == "curve" and key != "angle": _context_button("Angle","curve",func() -> void:
				editor_geometry = "angle"
				_build_editor_tools())
			editor_status.text = "Both straight arms change equally; 0 m makes a plain U-turn. Radius stays separate." if piece.kind == "hairpin" and key == "length" else "Only this section changes. Reconnect any open ends afterwards."
		else:
			if piece.kind == "spline":
				_context_button(GameText.message("Point %d/5") % (canvas.spline_point+1),"spline",func() -> void:
					canvas.spline_point = (canvas.spline_point+1)%5
					_build_editor_tools())
				_context_button("Width −","minus",_change_piece.bind("point_width",-0.5))
				_context_button(GameText.message("%.1f m") % float(piece.point_widths[canvas.spline_point]),"width",func() -> void: pass)
				_context_button("Width +","plus",_change_piece.bind("point_width",0.5))
			if piece.kind == "bridge":
				_context_button("Shape",piece.kind,func() -> void:
					editor_geometry = "length" if piece.kind in ["straight","bridge"] else "radius"
					_build_editor_tools())
				if piece.kind == "hairpin": _context_button("Straight length","straight",func() -> void:
					editor_geometry = "length"
					_build_editor_tools())
				_context_button("Width","width",func() -> void:
					editor_geometry = "width"
					_build_editor_tools())
				_context_button("Rotate","rotate",_change_piece.bind("heading",15.0))
			_context_button("Flip","flip",_change_piece.bind("flip",1.0))
			_context_button("Snap on" if canvas.snap_enabled else "Snap off","snap",func() -> void:
				canvas.snap_enabled = not canvas.snap_enabled
				canvas.snap_matched = false
				_build_editor_tools(),canvas.snap_enabled)
			_context_button("Cancel" if not canvas.ghost.is_empty() else "Delete","delete",_delete_piece)
			if canvas.ghost.is_empty():
				_context_button("Connect","snap",canvas.connect_nearby)
				_context_button("Layer","surface",canvas.cycle_piece)
			editor_status.text = "Drag inside to move · end dots resize and turn · ✓ to place" if not canvas.ghost.is_empty() else "Drag inside to move · drag end dots to reshape · Layer selects overlapping roads"
			if piece.kind == "bridge": editor_status.text = "Bridge: ramps at both ends · ground road passes beneath the middle"
			if piece.kind == "spline": editor_status.text = "Drag the five numbered points · select a point to set its width · ✓ to place"
	elif category == "paint":
		for pair: Array in [[1,"Grass"],[2,"Sand"],[3,"Water"]]:
			_context_button(pair[1],"terrain_dirt" if pair[0] == 2 else "terrain_"+pair[1].to_lower(),func() -> void:
				canvas.brush_surface = pair[0]
				canvas.mode = "paint"
				_build_editor_tools(),canvas.mode == "paint" and canvas.brush_surface == pair[0])
		_context_button("Puddle","terrain_puddle",_choose_hazard.bind("puddle"))
		_build_paint_tools()
		editor_status.text = "Drag to paint freely" if canvas.paint_mode == "free" else "Tap to add points / drag dots to reshape / confirm to place"
	elif category == "objects":
		if canvas.selected_object >= 0 and canvas.mode == "objects":
			editor_status.text=CreatorObjects.description(document.objects[canvas.selected_object].kind)
			_context_button("Rotate","rotate",_rotate_object).tooltip_text = "Rotate by 22.5°"
			var rotation_choice: Button = _context_button(preload("res://editor/object_rotation.gd").angle_text(_object_rotation()),"rotate",_object_rotation_dialog)
			rotation_choice.name = "ObjectRotation"
			rotation_choice.tooltip_text = "16 orientations or Free rotation"
			_context_button("Copy","objects",_duplicate_object)
			if document.objects[canvas.selected_object].kind == "speed_bump":
				_context_button("Width -","minus",func() -> void: _resize_speed_bump(-0.5))
				_context_button("Width +","plus",func() -> void: _resize_speed_bump(0.5))
				_context_button("Fit road","snap",_fit_speed_bump)
				editor_status.text = GameText.message("%.2f m / Drag end dots to set width") % CreatorObjects.size_of(document.objects[canvas.selected_object]).y
			elif document.objects[canvas.selected_object].kind not in ["tyre_wall","tyre_stack"]:
				_context_button("Size -","minus",func() -> void: _scale_object(-0.25))
				_context_button("Size +","plus",func() -> void: _scale_object(0.25))
				editor_status.text = GameText.message("%s / %.2fx") % [CreatorObjects.description(document.objects[canvas.selected_object].kind),float(document.objects[canvas.selected_object].get("scale",1.0))]
			_context_button("Delete","delete",_delete_selection)
			if document.objects[canvas.selected_object].kind == "container":
				editor_context.add_child(ContainerColorButton.make(ContainerPaint.value(document.objects[canvas.selected_object]),_container_colour))
			if canvas.issue_marker != Vector2.INF: _context_button("Move start","race",canvas.choose_start_line)
			_context_button("Palette","more",func() -> void:
				canvas.selected_object = -1
				_build_editor_tools())
		else:
			editor_status.text = CreatorCatalog.label(canvas.stamp_kind)+" / "+("Drag a curve; release to place" if canvas.run_shape=="curve" else "Drag a line, or tap its two ends" if canvas.mode=="run" else "Tap empty ground to place / tap an object to edit")
			if canvas.mode=="objects": editor_status.text="Tap an object to move, rotate or delete"

	var context_width: float = 0
	for child: Control in editor_context.get_children(): context_width += child.get_combined_minimum_size().x+6
	(editor_context.get_parent() as ScrollContainer).custom_minimum_size.x = clampf(context_width,320,maxf(320,canvas.size.x-260))
	_update_editor_save_state()
	canvas.refresh()

func _change_piece(key: String, delta: float) -> void:
	var is_ghost: bool = not canvas.ghost.is_empty()
	if not is_ghost and canvas.selected_piece < 0: return
	var piece: Dictionary = (canvas.ghost if is_ghost else document.pieces[canvas.selected_piece]).duplicate(true)
	var before: Dictionary = piece.duplicate(true)
	if piece.kind == "s_bend" and key == "length": return
	if key == "point_width" and piece.kind == "spline": piece = SplineRoad.with_width(piece,canvas.spline_point,float(piece.point_widths[canvas.spline_point])+delta)
	elif key == "flip": piece.flip = not piece.flip
	elif key == "heading": piece.heading = fposmod(float(piece.heading)+delta,360.0)
	else:
		var lower: float = 5.0 if key == "angle" else 6.0 if key == "width" else 2.0 if key == "height" else 3.0 if key == "radius" else 24.0 if piece.kind == "bridge" else 2.0 if piece.kind == "straight" else 0.0
		var upper: float = 270.0 if key == "angle" else 20.0 if key == "width" else 60.0 if key in ["radius","height"] else 120.0
		piece[key] = clampf((RoadPieces.height(piece) if key == "height" else float(piece.get(key,90.0)))+delta,lower,upper)
	piece = canvas.anchored_change(before,piece,key)
	var errors: Array[String] = RoadPieces.validate(piece)
	if not errors.is_empty():
		editor_status.text = errors[0]
		return
	if not canvas._valid_bridge_edit(piece,canvas.selected_piece): return
	if is_ghost:
		canvas.ghost = piece
		canvas.snap_matched = false
	else:
		_remember()
		document.pieces[canvas.selected_piece] = piece
		_save_draft(true)
	_build_editor_tools()

func _delete_piece() -> void:
	if not canvas.ghost.is_empty(): canvas.ghost.clear()
	elif canvas.selected_piece >= 0:
		_remember()
		document.pieces.remove_at(canvas.selected_piece)
		canvas.selected_piece = -1
		_save_draft(true)
	editor_geometry = ""
	_build_editor_tools()

func _practice_start(track: NativeTrack) -> Vector2:
	if document.has("start_line"): return Vector2(document.start_line.position[0],document.start_line.position[1])
	if document.has("practice_start"): return Vector2(document.practice_start.position[0],document.practice_start.position[1])
	if document.pieces.is_empty(): return track.spawn
	var samples: PackedVector2Array = RoadPieces.samples(document.pieces[0])
	return samples[mini(6,samples.size()-1)]

func _practice_heading(track: NativeTrack) -> float:
	if document.has("start_line"): return PI*0.5-deg_to_rad(float(document.start_line.heading))
	if document.has("practice_start"): return PI*0.5-deg_to_rad(float(document.practice_start.heading))
	if document.pieces.is_empty(): return track.spawn_heading
	var samples: PackedVector2Array = RoadPieces.samples(document.pieces[0])
	var index: int = mini(6,samples.size()-1)
	var tangent: Vector2 = samples[mini(index+1,samples.size()-1)]-samples[maxi(0,index-1)]
	return atan2(tangent.x,tangent.y)

func _update_editor_issues() -> void:
	if not is_instance_valid(canvas) or not is_instance_valid(editor_issue_button): return
	var previous: Dictionary = editor_issues[editor_issue_cursor] if editor_issue_cursor >= 0 and editor_issue_cursor < editor_issues.size() else {}
	editor_issues.clear()
	canvas.issue_marker = Vector2.INF
	var track: NativeTrack = canvas.native_preview
	if track != null:
		var start: Vector2 = _practice_start(track)
		var config: HandlingConfig = HandlingSelection.config()
		var radius: float = config.collision_radius
		var elevated: bool = track.collision_elevated_at(start,track.nearest_route(start),radius)
		if track.overlaps_obstacle(start,radius,elevated):
			for i: int in range(document.objects.size()):
				var object: Dictionary = document.objects[i]
				if CreatorObjects.surface(object.kind) not in [3,4]: continue
				var local: Vector2 = (start-Vector2(object.position[0],object.position[1])).rotated(-deg_to_rad(float(object.rotation)))
				var half: Vector2 = CreatorObjects.size_of(object)*0.5
				if local.distance_to(local.clamp(-half,half)) <= radius+track.cell_size*0.71:
					editor_issues.append({"message":GameText.message("%s blocks the start") % str(object.kind).capitalize(),"position":start,"object":i})
			if editor_issues.is_empty(): editor_issues.append({"message":"Obstacle overlaps the starting car","position":start,"object":-2})
	for join: Dictionary in RoadPieces.joins(document.pieces):
		editor_issues.append({"message":join.message,"position":join.position,"object":-1,"index":join.index,"endpoint":join.endpoint})
	editor_issue_cursor = editor_issues.find(previous)
	editor_issue_button.text = GameText.message("Issue %d/%d") % [editor_issue_cursor+1,editor_issues.size()] if editor_issue_cursor >= 0 else GameText.plural("{count} issue","{count} issues",editor_issues.size())
	editor_issue_button.tooltip_text = "Tap to focus the next issue."
	editor_issue_button.visible = not editor_issues.is_empty()
	_update_test_access()
	canvas.queue_redraw()

func _update_test_access() -> void:
	if not is_instance_valid(test_button) or not is_instance_valid(canvas): return
	var has_road: bool = not document.pieces.is_empty() or not document.layout.is_empty() or not document.paint.is_empty() or document.base_track != ""
	test_button.disabled = editor_commits.unsettled() or editor_preview_thread != null or not (editor_validation_errors if document == editor_validation_document else TrackDocument.validate(document)).is_empty() or not has_road or _has_pending_editor_work()
	for issue: Dictionary in editor_issues:
		if int(issue.object) != -1: test_button.disabled = true

func _focus_issue() -> void:
	if editor_issues.is_empty(): return
	if _has_pending_editor_work():
		_resolve_editor_previews(_focus_issue)
		return
	editor_issue_cursor = (editor_issue_cursor+1)%editor_issues.size()
	var issue: Dictionary = editor_issues[editor_issue_cursor]
	_editor_category("objects" if int(issue.object) >= 0 else "paint" if int(issue.object) == -2 else "road")
	canvas.mode = "objects" if int(issue.object) >= 0 else "paint" if int(issue.object) == -2 else "road"
	canvas.issue_marker = issue.position
	canvas.issue_text = issue.message
	canvas.pan += canvas.size*0.5-canvas.to_screen(issue.position)
	if int(issue.object) >= 0: canvas.selected_object = issue.object
	elif int(issue.object) == -1: canvas.selected_piece = issue.index
	_build_editor_tools()
	editor_issue_button.text = GameText.message("Issue %d/%d") % [editor_issue_cursor+1,editor_issues.size()]
	_editor_hint(issue.message+" · paint Road over the obstacle, or place a Start line." if int(issue.object) == -2 else issue.message+" · drag to repair, or delete the selection.")
	canvas.refresh()

func _commit_selection() -> void:
	if canvas.mode in ["move","add"]: document.route_override = true
	canvas.refresh()
	_save_draft(true)
	_build_editor_tools()

func _delete_selection() -> void:
	if canvas.mode in ["objects","place","run"]:
		if canvas.selected_object < 0: return
		_remember()
		document.objects.remove_at(canvas.selected_object)
		canvas.selected_object = -1
	else: return
	_commit_selection()

func _rotate_object() -> void:
	_set_object_rotation(preload("res://editor/object_rotation.gd").next_angle(_object_rotation()))

func _object_rotation() -> float:
	return float(document.objects[canvas.selected_object].rotation) if canvas.selected_object >= 0 else canvas.stamp_rotation

func _set_object_rotation(value: float) -> void:
	if not is_finite(value): return
	var angle: float = fposmod(value,360.0)
	canvas.stamp_rotation = angle
	if canvas.selected_object >= 0 and not is_equal_approx(float(document.objects[canvas.selected_object].rotation),angle):
		_remember()
		document.objects[canvas.selected_object].rotation = angle
		_commit_selection()
	else: _build_editor_tools()
	object_browser.set_stamp_rotation(angle)

func _object_rotation_dialog() -> void:
	if root_ui.find_child("ObjectRotationDialog",true,false) != null: return
	if is_instance_valid(object_browser.options): object_browser.options.hide()
	canvas.cancel_gesture()
	var dialog := preload("res://editor/object_rotation.gd").new()
	dialog.angle = _object_rotation()
	var owner_canvas: EditorCanvas = canvas
	var source: Dictionary = document
	var selection: int = canvas.selected_object
	var kind: String = canvas.stamp_kind
	dialog.confirmed.connect(func() -> void:
		if not is_instance_valid(owner_canvas) or canvas != owner_canvas or screen != "create": return
		if not is_same(document,source) or canvas.selected_object != selection or canvas.stamp_kind != kind: return
		if dialog.free_rotation: dialog.field.apply()
		_set_object_rotation(dialog.angle))
	_own_dialog(dialog)
	dialog.popup_centered_clamped(Vector2i(410,360))

func _scale_object(delta: float) -> void:
	if canvas.selected_object < 0: return
	if document.objects[canvas.selected_object].kind == "speed_bump":
		_resize_speed_bump(delta*4.0)
		return
	_remember()
	var object: Dictionary = document.objects[canvas.selected_object]
	object.scale = clampf(float(object.get("scale",1.0))+delta,0.5,1.5 if object.kind in CreatorCatalog.DECORATIVE else 3.0)
	_commit_selection()


func _resize_speed_bump(delta: float) -> void:
	if canvas.selected_object < 0: return
	var object: Dictionary = document.objects[canvas.selected_object]
	if object.kind != "speed_bump": return
	var span: float = clampf(CreatorObjects.size_of(object).y+delta,SpeedBumpEdit.MIN_SPAN,SpeedBumpEdit.MAX_SPAN)
	if is_equal_approx(span,CreatorObjects.size_of(object).y): return
	_remember()
	object["span"] = span
	document.objects[canvas.selected_object] = SpeedBumpEdit.serialize_ready(object)
	_commit_selection()


func _fit_speed_bump() -> void:
	if canvas.selected_object < 0: return
	var object: Dictionary = document.objects[canvas.selected_object]
	if object.kind != "speed_bump": return
	var fitted: Dictionary = SpeedBumpEdit.fit_road(document,object,canvas.native_preview)
	if fitted.is_empty():
		_editor_hint("Place the speed bump on a ground road first.")
		return
	if fitted == object: return
	_remember()
	document.objects[canvas.selected_object] = fitted
	_commit_selection()


func _duplicate_object() -> void:
	if canvas.selected_object < 0 or document.objects.size() >= preload("res://editor/creator_limits.gd").MAX_OBJECTS: return
	var object: Dictionary = document.objects[canvas.selected_object].duplicate(true)
	object.position = [clampf(float(object.position[0])+4,-110,110),clampf(float(object.position[1])+4,-110,110)]
	var admission: String = preload("res://editor/creator_limits.gd").addition_error(document.objects,[object],str(document.theme))
	if not admission.is_empty(): _editor_hint(admission); return
	_remember()
	document.objects.append(object)
	canvas.selected_object = document.objects.size()-1
	canvas.mode = "objects"
	_commit_selection()

func _remember() -> void:
	editor_session.remember(document)

func _set_document_value(key: String, value: Variant) -> void:
	if key in ["theme", "biome", "creator"]: return
	_remember()
	document[key] = value
	_save_draft(true)
	_show_screen("create")

func _undo() -> void:
	if history.is_empty(): return
	document = editor_session.restore(document,true)
	_restore_editor_history()

func _redo() -> void:
	if redo_history.is_empty(): return
	document = editor_session.restore(document,false)
	_restore_editor_history()

func _restore_editor_history() -> void:
	# Keep the viewport, camera and controls alive; stale worker results are
	# discarded by _process, without waiting for them in the input handler.
	canvas.changed_in_gesture = false
	canvas.cancel_gesture()
	canvas.ghost.clear()
	canvas.selected_piece = -1
	canvas.selected_object = -1
	canvas.document = document
	canvas.road_approval_pending = false
	var title: Label = root_ui.find_child("TrackName",true,false) as Label
	if title != null: title.text = str(document.name)
	canvas.refresh()
	_save_draft(true)
	_build_editor_tools()

func _refresh_editor() -> void:
	if not is_instance_valid(editor_status): return
	var errors: Array[String] = TrackDocument.validate(document)
	editor_status.text = "Waypoints are generated from connected roads. Changes save automatically." if errors.is_empty() else errors[0]
	test_button.disabled = not errors.is_empty()
	publish_button.disabled = not errors.is_empty() or lifecycle == null or not lifecycle.ready_to_publish(document)
	share_button.disabled = not errors.is_empty()
	if is_instance_valid(canvas): canvas.refresh()

func _editor_copy_is_current(snapshot: Dictionary, storage: TrackLibrary, relative_path: String, disk_hash: String) -> bool:
	if storage != library or document != snapshot or disk_hash.is_empty(): return false
	var path: String = library.directory.path_join(relative_path)
	return FileAccess.file_exists(path) and FileAccess.get_sha256(path) == disk_hash

func _apply_editor_writes() -> void:
	for receipt: Dictionary in editor_writes.completed:
		var storage: TrackLibrary = receipt.storage
		if receipt.error == OK: storage.revision += 1
		if storage != library: continue
		if receipt.document != document:
			if receipt.error != OK and str(receipt.document.get("id","")) == str(document.get("id","")):
				editor_save_error = receipt.error; editor_save_message = "Could not save: "+str(receipt.message)
				if not _editor_exiting and is_inside_tree(): _editor_hint(editor_save_message); _update_editor_save_state()
			continue
		library.last_error = receipt.message
		if receipt.error != OK or not editor_retry_original:
			editor_save_error = receipt.error
			editor_save_message = "Could not save: "+str(receipt.message) if receipt.error != OK else ""
		if receipt.error == OK:
			editor_wip_snapshot = receipt.document.duplicate(true); editor_wip_store = storage; editor_wip_disk_hash = receipt.digest
			editor_wip_saved = TrackLibrary.draft_fingerprint(receipt.document)
			if is_instance_valid(editor_status) and editor_status.text == "Saving...": editor_status.text = "WIP autosaved. Saved original unchanged."
		elif not _editor_exiting and is_inside_tree(): _editor_hint(editor_save_message)
		if not _editor_exiting and is_inside_tree(): _update_editor_save_state()
	editor_writes.completed.clear()

func _apply_editor_commits() -> void:
	for receipt: Dictionary in editor_commits.completed:
		# A newer in-progress gesture must not discard the preceding committed
		# revision's recovery write. Analysis and writes both preserve order.
		if not receipt.has("error"): editor_writes.enqueue(receipt.storage,receipt.document)
		if not editor_session.accept(receipt,library,document): continue
		if receipt.has("error"):
			editor_save_error = receipt.error; editor_save_message = "Could not prepare the draft for saving. Use Save to retry."
			if not _editor_exiting and is_inside_tree(): _editor_hint(editor_save_message)
			continue
		# Preserve the bound dictionary, selection and session identity.
		for key: String in ["points","widths","corners","route_override"]:
			document[key] = receipt.document[key]
		if not editor_retry_original: editor_save_error = OK; editor_save_message = ""
		if not _editor_exiting and is_inside_tree() and is_instance_valid(canvas) and canvas.is_inside_tree() and canvas.document == document:
			canvas.refresh()
			if canvas.native_preview != null and canvas.native_preview.metadata.get("creator_document",{}) == document:
				_update_editor_issues()
			else:
				if _objects_only_edit(): editor_world.preview_objects(document)
				_queue_editor_preview()
			if is_instance_valid(editor_undo): editor_undo.disabled = history.is_empty()
			if is_instance_valid(editor_redo): editor_redo.disabled = redo_history.is_empty()
			publish_button.disabled = not editor_validation_errors.is_empty() or lifecycle == null or lifecycle.no_publishing_slots() or not bool(editor_workflow_presentation.get("ready",false))
			share_button.disabled = not editor_validation_errors.is_empty()
		if not _editor_exiting and is_inside_tree(): _update_editor_save_state()
	editor_commits.completed.clear()

func _flush_editor_writes() -> void:
	editor_commits.flush(); _apply_editor_commits()
	editor_writes.flush(); _apply_editor_writes()

func _save_draft(background_preview: bool = false) -> Error:
	var deferred_write: bool = background_preview and is_instance_valid(canvas) and library.get_script() == preload("res://persistence/track_library.gd")
	if deferred_write:
		if document.is_empty(): return ERR_INVALID_DATA
		_stamp_creator()
		editor_session.enqueue(library,document,lifecycle._root() if lifecycle != null else "")
		editor_commits.poll()
		test_button.disabled = true; publish_button.disabled = true; share_button.disabled = true
		if is_instance_valid(editor_status): editor_status.text = "Saving..."
		_update_editor_save_state()
		return OK
	if not deferred_write: _flush_editor_writes()
	if not background_preview: _finish_preview_thread()
	if document.is_empty(): return ERR_INVALID_DATA
	_stamp_creator()
	if not document.pieces.is_empty():
		if document.pieces != editor_route_pieces or editor_route_fields.is_empty():
			var auto_route: Dictionary = RoadPieces.route_from_pieces(document)
			if auto_route.ok:
				editor_route_pieces = document.pieces.duplicate(true)
				editor_route_fields.clear()
				for key: String in ["points","widths","corners","route_override"]: editor_route_fields[key] = auto_route.document[key]
		if document.pieces == editor_route_pieces:
			for key: String in editor_route_fields: document[key] = editor_route_fields[key].duplicate(true) if editor_route_fields[key] is Array else editor_route_fields[key]
	var errors: Array[String] = TrackDocument.validate(document)
	var message: String
	# A successful immutable snapshot belongs to this exact local library.
	# Missing primaries and failed writes still take the real recovery path.
	# A durable match can still be overwritten by an older in-flight revision.
	# Queue this final state after it; enqueue coalesces only unstarted writes.
	var wip_current: bool = not editor_writes.unsettled(library,str(document.id)) and (editor_save_error == OK or editor_retry_original) and _editor_copy_is_current(editor_wip_snapshot,editor_wip_store,"wip/"+str(document.id)+".json",editor_wip_disk_hash) and not library.is_published(str(document.id))
	var save_error: Error = OK if wip_current else editor_writes.enqueue(library,document) if deferred_write else library.save_wip(document)
	if wip_current: library.last_error = ""
	if save_error != OK or not editor_retry_original:
		editor_save_error = save_error
		editor_save_message = "Could not save: "+library.last_error if save_error != OK else ""
	if save_error == OK and not wip_current and not deferred_write:
		editor_wip_saved = TrackLibrary.draft_fingerprint(document)
		editor_wip_snapshot = document.duplicate(true)
		editor_wip_store = library
		editor_wip_disk_hash = FileAccess.get_sha256(library.directory.path_join("wip/"+str(document.id)+".json"))
	if save_error != OK: message = "Could not save: " + library.last_error
	elif deferred_write and not wip_current: message = "Saving..."
	elif not errors.is_empty(): message = "Draft saved. Before driving: " + errors[0]
	else: message = "WIP autosaved. Saved original unchanged."
	if is_instance_valid(editor_status):
		editor_status.text = message
		test_button.disabled = not errors.is_empty()
		publish_button.disabled = not errors.is_empty() or lifecycle == null or not lifecycle.ready_to_publish(document)
		share_button.disabled = not errors.is_empty()
	_update_editor_save_state()
	if save_error != OK: _editor_hint(editor_save_message)
	# Refresh action availability after each edit, without rebuilding under a finger.
	if is_instance_valid(canvas):
		if is_instance_valid(editor_undo): editor_undo.disabled = history.is_empty()
		if is_instance_valid(editor_redo): editor_redo.disabled = redo_history.is_empty()
		if background_preview:
			canvas.queue_redraw()
			if canvas.native_preview != null and canvas.native_preview.metadata.get("creator_document",{}) == document:
				_update_editor_issues()
			else:
				if _objects_only_edit(): editor_world.preview_objects(document)
				test_button.disabled = true
				_queue_editor_preview()
		else:
			var preview_track: NativeTrack = canvas.native_preview if TrackLifecycle.prepared_test_matches(document,canvas.native_preview) else _editor_track_preview()
			if preview_track != null and preview_track != canvas.native_preview: canvas.show_native(preview_track)
			_update_editor_issues()
	return save_error

func _test_document() -> void:
	if is_instance_valid(canvas) and canvas.active_pointer != -99:
		_editor_hint("Release the track before testing.")
		return
	if _has_pending_editor_work():
		_notice("Confirm or cancel the pending previews before testing.")
		return
	if not canvas.paint_points.is_empty():
		_notice("Confirm or cancel the surface preview first.")
		return
	if not canvas.ghost.is_empty():
		editor_status.text = "Confirm or cancel the preview before testing."
		return
	if _save_draft() != OK: return
	var prepared: NativeTrack = canvas.native_preview
	if not await _prepare_creator_test(document,prepared): return
	# Practice owns its mutable spawn/contact helpers. The editor's exact
	# compiled snapshot remains available for the next edit and test cycle.
	var track: NativeTrack = preload("res://editor/prepared_track_cache.gd").copy_track(prepared) if prepared != null else null
	if track != null and not test_button.disabled:
		track.spawn = _practice_start(track)
		track.spawn_heading = _practice_heading(track)
		await _start_race(track, true)

func _publish_current_document() -> void:
	if _has_pending_editor_work():
		_notice("Confirm or cancel the preview before publishing.")
		return
	if _save_draft() != OK: return
	await _publish_saved_draft("wip:"+str(document.id))

func _share_dialog() -> void:
	if not canvas.paint_points.is_empty():
		_notice("Confirm or cancel the surface preview first.")
		return
	if _save_draft() != OK:
		_notice("Could not save: "+library.last_error)
		return
	var dialog := AcceptDialog.new()
	dialog.title = "Share your circuit"
	dialog.dialog_text = "Copy this circuit and send it to a friend. They can paste it into Import.\nLocal creation and racing shared circuits are free."
	dialog.ok_button_text = "Done"
	dialog.add_button("Copy circuit", false, "copy")
	dialog.add_button("Export file", false, "file")
	dialog.custom_action.connect(func(action: StringName) -> void:
		if action == &"copy":
			DisplayServer.clipboard_set(JSON.stringify(document))
			dialog.dialog_text = "Circuit copied. Your friend can paste it into Tracks > Import a circuit."
		else: _export_file())
	_own_dialog(dialog)
	dialog.popup_centered(Vector2i(650,220))

func _export_file() -> void:
	var dialog := FileDialog.new()
	dialog.title = "Export circuit"
	dialog.file_mode = FileDialog.FILE_MODE_SAVE_FILE
	dialog.access = FileDialog.ACCESS_FILESYSTEM
	dialog.filters = PackedStringArray(["*.json ; Circuit file"])
	dialog.current_file = str(document.id) + ".json"
	dialog.file_selected.connect(func(path: String) -> void:
		if library.export_document(document, path) == OK: _notice("Circuit exported.")
		else: _notice("Export failed: " + library.last_error))
	_own_dialog(dialog)
	dialog.popup_centered_ratio(0.8)

func _import_dialog() -> void:
	var dialog := ConfirmationDialog.new()
	dialog.title = "Import a circuit"
	dialog.ok_button_text = "Import"
	var layout := VBoxContainer.new()
	dialog.add_child(layout)
	layout.add_child(MenuStyle.label("Paste a shared circuit below, or choose a circuit file.",18))
	var text := TextEdit.new()
	text.custom_minimum_size = Vector2(620,220)
	text.placeholder_text = "Paste circuit data here"
	layout.add_child(text)
	layout.add_child(MenuStyle.button("Paste from clipboard", func() -> void:
		var copied: String = DisplayServer.clipboard_get()
		if copied.to_utf8_buffer().size() <= TrackDocument.MAX_BYTES: text.text = copied
		else: _notice("That circuit is too large to import.")))
	layout.add_child(MenuStyle.button("Choose file", func() -> void:
		var picker := FileDialog.new()
		picker.file_mode = FileDialog.FILE_MODE_OPEN_FILE
		picker.access = FileDialog.ACCESS_FILESYSTEM
		picker.filters = PackedStringArray(["*.json ; Circuit file"])
		picker.file_selected.connect(func(path: String) -> void:
			var imported: Dictionary = library.import_document(path)
			if imported.is_empty(): _notice(library.last_error)
			else: _accept_import(imported))
		_own_dialog(picker)
		picker.popup_centered_ratio(0.8)))
	dialog.confirmed.connect(func() -> void:
		if text.text.to_utf8_buffer().size() > TrackDocument.MAX_BYTES:
			_notice("That circuit is too large to import.")
			return
		var parsed: Variant = JSON.parse_string(text.text)
		var errors: Array[String] = TrackDocument.validate(parsed)
		if not errors.is_empty(): _notice(errors[0])
		else: _accept_import(parsed))
	_own_dialog(dialog)
	dialog.popup_centered()

func _accept_import(imported: Dictionary) -> void:
	if not document.is_empty() and not TrackDocument.validate(document).is_empty():
		_notice("Fix or undo your unsaved route change before importing another circuit.")
		return
	_save_draft()
	editor_view.clear()
	canvas = null
	document = imported.duplicate(true)
	# Import as a new local draft: never replace an existing author's work by ID.
	document.id = TrackLibrary.unique_id()
	_stamp_creator()
	history.clear()
	redo_history.clear()
	_save_draft()
	_show_screen("create")

func _notice(message: String) -> void:
	var dialog := preload("res://ui/fault_dialog.gd").new()
	dialog.dialog_text = message
	_own_dialog(dialog)
	dialog.popup_message()

func _popup_node_added(node: Node) -> void:
	if node is Window and is_ancestor_of(node):
		preload("res://ui/popup_style.gd").watch(node)

func _own_dialog(dialog: AcceptDialog) -> void:
	# Practice suspends the retained editor. Its owned windows must still take
	# input without enabling the editor underneath the active race.
	dialog.process_mode = Node.PROCESS_MODE_ALWAYS
	root_ui.add_child(dialog)
	preload("res://ui/popup_style.gd").watch(dialog)
	dialog.confirmed.connect(dialog.queue_free)
	dialog.canceled.connect(dialog.queue_free)
	if dialog is FileDialog:
		dialog.file_selected.connect(func(_path: String) -> void: dialog.queue_free())

var test_return_to_drafts: bool = false
var test_document_snapshot: Dictionary = {}
var _practice_editor_context: Dictionary = {}
var _race_menu_processing: Dictionary = {}

func _race_menu_visible(value: bool) -> void:
	if not is_instance_valid(root_ui): return
	var identity: int = root_ui.get_instance_id()
	if not value:
		if _race_menu_processing.get("root",0) != identity:
			_race_menu_processing = {"root":identity,"mode":root_ui.process_mode}
		root_ui.process_mode = Node.PROCESS_MODE_DISABLED
	else:
		if _race_menu_processing.get("root",0) == identity: root_ui.process_mode = _race_menu_processing.mode
		_race_menu_processing.clear()
	root_ui.visible = value
var _draft_test_save_context: Dictionary = {}
var _draft_test_save_dialog: AcceptDialog

func _open_race_loading(track: NativeTrack = null, practice: bool = false) -> RaceLoading:
	if product_telemetry != null: product_telemetry.set_transport_allowed(false)
	if discovery_provider != null: discovery_provider.comparisons.cancel_speculation()
	_stop_menu_page_motion()
	race_loading = RaceLoading.new()
	add_child(race_loading)
	var deadline := Timer.new()
	deadline.name = "RaceLoadingDeadline"
	deadline.process_mode = Node.PROCESS_MODE_ALWAYS
	deadline.one_shot = true
	race_loading.add_child(deadline)
	deadline.timeout.connect(_race_loading_timed_out.bind(race_loading.get_instance_id()))
	deadline.start(RACE_LOAD_DEADLINE_SECONDS)
	if track != null:
		race_loading.configure(track_title(track), str(track.metadata.get("theme", "pine")), track.route, practice)
	return race_loading

func _present_race_loading() -> bool:
	# Layout and actually draw the overlay before synchronous scene construction.
	await get_tree().process_frame
	if DisplayServer.get_name() == "headless": return false
	# Minimized/suspended windows may stop emitting frame_post_draw entirely.
	# Wait for an actual draw normally, but never make it an unbounded race gate.
	var drawn: Dictionary = {"done": false}
	var observe: Callable = func() -> void: drawn.done = true
	RenderingServer.frame_post_draw.connect(observe, CONNECT_ONE_SHOT)
	var began: int = Time.get_ticks_msec()
	while not drawn.done and Time.get_ticks_msec() - began < RACE_LOAD_DRAW_WAIT_MSEC:
		await get_tree().process_frame
	if RenderingServer.frame_post_draw.is_connected(observe):
		RenderingServer.frame_post_draw.disconnect(observe)
	return drawn.done

func _race_loading_matches(expected_id: int) -> bool:
	return is_instance_valid(race_loading) and race_loading.get_instance_id() == expected_id

func _race_preparation_changed(expected_id: int, scope: String, navigation: int, starting_screen: String, vehicle: String, selection: NativeTrack) -> bool:
	if not _race_loading_matches(expected_id): return true
	# Navigation cancels intentionally. Changes on the same page need feedback.
	if navigation != _navigation_generation or starting_screen != screen:
		_close_race_loading(expected_id)
		return true
	var reason: String = ""
	if scope != lifecycle.scope(): reason = "Account changed while preparing the race. Try again."
	elif vehicle != VehicleCatalog.selected: reason = "Car changed while preparing the race. Try again."
	elif selection != selected_track: reason = "Track changed while preparing the race. Try again."
	if reason.is_empty(): return false
	cloud_ticket = {}
	_close_race_loading(expected_id)
	_notice(reason)
	return true

func _race_loading_timed_out(expected_id: int) -> void:
	if not _race_loading_matches(expected_id): return
	push_warning("Race preparation timed out at stage: " + race_loading.status_label.text)
	# A partially constructed world is still disabled and has no race result.
	if is_instance_valid(game) and game.process_mode == Node.PROCESS_MODE_DISABLED:
		_discard_preparing_game(game)
	cloud_ticket = {}
	cloud_starting = false
	_close_race_loading(expected_id)
	_race_menu_visible(true)
	_show_screen(screen)
	_notice("Race loading timed out. Try again.")

func _close_race_loading(expected_id: int = 0) -> void:
	if not is_instance_valid(race_loading): return
	if expected_id != 0 and race_loading.get_instance_id() != expected_id: return
	cloud_starting = false
	remove_child(race_loading)
	race_loading.queue_free()
	race_loading = null

func _prepare_metadata_race(track: NativeTrack, from_editor: bool, offline_only: bool, issued: Dictionary) -> void:
	var scope: String = lifecycle.scope()
	var navigation: int = _navigation_generation
	var starting_screen: String = screen
	var vehicle: String = VehicleCatalog.selected
	var selection: NativeTrack = selected_track
	var entry: Dictionary = track.metadata.cloud_entry.duplicate(true)
	var overlay: RaceLoading = _open_race_loading(track,from_editor)
	var overlay_id: int = overlay.get_instance_id()
	cloud_starting = true
	await _present_race_loading()
	if _race_preparation_changed(overlay_id,scope,navigation,starting_screen,vehicle,selection): return
	if not await _await_selected_preparation(track,overlay_id,scope,navigation,starting_screen,vehicle,selection): return
	if not track.metadata.get("metadata_only",false):
		cloud_starting = false
		await _start_race(track,from_editor,offline_only,issued,overlay)
		return
	overlay.stage("Downloading track...")
	var downloaded: Dictionary = await cloud.download_document(entry)
	if _race_preparation_changed(overlay_id,scope,navigation,starting_screen,vehicle,selection): return
	if downloaded.is_empty():
		_close_race_loading(overlay_id)
		_notice(cloud.last_error if not cloud.last_error.is_empty() else "Track download failed. Check your connection and try again.")
		return
	overlay.stage("Preparing track…")
	var ready: Variant = await online.client._background(cloud.compile_document.bind(entry,downloaded))
	if _race_preparation_changed(overlay_id,scope,navigation,starting_screen,vehicle,selection): return
	if not ready is NativeTrack:
		_close_race_loading(overlay_id)
		_notice("Track could not be prepared. Try again.")
		return
	# Keep the selected object identity, but hydrate every pinned geometry field
	# before the existing ticket/manifest checks and canonical scene construction.
	for property: Dictionary in ready.get_property_list():
		if int(property.usage) & PROPERTY_USAGE_SCRIPT_VARIABLE: track.set(property.name,ready.get(property.name))
	cloud.remember_compiled_entry(entry,track)
	track_catalog.remember_track(entry,track)
	cloud_starting = false
	await _start_race(track,from_editor,offline_only,issued,overlay)

func _start_race(track: NativeTrack, from_editor: bool, offline_only: bool = false, rivalry_issued: Dictionary = {}, prepared_loading: RaceLoading = null) -> void:
	if cloud_starting or (is_instance_valid(race_loading) and race_loading != prepared_loading): return
	if track == null:
		_notice("Choose a track before starting a race.")
		return
	var tutorial_lesson: bool = tutorial != null and tutorial.authorizes(track)
	if cloud != null and is_instance_valid(online.client.get("safety")) and not online.client.safety.allows(track.metadata.get("cloud_entry",track.metadata)):
		_notice("This player is blocked. Manage blocked players in Settings > Privacy > Community safety.")
		return
	if track.metadata.get("metadata_only",false):
		await _prepare_metadata_race(track,from_editor,offline_only,rivalry_issued)
		return
	if not from_editor and not track.metadata.has("cloud_version") and cloud != null and not tutorial_lesson:
		_notice("Choose a published backend track from Race.")
		return
	var original_scope: String = lifecycle.scope()
	var navigation_generation: int = _navigation_generation
	var starting_screen: String = screen
	var selected_vehicle: String = VehicleCatalog.selected
	var attempt_vehicle: String = rivalry.model.vehicle_id if not rivalry_issued.is_empty() and not rivalry_issued.has("challenge_code") else selected_vehicle
	var starting_selection: NativeTrack = selected_track
	var loading: RaceLoading = prepared_loading if is_instance_valid(prepared_loading) else _open_race_loading(track, from_editor)
	var loading_id: int = loading.get_instance_id()
	cloud_starting = true
	if prepared_loading == null: await _present_race_loading()
	if not _race_loading_matches(loading_id): return
	if _race_preparation_changed(loading_id,original_scope,navigation_generation,starting_screen,selected_vehicle,starting_selection): return
	if not await _await_selected_preparation(track,loading_id,original_scope,navigation_generation,starting_screen,selected_vehicle,starting_selection): return
	cloud_ticket = {}
	if not offline_only and not from_editor and track.metadata.has("cloud_version") and online.client.signed_in():
		loading.stage("Connecting race…")
		var issued: Dictionary = await cloud.ticket(track,false,attempt_vehicle,null,rivalry_issued) if not rivalry_issued.is_empty() else await cloud.ticket(track)
		if not _race_loading_matches(loading_id): return
		if _race_preparation_changed(loading_id,original_scope,navigation_generation,starting_screen,selected_vehicle,starting_selection): return
		cloud_ticket = issued
		if not cloud_ticket.is_empty():
			cloud_ticket._owner_id = str(online.client.player.id)
			cloud_ticket._origin = str(online.client.base_url())
			if rivalry_issued.has("challenge_code"): challenges.result_ticket = str(cloud_ticket.ticket_id)
			elif not rivalry_issued.is_empty(): rivalry.result_ticket = str(cloud_ticket.ticket_id)
		if cloud_ticket.is_empty():
			cloud_starting = false
			_close_race_loading(loading_id)
			var failure: String = cloud.last_error if not cloud.last_error.is_empty() else "Could not connect the race. Check your connection and try again."
			if not rivalry_issued.is_empty():
				if rivalry_issued.has("challenge_code"):
					challenges.error = failure
					_challenges()
				else:
					rivalry.error = failure
					_rivalry()
				_notice(failure)
				return
			var offline_dialog := ConfirmationDialog.new()
			offline_dialog.title = "Online race unavailable"
			offline_dialog.dialog_text = failure+"\nRace offline with a local time? This attempt will not enter the online leaderboard."
			offline_dialog.ok_button_text = "Race offline"
			_own_dialog(offline_dialog)
			offline_dialog.confirmed.connect(func() -> void:
				if navigation_generation == _navigation_generation and screen == starting_screen and VehicleCatalog.selected == selected_vehicle and selected_track == starting_selection:
					_start_race(track,from_editor,true))
			offline_dialog.popup_centered()
			return
	loading.stage("Loading track…")
	await _present_race_loading()
	if not _race_loading_matches(loading_id): return
	if _race_preparation_changed(loading_id,original_scope,navigation_generation,starting_screen,selected_vehicle,starting_selection): return
	var prepared_roads: Dictionary = {}
	if NativeTrackVisual.race_roads_need_preparation(track):
		var road_job = preload("res://editor/road_preparation_job.gd").start(track,get_tree())
		while not road_job.done:
			await get_tree().process_frame
			if _race_preparation_changed(loading_id,original_scope,navigation_generation,starting_screen,selected_vehicle,starting_selection):
				preload("res://race/selected_track_preparation.gd").cancel(road_job,get_tree())
				return
		prepared_roads = road_job.result if road_job.result is Dictionary else {}
		NativeTrackVisual.ROAD_DISK_CACHE.publish_arrays(prepared_roads.get("receipt",{}))
		prepared_roads.erase("receipt")
	returning_to_editor = from_editor
	challenge_racing = rivalry_issued.has("challenge_code")
	challenge_practice = offline_only and screen == "challenges" and not challenges.selected.is_empty()
	rivalry_racing = not rivalry_issued.is_empty() and not challenge_racing
	test_return_to_drafts = from_editor and screen == "drafts"
	test_document_snapshot = document.duplicate(true) if from_editor else {}
	if from_editor:
		test_library_snapshot = library
		test_scope_snapshot = lifecycle.scope() if lifecycle != null else ""
		test_vehicle_snapshot = VehicleCatalog.selected
	if not from_editor and not tutorial_lesson and records.settings.get("last_track","") != track.identity:
		var previous_track: String = str(records.settings.get("last_track",""))
		records.settings["last_track"] = track.identity
		if records.save_records() != OK:
			records.settings["last_track"] = previous_track
			pending_menu_notice = "This circuit could not be remembered for next time. Check available storage."
	if is_instance_valid(canvas):
		canvas.cancel_gesture()
		editor_view = {"zoom":canvas.zoom,"pan":canvas.pan,"mode":canvas.mode,"selected":canvas.selected,"selected_object":canvas.selected_object,"stamp_kind":canvas.stamp_kind,"stamp_scale":canvas.stamp_scale,"stamp_span":canvas.stamp_span,"stamp_container_color":canvas.stamp_container_color,"run_shape":canvas.run_shape,"free_run":canvas.free_run,"brush_surface":canvas.brush_surface,"brush_width":canvas.brush_width,"paint_mode":canvas.paint_mode,"brush_shape":canvas.brush_shape,"selected_piece":canvas.selected_piece}
	_stop_menu_page_motion()
	_practice_editor_context = {}
	if from_editor and screen == "create" and is_instance_valid(canvas) and canvas.document == document:
		_practice_editor_context = {"root":root_ui.get_instance_id(),"navigation":_navigation_generation,"mode":root_ui.process_mode}
	_race_menu_visible(false)
	game = GAME_SCENE.instantiate()
	game.profile_enabled = race_profile_enabled
	game.set("vehicle_id",attempt_vehicle)
	game.process_mode = Node.PROCESS_MODE_DISABLED
	game.cooperative_preparation = true
	game.preparation_current = _race_installation_current.bind(loading_id,original_scope,navigation_generation,starting_screen,selected_vehicle,starting_selection)
	game.set_meta("soundtrack_rivalry", rivalry_racing)
	game.set_meta("race_offline_only", offline_only)
	game.set_meta("tutorial_lesson", tutorial_lesson)
	if challenge_racing:
		game.set_meta("challenge_attempt",{"code":str(rivalry_issued.challenge_code),"stage":int(rivalry_issued.get("_challenge_stage",challenges.selected_stage)),"scope":challenges.scope()})
	game.set("initial_track", track)
	game.set("prepared_road_packet",prepared_roads)
	game.set("production_mode", true)
	game.set("resume_client",null if tutorial_lesson else online.client)
	game.set("resume_ticket_id",str(cloud_ticket.get("ticket_id","")))
	game.set("rating_records", null if tutorial_lesson or track.metadata.has("cloud_version") else records)
	game.set("preference_records", records)
	game.set("editor_test", from_editor)
	_prepare_race_rating(track)
	game.connect("exit_requested", _leave_race)
	game.connect("edit_here_requested", _edit_here)
	game.connect("race_completed", _results)
	game.connect("practice_lap_completed", _complete_draft_test,CONNECT_DEFERRED)
	game.connect("retry_requested", _retry_race)
	add_child(game)
	var prepared_game: Node = game
	while is_instance_valid(prepared_game) and game == prepared_game and not prepared_game.preparation_complete:
		await get_tree().process_frame
		if _race_preparation_changed(loading_id,original_scope,navigation_generation,starting_screen,selected_vehicle,starting_selection):
			_discard_preparing_game(prepared_game)
			return
	if not is_instance_valid(prepared_game) or game != prepared_game: return
	if is_instance_valid(prepared_game.world_render_preparation):
		loading.stage("Preparing graphics...")
		var stage_current: Callable = _race_installation_current.bind(loading_id,original_scope,navigation_generation,starting_screen,selected_vehicle,starting_selection)
		if not await prepared_game.world_render_preparation.prepare(_present_race_loading,stage_current):
			if is_queued_for_deletion(): return
			_race_preparation_changed(loading_id,original_scope,navigation_generation,starting_screen,selected_vehicle,starting_selection)
			if is_instance_valid(prepared_game): _discard_preparing_game(prepared_game)
			_close_race_loading(loading_id)
			return
	if rivalry_racing:
		game.ghost_mode = "race" if not rivalry_recording.is_empty() else "off"
		game.ghost_bests = {"race":rivalry_recording} if not rivalry_recording.is_empty() else {}
	elif challenge_racing or (offline_only and screen == "challenges"):
		game.ghost_mode = "race" if not challenge_recording.is_empty() else "off"
		game.ghost_bests = {"race":challenge_recording} if not challenge_recording.is_empty() else {}
	game.call("_prepare_personal_ghost")
	var hud: PlaygroundHUD = game.get("hud")
	if tutorial_lesson and hud.rewind_button != null: hud.rewind_button.hide()
	hud.touch.control_scale = ui_touch_scale
	hud.touch.left_handed = ui_left_handed
	hud.touch.haptic_strength = float(records.settings.get("steering_haptics",0.2))
	hud.touch.layout = ControlLayout.from_settings(records.settings)
	hud.touch.show_labels = bool(records.settings.get("control_labels", true))
	# Render the prepared world once with the countdown/input still frozen.
	game.call("_process", 0.0)
	loading.stage("Preparing start…")
	var prepared_finish: VehicleWeathering = game.get("car_weathering")
	var finish_warmed: bool = prepared_finish.begin_render_warmup()
	var prepared_personal_ghost: PersonalGhost = game.get("personal_ghost")
	var ghost_pose: Transform3D = Transform3D.IDENTITY
	var ghost_visible: bool = false
	if is_instance_valid(prepared_personal_ghost) and prepared_personal_ghost.mesh != null:
		ghost_pose = prepared_personal_ghost.transform
		ghost_visible = prepared_personal_ghost.visible
		prepared_personal_ghost.position = game.get("car").position+Vector3.UP*0.05
		prepared_personal_ghost.rotation = game.get("car").rotation
		prepared_personal_ghost.show()
	var bridge_preparation = preload("res://track/bridge_render_preparation.gd")
	var prepared_bridges: Array[Dictionary] = []
	if DisplayServer.get_name() != "headless": prepared_bridges = bridge_preparation.begin(game.get("track_ground"), game.get("camera"))
	var bridge_meshes: int = prepared_bridges.size()
	var prepared_hazards: Array[Dictionary] = []
	if DisplayServer.get_name() != "headless": prepared_hazards = bridge_preparation.begin_groups(game.get("track_ground"), game.get("camera"), ["race_hazard_rendering"])
	var hazard_meshes: int = prepared_hazards.size()
	var trail_preparation = preload("res://vehicle/trail_render_preparation.gd")
	var prepared_trail: MultiMeshInstance3D = trail_preparation.begin(game.get("trails"), game.get("camera"), track, game.get("sim").state)
	var trail_warmed: bool = prepared_trail != null
	var effect_preparation = preload("res://vehicle/effect_render_preparation.gd")
	var prepared_effects: Dictionary = effect_preparation.begin(game.get_node("World"),game.get("sand_dust"),game.get("camera"),game.get("impact_cracks"))
	var effect_counts: Dictionary = {"particles":prepared_effects.particles,"batches":prepared_effects.batches,"damage_meshes":prepared_effects.damage_meshes,"canvas":prepared_effects.canvas}
	var preparation_started: int = Time.get_ticks_usec()
	var finish_drawn: bool = await _present_race_loading()
	var night_preparation: Dictionary = {"drawn":false,"items":0,"contexts":0,"sets":0,"elapsed_ms":0.0,"truncated":0,"light_limit":false}
	if is_instance_valid(prepared_game) and game == prepared_game:
		night_preparation = await _prepare_night_lighting(loading_id, prepared_game)
	if is_instance_valid(prepared_personal_ghost) and prepared_personal_ghost.mesh != null:
		prepared_personal_ghost.transform = ghost_pose
		prepared_personal_ghost.visible = ghost_visible
	# Restore even if navigation or the loading deadline removed the game.
	bridge_preparation.end(prepared_bridges)
	bridge_preparation.end(prepared_hazards)
	if is_instance_valid(prepared_trail): trail_preparation.end(prepared_trail)
	effect_preparation.end(prepared_effects)
	var preparation_ms: float = (Time.get_ticks_usec() - preparation_started) / 1000.0
	# Always restore after the bounded draw wait, including cancellation/focus loss.
	prepared_finish.end_render_warmup()
	if finish_warmed and night_preparation.contexts > 0:
		# Clean and weathered car materials can have separate shader RIDs.
		var clean_night: Dictionary = await _prepare_night_lighting(loading_id, prepared_game)
		night_preparation.drawn = night_preparation.drawn and clean_night.drawn
		night_preparation.contexts += clean_night.contexts
		night_preparation.sets += clean_night.sets
		night_preparation.elapsed_ms += clean_night.elapsed_ms
		night_preparation.truncated = maxi(night_preparation.truncated, clean_night.truncated)
		night_preparation.light_limit = night_preparation.light_limit or clean_night.light_limit
	if (finish_warmed or night_preparation.contexts > 0) and _race_loading_matches(loading_id) and is_instance_valid(prepared_game) and game == prepared_game:
		game.call("_process", 0.0)
		# The exact clean/livery finish is visible before releasing the loading cover.
		await _present_race_loading()
	if not _race_loading_matches(loading_id):
		if is_instance_valid(prepared_game) and game == prepared_game and prepared_game.process_mode == Node.PROCESS_MODE_DISABLED:
			_leave_race()
		return
	if not is_instance_valid(prepared_game) or game != prepared_game:
		cloud_starting = false
		_close_race_loading(loading_id)
		return
	if _race_preparation_changed(loading_id,original_scope,navigation_generation,starting_screen,selected_vehicle,starting_selection):
		cloud_starting = false
		_close_race_loading(loading_id)
		_leave_race()
		return
	game.set("weathering_prepared", finish_drawn)
	game.set("bridge_prepared", finish_drawn and bridge_meshes > 0)
	game.set("bridge_preparation_meshes", bridge_meshes)
	game.set("hazards_prepared", finish_drawn and hazard_meshes > 0)
	game.set("hazard_preparation_meshes", hazard_meshes)
	game.set("trails_prepared", finish_drawn and trail_warmed)
	game.set("effects_prepared", finish_drawn and effect_counts.particles > 0)
	game.set("effect_preparation_counts",effect_counts)
	game.set("night_preparation",night_preparation)
	# This is the shared covered finish/bridge draw, not isolated bridge GPU time.
	game.set("bridge_preparation_ms", preparation_ms)
	game.preparation_current = Callable()
	game.process_mode = Node.PROCESS_MODE_INHERIT
	_telemetry_begin_attempt(track)
	if race_ad_breaks != null and not tutorial_lesson and not returning_to_editor and not bool(game.get("attempt_practice")): race_ad_breaks.prepare()
	cloud_starting = false
	_close_race_loading(loading_id)


func _race_installation_current(loading_id: int, scope: String, navigation: int, starting_screen: String, vehicle: String, selection: NativeTrack) -> bool:
	return not is_queued_for_deletion() and _race_loading_matches(loading_id) and scope == lifecycle.scope() and navigation == _navigation_generation and starting_screen == screen and vehicle == VehicleCatalog.selected and selection == selected_track


func _discard_preparing_game(prepared_game: Node) -> void:
	if not is_instance_valid(prepared_game) or game != prepared_game or prepared_game.process_mode != Node.PROCESS_MODE_DISABLED: return
	prepared_game.cancel_preparation()
	remove_child(prepared_game)
	prepared_game.queue_free()
	game = null
	cloud_ticket = {}
	if not _practice_editor_context.is_empty() and is_instance_valid(root_ui) and root_ui.get_instance_id() == _practice_editor_context.root:
		root_ui.process_mode = _practice_editor_context.mode
	_practice_editor_context = {}
	_race_menu_visible(true)

func _prepare_night_lighting(loading_id: int, prepared_game: Node) -> Dictionary:
	var summary: Dictionary = {"drawn":false,"items":0,"contexts":0,"sets":0,"elapsed_ms":0.0,"truncated":0,"light_limit":false}
	if DisplayServer.get_name() == "headless" or RenderingServer.get_current_rendering_method() != "gl_compatibility": return summary
	if not _race_loading_matches(loading_id) or not is_instance_valid(prepared_game) or game != prepared_game: return summary
	var track: NativeTrack = prepared_game.get("native_track")
	if track == null or track.metadata.get("theme", "pine") != "night_city": return summary
	var preparation = preload("res://track/night_render_preparation.gd")
	var started: int = Time.get_ticks_usec()
	var prepared: Dictionary = preparation.begin(prepared_game.get_node("World"), prepared_game.get("camera"))
	summary.items = prepared.items
	summary.truncated = prepared.truncated
	summary.light_limit = prepared.light_limit
	if prepared.nodes.size() == 2:
		for context: int in range(preparation.CONTEXTS):
			if not _race_loading_matches(loading_id) or not is_instance_valid(prepared_game) or game != prepared_game: break
			preparation.set_context(prepared, context)
			if not await _present_race_loading(): break
			summary.contexts += 1
		summary.drawn = summary.contexts == preparation.CONTEXTS
		summary.sets = 1
	preparation.end(prepared)
	summary.elapsed_ms = (Time.get_ticks_usec() - started) / 1000.0
	return summary

func _edit_here(position: Vector2) -> void:
	_leave_race()
	if is_instance_valid(canvas):
		canvas.pan += canvas.size*0.5-canvas.to_screen(position)
		canvas.refresh()

func _leave_race() -> void:
	if is_instance_valid(game) and game.get("free_drive_mode") == true:
		_leave_garage_free_drive()
		return
	if _draft_test_save_is_current(_draft_test_save_context):
		_show_draft_test_save_recovery()
		return
	_clear_draft_test_save_recovery()
	if race_ad_breaks != null and race_ad_breaks.blocking: return
	if is_instance_valid(game) and game.preparation_complete and not cloud_ticket.is_empty() and bool(game.get("track_session").finished):
		_results()
		if not cloud_ticket.is_empty(): return
	if is_instance_valid(game) and game.preparation_complete and not _telemetry_race_finished:
		var complete: bool = bool(game.get("track_session").finished)
		if client_quality != null: client_quality.finish_race("finished" if complete else "abandoned")
		_telemetry_observe("race_finished" if complete else "race_abandoned",_telemetry_track_properties(game.get("native_track"),"finished" if complete else "exit"))
		_telemetry_race_finished = complete
	if product_telemetry != null: product_telemetry.set_transport_allowed(true)
	if is_instance_valid(game):
		remove_child(game)
		game.queue_free()
	game = null
	if not _queued_track_link.is_empty():
		var queued_track: String = _queued_track_link
		_queued_track_link = ""
		_show_screen("tracks")
		_receive_track_link.call_deferred(queued_track)
		return
	if not challenge_queued_invitation.is_empty():
		var queued: String = challenge_queued_invitation
		challenge_queued_invitation = ""
		challenge_racing = false
		rivalry_racing = false
		challenge_result_view = false
		_receive_challenge(queued)
		return
	if challenge_racing or challenge_practice:
		challenge_racing = false
		challenge_practice = false
		challenge_result_view = false
		_show_screen("challenges")
	elif rivalry_racing:
		rivalry_racing = false
		rivalry_section = "overview"
		_show_screen("rivalry")
	elif not _resume_practice_editor(): _show_screen("drafts" if test_return_to_drafts else "create" if returning_to_editor else "daily" if race_area_mode == "daily" else "tracks")
	_practice_editor_context = {}
	test_return_to_drafts = false
	if not pending_menu_notice.is_empty():
		_notice(pending_menu_notice)
		pending_menu_notice = ""

func _resume_practice_editor() -> bool:
	if not returning_to_editor or test_return_to_drafts or _practice_editor_context.is_empty(): return false
	if not is_instance_valid(root_ui) or not is_instance_valid(canvas) or not is_instance_valid(editor_world): return false
	if root_ui.get_instance_id() != _practice_editor_context.root or _navigation_generation != _practice_editor_context.navigation or screen != "create": return false
	if library != test_library_snapshot or (lifecycle != null and lifecycle.scope() != test_scope_snapshot) or VehicleCatalog.selected != test_vehicle_snapshot: return false
	if document != test_document_snapshot or canvas.document != document: return false
	_close_race_loading()
	root_ui.process_mode = _practice_editor_context.mode
	_race_menu_visible(true)
	NativeTrackVisual.reserve_editor_sections()
	GameSoundtrack.instance().show_menu()
	_update_editor_issues()
	_lifecycle_changed()
	return true

func _results() -> void:
	if not is_instance_valid(game) or not game.preparation_complete: return
	var result_records: LocalRecords = game.get("preference_records")
	var session: TrackSession = game.get("track_session")
	var track: NativeTrack = game.get("native_track")
	var total: float = session.race_time_seconds()
	var clean: bool = not bool(game.get("attempt_practice")) and not returning_to_editor
	if _result_game_id == game.get_instance_id(): return
	_result_game_id = game.get_instance_id()
	if clean and session.finished and race_ad_breaks != null: race_ad_breaks.record_finish()
	if client_quality != null: client_quality.finish_race("finished")
	_telemetry_race_finished = true
	_telemetry_observe("race_finished",_telemetry_track_properties(track,"finished"))
	if product_telemetry != null: product_telemetry.set_transport_allowed(true)
	var local_result_notice: String = ""
	if session.finished and not cloud_ticket.is_empty() and (not clean or not game.attempt_evidence.eligible(game.race_proof)):
		# Incomplete/practice evidence cannot be retried into a valid upload. It
		# must not strand Challenge Continue behind an impossible save admission.
		local_result_notice = "Recording limit reached. This race cannot enter online standings." if not game.attempt_evidence.eligible(game.race_proof) else "This practice run cannot enter online standings."
		cloud_ticket = {}
		challenge_seed = {}
		if challenge_racing:
			challenges.result_ticket = ""; challenges.result_state = ""; challenges.outcome = {}; challenges.error = local_result_notice
		if rivalry_racing:
			rivalry.result_ticket = ""; rivalry.result_state = ""; rivalry.error = local_result_notice
	var online_queued: bool = clean and session.finished and not cloud_ticket.is_empty() and game.attempt_evidence.eligible(game.race_proof)
	var challenge_source_ticket: String = str(cloud_ticket.get("ticket_id",""))
	var finished_challenge: Dictionary = _challenge_finished_context(track,total,session.completed_laps,challenge_source_ticket,str(game.get("vehicle_id"))) if online_queued else {}
	if challenge_racing and online_queued:
		challenges.begin_result(challenge_source_ticket)
		challenges.poll_result()
	if not challenge_seed.is_empty():
		challenge_seed.ticket_id = challenge_source_ticket
		challenge_seed.finished = finished_challenge.duplicate(true)
	if rivalry_racing:
		rivalry_result_pending = online_queued
		# Verification runs behind the normal PB/lap summary until Continue.
		rivalry_section = "race_results"
		if online_queued: rivalry.model.preview_result(rivalry_track,session.elapsed_ticks,total)
		else: rivalry.model.last_result = {"ms":roundi(total*1000.0)}
		if online_queued: rivalry.poll_result()
	var previous: float = result_records.best_for(track, game.get("handling"))
	var first_reward_track: bool = track.identity not in result_records.settings.get("raced_tracks",[])
	if rivalry_racing:
		rivalry_race_details = {"previous":previous,"clean":clean and session.finished,
			"laps":session.completed_laps,"distance_m":track.route_length*session.completed_laps,
			"theme":str(track.metadata.get("theme","pine")),"route":track.route.duplicate()}
	GameSoundtrack.instance().results_feedback(previous - total if previous > 0.0 else 0.0, clean and session.finished)
	var previous_lap: float = float(result_records.records.get(result_records.key_for(track,game.get("handling")),{}).get("flying_ms",0))/1000.0
	var result_data: RaceResultData = RaceResultData.build(track,session.lap_times,game.get("lap_telemetry"),bool(game.get("attempt_practice")))
	var flying: float = 0.0
	for i: int in range(1,session.lap_times.size()):
		if flying == 0 or session.lap_times[i] < flying: flying = session.lap_times[i]
	var incident_free: bool = game.sim.state.collision_count == 0 and result_data.laps.size() == RaceRules.LAPS
	for lap: Dictionary in result_data.laps:
		if lap.get("samples",[]).is_empty() or not lap.get("events",[]).is_empty() or lap.get("events_truncated",false): incident_free = false
	var reward_facts: Dictionary = {"complete":clean and session.finished,"total":total,"previous":previous,"previous_lap":previous_lap,"flying":flying,"incident_free":incident_free,"first_track":first_reward_track,"track_id":track.identity}
	var saved: bool = not clean
	if clean:
		AchievementProgress.race(result_records,track,str(game.get("vehicle_id")),session.lap_times,reward_facts)
		saved = result_records.record(track, game.get("handling"), total, session.lap_times) == OK
	if clean and saved:
		var ghost_error: Error = game.save_personal_ghost()
		if ghost_error != OK: pending_menu_notice = "Best time saved. Could not save its local ghost."
	(game.get("hud") as PlaygroundHUD).hide()
	# The summary replaces the menu children. Retire their references before
	# Continue or a background result update can revisit the previous page.
	if screen == "rivalry" and is_instance_valid(content): _remember_rivalry_standings(content)
	_stop_menu_page_motion()
	if is_instance_valid(_retained_garage) and root_ui.is_ancestor_of(_retained_garage): _park_garage()
	_park_rivalry_page(root_ui)
	menu_neighbors.clear()
	content = null
	menu_body = null
	menu_body_slot = null
	menu_body_backgrounds.clear()
	_race_menu_visible(true)
	for child: Node in root_ui.get_children():
		root_ui.remove_child(child)
		child.queue_free()
	var background := ColorRect.new()
	background.color = Color.WHITE
	var blur := ShaderMaterial.new()
	blur.shader = preload("res://ui/results_backdrop.gdshader")
	background.material = blur
	MenuStyle.fill(background)
	root_ui.add_child(background)
	var center := MarginContainer.new()
	MenuStyle.fill(center)
	for side: String in ["left","right"]: center.add_theme_constant_override("margin_"+side,32)
	for side: String in ["top","bottom"]: center.add_theme_constant_override("margin_"+side,16)
	root_ui.add_child(center)
	_apply_editor_safe_area(center)
	center.resized.connect(_apply_editor_safe_area.bind(center))
	var panel := RaceResults.new()
	panel.circuit = track_title(track)
	panel.vehicle_name = VehicleCatalog.title(game.vehicle_id)
	panel.total = total
	panel.previous = previous
	panel.best = result_records.best_for(track,game.get("handling"))
	panel.laps = session.lap_times.duplicate()
	panel.clean = clean
	panel.saved = saved
	panel.verification_notice = local_result_notice
	panel.editor = returning_to_editor
	panel.challenge_active = challenge_racing or challenge_practice or not challenge_seed.is_empty()
	panel.challenge_available = online_queued and not returning_to_editor and not panel.challenge_active
	panel.challenge_requested.connect(func() -> void:
		_create_challenge_dialog(str(finished_challenge.entry.version_id),str(finished_challenge.vehicle_id),challenge_source_ticket,604800,finished_challenge,0,{},true))
	panel.result = result_data
	panel.set_meta("reward_facts",reward_facts)
	panel.set_meta("reward_ticket",challenge_source_ticket)
	panel.set_meta("coin_receipt",{"status":"pending" if online_queued else "unavailable","amount":0,"rows":[]})
	panel.continue_requested.connect(_results_continue.bind(panel,center))
	panel.retry_requested.connect(_retry_race)
	panel.return_requested.connect(_leave_race)
	if bool(game.get_meta("tutorial_lesson",false)):
		var lesson_scroll := ScrollContainer.new()
		lesson_scroll.name = "TutorialResultScroll"
		lesson_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
		center.add_child(lesson_scroll)
		lesson_scroll.add_child(panel)
	else: center.add_child(panel)
	if track.metadata.has("cloud_version"):
		var online_status := Label.new()
		online_status.name = "CloudRunStatus"
		online_status.text = "Could not connect to the server. We'll retry automatically."
		if not game.attempt_evidence.eligible(game.race_proof): online_status.text = "Saved locally. This attempt exceeds the online recording limit." if clean and saved else "Online recording limit reached. Restart for a verified result."
		online_status.visible = (online_queued and cloud.run_connection_failed) or not game.attempt_evidence.eligible(game.race_proof)
		panel.add_child(online_status)
		if online_queued:
			var update_status: Callable = func() -> void:
				if is_instance_valid(online_status): online_status.visible = cloud.run_connection_failed
			cloud.changed.connect(update_status)
			online_status.tree_exiting.connect(func() -> void:
				if cloud.changed.is_connected(update_status): cloud.changed.disconnect(update_status))
	root_ui.modulate.a = 0.0
	create_tween().tween_property(root_ui, "modulate:a", 1.0, 0.4).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	if online_queued: _save_result_upload(game,cloud_ticket,game.get("online_frames"),"",game.get("online_rewinds"))
	if clean and session.finished: _try_race_ad.call_deferred(_result_game_id,panel)

func _ad_play_active() -> bool:
	if not startup_complete or not _publishing_slots_foreground or cloud_starting or screen in ["create","drafts"] or returning_to_editor: return false
	return not is_instance_valid(game) or (not bool(game.get("paused")) and not bool(game.get("attempt_practice")))

func _try_race_ad(finished_game: int, panel: Control) -> void:
	if is_instance_valid(game) and bool(game.get_meta("tutorial_lesson",false)): return
	if race_ad_breaks == null: return
	if game_configuration != null:
		game_configuration.set_transport_allowed(true)
		game_configuration.at_result(false)
		_remote_config_changed()
	var at_break: Callable = func() -> bool:
		return _publishing_slots_foreground and is_instance_valid(game) and game.preparation_complete and game.get_instance_id() == finished_game and bool(game.get("track_session").finished) and is_instance_valid(panel) and panel.is_visible_in_tree()
	if game_configuration != null and game_configuration.negotiated and race_ad_breaks.enabled and is_instance_valid(race_ad_breaks.adapter) and race_ad_breaks.adapter.supported():
		await game_configuration.renew_result_permission()
	if not at_break.call(): return
	if game_configuration != null and game_configuration.needs_ad_exposure() and race_ad_breaks.enabled and is_instance_valid(race_ad_breaks.adapter) and race_ad_breaks.adapter.supported():
		var eligible: bool = await race_ad_breaks._eligible(preload("res://backend/store_access_cache.gd").identity(online.client))
		if eligible and at_break.call() and game_configuration.needs_ad_exposure(): game_configuration.expose("ads","race_result")
	if not at_break.call(): return
	var was_due: bool = race_ad_breaks.due() and race_ad_breaks.can_present()
	var outcome: Dictionary = await race_ad_breaks.show_if_due(at_break)
	if game_configuration != null and at_break.call():
		game_configuration.record_ad_decision("shown" if outcome.get("shown",false) else "unavailable" if was_due else "suppressed")

func _remote_config_changed() -> void:
	if game_configuration != null and game_configuration.negotiated and race_ad_breaks != null:
		race_ad_breaks.set_policy(game_configuration.settings)

func _remote_menu_notice() -> void:
	if game_configuration == null or not is_instance_valid(content): return
	var previous: Node = content.get_node_or_null("RemoteGameNotice")
	if previous != null:
		content.remove_child(previous)
		previous.queue_free()
	var message: String = str(game_configuration.settings.get("notice.message",""))
	var expiry: int = int(game_configuration.settings.get("notice.expires_at",0))
	if expiry > 0 and (online.client.server_now() <= 0 or online.client.server_now() >= expiry): message = ""
	if not message.is_empty() and screen not in ["create","restoring"]:
		var notice: Label = MenuStyle.label(message,16)
		notice.name = "RemoteGameNotice"
		notice.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		content.add_child(notice)
		content.move_child(notice,0)
	if screen not in ["create","restoring"]: game_configuration.menu_applied(screen)

func _ad_blocking_changed(value: bool) -> void:
	if is_instance_valid(_ad_input_blocker):
		_ad_input_blocker.queue_free()
		_ad_input_blocker = null
	if not value and _ad_previous_focus != null:
		var previous: Control = _ad_previous_focus.get_ref() as Control
		if is_instance_valid(previous) and previous.is_visible_in_tree(): previous.grab_focus()
		_ad_previous_focus = null
	if value and is_instance_valid(menu_layer):
		var previous: Control = get_viewport().gui_get_focus_owner()
		_ad_previous_focus = weakref(previous) if previous != null else null
		_ad_input_blocker = Control.new()
		_ad_input_blocker.name = "AdInputBlocker"
		_ad_input_blocker.mouse_filter = Control.MOUSE_FILTER_STOP
		_ad_input_blocker.focus_mode = Control.FOCUS_ALL
		menu_layer.add_child(_ad_input_blocker)
		MenuStyle.fill(_ad_input_blocker)
		_ad_input_blocker.grab_focus()

func _save_result_upload(completed_game: Node, ticket_data: Dictionary, frames: Variant, publish_version: String, rewinds: Array) -> void:
	ticket_data = ticket_data.duplicate()
	if is_instance_valid(completed_game) and not completed_game.attempt_evidence.eligible(completed_game.race_proof): return
	if is_instance_valid(completed_game) and completed_game.get("race_proof") != null and bool(cloud.client.get("_capabilities").get("lightweight_race_proofs",false)):
		var proof: Dictionary = completed_game.race_proof.recording(completed_game.track_session)
		if not proof.is_empty():
			var incidents: Dictionary = preload("res://race/race_incidents.gd").build(completed_game.track_session,completed_game.lap_telemetry,completed_game.sim.state)
			if not incidents.is_empty(): proof.incidents = incidents
			ticket_data["_race_proof"] = proof
			ticket_data["_race_ghost_source"] = completed_game.ghost_run.snapshot_for_save()
			ticket_data["_claimed_lap_ticks"] = completed_game.track_session.lap_times.map(func(seconds: float) -> int: return roundi(seconds*120.0))
	if not cloud.enqueue_completed(ticket_data,frames,publish_version,rewinds):
		_notice("This recorded result could not enter the save queue. Keep this race open and free storage.")
		return
	# Ownership transfers immediately; navigation never cancels its durable save.
	if is_instance_valid(completed_game) and game == completed_game:
		cloud_ticket = {}

func _results_continue(results: RaceResults, parent: Control) -> void:
	if race_ad_breaks != null and race_ad_breaks.blocking: return
	if challenge_practice:
		challenge_practice = false
		_clear_challenge_game()
		_show_screen("challenges")
		return
	if challenge_racing:
		if not cloud_ticket.is_empty():
			_save_result_upload(game,cloud_ticket,game.get("online_frames"),"",game.get("online_rewinds"))
			if not cloud_ticket.is_empty(): return
		challenge_result_view = true
		# Feedback can select another track or invitation. It owns no retryable Game.
		_clear_challenge_game()
		_show_screen("challenges")
		challenges.poll_result()
		return
	if not challenge_seed.is_empty():
		var seed: Dictionary = challenge_seed.duplicate(true)
		challenge_seed = {}
		if is_instance_valid(game):
			remove_child(game)
			game.queue_free()
			game = null
		_open_challenges()
		_create_challenge_dialog(str(seed.version_id),str(seed.vehicle_id),str(seed.get("ticket_id","")),int(seed.get("duration_seconds",604800)),seed.get("finished",{}),int(seed.get("attempt_limit",0)),seed.get("configuration",{}))
		return
	if rivalry_racing:
		rivalry_section = "result"
		_show_screen("rivalry")
		if rivalry_result_pending: rivalry.poll_result()
		return
	results.hide()
	var page := RaceComplete.new()
	page.results = results
	page.rating_records = records
	page.rating_track_id = (game.get("native_track") as NativeTrack).identity
	page.cloud_client = online.client
	_configure_result_comparisons()
	page.comparison_cache = discovery_provider.comparisons
	page.cloud_sync = cloud
	var finish_vote: Variant = game.get("cloud_rating")
	if is_instance_valid(finish_vote): page.finish_vote = finish_vote
	page.vehicle_id = str(game.get("vehicle_id"))
	page.cloud_version = str((game.get("native_track") as NativeTrack).metadata.get("cloud_version",""))
	page.facts = results.get_meta("reward_facts",{})
	page.economy = cosmetic_economy
	page.reward_ticket = str(results.get_meta("reward_ticket",""))
	page.coin_receipt = results.get_meta("coin_receipt",{})
	_ensure_track_catalog()
	if track_catalog.indexed_revision != library.revision:
		track_catalog.entries.clear()
		if cloud != null:
			cloud.add_to_catalog(track_catalog,discovery_provider)
		else:
			for id: String in BUILTIN_IDS: track_catalog.add_builtin(id)
			for id: String in track_catalog.local_ids(): track_catalog.add_local(id)
		track_catalog.indexed_revision = library.revision
	page.recommendations = RaceRecommendations.suggest(track_catalog,game.get("native_track"))
	page.back_requested.connect(func() -> void:
		parent.remove_child(page)
		page.queue_free()
		results.show())
	page.home_requested.connect(func() -> void:
		if is_instance_valid(game):
			remove_child(game)
			game.queue_free()
		game = null
		returning_to_editor = false
		_show_screen("tracks"))
	page.tracks_requested.connect(_leave_race)
	page.race_requested.connect(_next_result_race)
	parent.add_child(page)

func _next_result_race(recommendation: Dictionary) -> void:
	if race_ad_breaks != null and race_ad_breaks.blocking: return
	var next_track: NativeTrack = track_catalog.cached_track(recommendation.entry)
	if next_track == null:
		next_track = cloud.presentation_track(recommendation.entry) if recommendation.entry.source == "cloud" else track_catalog.resolve(recommendation.entry)
	if next_track == null:
		_notice("This track is no longer available. Choose another track.")
		return
	if is_instance_valid(game):
		remove_child(game)
		game.queue_free()
	game = null
	selected_track = next_track
	_start_race(next_track,false)

func _result_capacity_available() -> bool:
	cloud._ensure_result_saves()
	if cloud.result_saves.can_start_attempt(): return true
	_notice("Previous results are waiting for storage. Free space or race offline.")
	return false

func _retry_race(offline_only: bool = false) -> void:
	if race_ad_breaks != null and race_ad_breaks.blocking: return
	if cloud_starting or not is_instance_valid(game) or not game.preparation_complete: return
	if product_telemetry != null: product_telemetry.set_transport_allowed(false)
	if not cloud_ticket.is_empty() and bool(game.get("track_session").finished):
		_results()
		if not cloud_ticket.is_empty(): return
	var active_game: Node = game
	var account_id: String = str(online.client.player.get("id",""))
	var origin: String = str(online.client.base_url())
	var track: NativeTrack = game.get("native_track")
	var replacement: Dictionary = {}
	var retry_offline: bool = (offline_only or bool(game.get_meta("race_offline_only",false))) and not (rivalry_racing or challenge_racing)
	var challenge_attempt: Dictionary = game.get_meta("challenge_attempt",{})
	if challenge_racing and (not online.client.signed_in() or str(challenge_attempt.get("scope","")) != challenges.scope() or str(challenge_attempt.get("code","")) != str(challenges.selected.get("code",""))):
		_notice("Open the challenge and select a track to race again.")
		return
	if not retry_offline and track.metadata.has("cloud_version") and online.client.signed_in():
		if not _result_capacity_available(): return
		cloud_starting = true
		var issued: Dictionary = await challenges.ticket(int(challenge_attempt.get("stage",0))) if challenge_racing else await rivalry.ticket(rivalry_track) if rivalry_racing else {}
		if game != active_game or not is_instance_valid(active_game) or str(online.client.player.get("id","")) != account_id or str(online.client.base_url()) != origin:
			cloud_starting = false
			return
		replacement = await cloud.ticket(track,false,str(active_game.get("vehicle_id")),active_game.get("handling"),issued) if not (rivalry_racing or challenge_racing) or not issued.is_empty() else {}
		if game != active_game or not is_instance_valid(active_game) or str(online.client.player.get("id","")) != account_id or str(online.client.base_url()) != origin:
			cloud_starting = false
			return
		if replacement.is_empty():
			cloud_starting = false
			if rivalry_racing or challenge_racing:
				var failure: String = challenges.error if challenge_racing and issued.is_empty() else cloud.last_error
				_notice("Could not start verified retry: "+(failure if not failure.is_empty() else "Check your connection and try again."))
			else:
				var offline_dialog := ConfirmationDialog.new()
				offline_dialog.title = "Online race unavailable"
				offline_dialog.dialog_text = cloud.last_error+"\nRestart offline with a local time? This attempt will not enter the online leaderboard."
				offline_dialog.ok_button_text = "Race offline"
				_own_dialog(offline_dialog)
				offline_dialog.confirmed.connect(func() -> void:
					if game == active_game and is_instance_valid(active_game) and str(online.client.player.get("id","")) == account_id and str(online.client.base_url()) == origin:
						_retry_race(true))
				offline_dialog.popup_centered()
			return
	if challenge_racing:
		# Keep the start lock through the optional download; repeated presses
		# during this await must not spend another track's try.
		challenge_recording = await challenges.ghost(int(challenge_attempt.get("stage",0)))
		if game != active_game or not is_instance_valid(active_game) or str(online.client.player.get("id","")) != account_id or str(online.client.base_url()) != origin or str(challenge_attempt.get("code","")) != str(challenges.selected.get("code","")):
			cloud_starting = false
			return
		challenge_result_view = false
		challenges.result_ticket = ""
		challenges.result_state = ""
	if rivalry_racing:
		cloud_starting = true
		var refreshed_recording: Dictionary = await _rivalry_ghost(rivalry_track,rivalry_ghost_choice,true)
		cloud_starting = false
		if game != active_game or not is_instance_valid(active_game) or str(online.client.player.get("id","")) != account_id or str(online.client.base_url()) != origin: return
		rivalry_recording = refreshed_recording
	cloud_starting = false
	cloud_ticket = replacement
	if rivalry_racing:
		rivalry.result_ticket = str(replacement.get("ticket_id",""))
		rivalry.result_state = ""
		rivalry_result_pending = false
	if not cloud_ticket.is_empty():
		cloud_ticket._owner_id = account_id
		cloud_ticket._origin = origin
	_race_menu_visible(false)
	(game.get("hud") as PlaygroundHUD).show()
	game.set("resume_ticket_id",str(cloud_ticket.get("ticket_id","")))
	game.set("preference_records",records) # A confirmed restart begins a new attempt.
	game.set("rating_records",null if bool(game.get_meta("tutorial_lesson",false)) or track.metadata.has("cloud_version") else records)
	_prepare_race_rating(track)
	game.set_meta("race_offline_only",retry_offline)
	# Retry reuses the Game node but starts a new scored attempt. Keep duplicate
	# finish signals idempotent within an attempt, without suppressing its retry.
	_result_game_id = 0
	if client_quality != null: client_quality.finish_race("restarted")
	if not _telemetry_race_finished: _telemetry_observe("race_abandoned",_telemetry_track_properties(track,"restart"))
	_telemetry_observe("race_retried",_telemetry_track_properties(track,"restart"))
	_telemetry_begin_attempt(track)
	game.call("restart")
	if rivalry_racing:
		game.ghost_mode = "race" if not rivalry_recording.is_empty() else "off"
		game.ghost_bests = {"race":rivalry_recording} if not rivalry_recording.is_empty() else {}
	elif challenge_racing:
		game.ghost_mode = "race" if not challenge_recording.is_empty() else "off"
		game.ghost_bests = {"race":challenge_recording} if not challenge_recording.is_empty() else {}
	game.call("_prepare_personal_ghost")

func _prepare_race_rating(track: NativeTrack) -> void:
	var previous_vote: Variant = game.get("cloud_rating")
	if is_instance_valid(previous_vote): previous_vote.abandon()
	game.set("cloud_rating",null)
	if cloud_ticket.is_empty() or bool(game.get("editor_test")) or not track.metadata.has("cloud_version"): return
	var vote := preload("res://backend/finish_rating.gd").new()
	vote.client = online.client
	vote.sync = cloud
	if rivalry_racing: vote.rivalry_sync = rivalry
	vote.version = str(track.metadata.cloud_version)
	vote.creator_id = str(track.metadata.get("cloud_creator_id",""))
	cloud.add_child(vote)
	game.set("cloud_rating",vote)

static func track_title(track: NativeTrack) -> String:
	return str(track.metadata.get("title", track.metadata.get("name", track.identity.replace("_"," ").to_upper())))

func _capture() -> void:
	await get_tree().process_frame
	for child: Node in content.get_children():
		if child is TrackBrowser:
			while child.loading: await get_tree().process_frame
	if screen == "tracks":
		var browser: TrackBrowser = root_ui.find_child("TrackBrowser",true,false)
		while browser != null and browser.loading: await get_tree().process_frame
		for preview: Node in root_ui.find_children("*","TrackShowroom",true,false):
			while not preview.ready_for_display: await get_tree().process_frame
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	var error: Error = get_viewport().get_texture().get_image().save_png(capture_path)
	if error == OK: print("CAPTURE_SAVED: " + capture_path)
	get_tree().quit(0 if error == OK else 1)


func _build_paint_tools() -> void:
	editor_inspector.add_child(EditorStyle.button("Keep road" if canvas.protect_road else "Paint all",func() -> void:
		canvas.protect_road = not canvas.protect_road
		_build_editor_tools()))
	if canvas.paint_mode != "free":
		editor_inspector.add_child(MenuStyle.button("Remove last point",func() -> void:
			if not canvas.paint_points.is_empty(): canvas.paint_points.pop_back()
			canvas.queue_redraw()))
		editor_inspector.add_child(MenuStyle.button("Cancel surface",func() -> void:
			canvas.cancel_gesture()
			canvas.queue_redraw()))
	var materials := OptionButton.new()
	materials.custom_minimum_size.y = 54
	for label: String in ["Grass / erase","Sand","Water","Barrier","Kerb","Rough ground","Low obstacles"]: materials.add_item(label)
	materials.selected = canvas.brush_surface-1
	materials.item_selected.connect(func(index: int) -> void:
		canvas.brush_surface = index+1
		canvas.mode = "paint"
		_build_editor_tools())
	editor_inspector.add_child(materials)
	var actions := HBoxContainer.new()
	editor_inspector.add_child(actions)
	for entry: Array in [["paint","Paint"],["pan","Pan"]]:
		var value: String = entry[0]
		actions.add_child(MenuStyle.button(entry[1],func() -> void:
			canvas.mode = value
			_build_editor_tools(),canvas.mode == value))
	var shapes := OptionButton.new()
	shapes.custom_minimum_size.y = 54
	shapes.add_item("Round brush")
	shapes.add_item("Square brush")
	shapes.selected = 1 if canvas.brush_shape == "square" else 0
	shapes.item_selected.connect(func(index: int) -> void: canvas.brush_shape = "square" if index else "round")
	editor_inspector.add_child(shapes)
	var help := MenuStyle.label("Tap to add points; drag dots to reshape. Confirm to place. Free painting commits on release.",16,true)
	if document.base_track != "": help.text += " Remix paints ground only."
	help.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	editor_inspector.add_child(MenuStyle.button("Clear map",func() -> void:
		_remember()
		document.layout = {}
		document.paint = []
		document.pieces = []
		document.objects = []
		canvas.selected_object = -1
		canvas.selected = -1
		document.base_track = ""
		document.route_override = true
		_save_draft(true)
		_build_editor_tools()))
	editor_inspector.add_child(help)

func _editor_help() -> void:
	_notice("Changes autosave to a separate WIP. Load reopens the latest saved draft or autosave. Save (Ctrl+S) updates the saved original.\n\nDrag inside a road section to move it. Drag an end dot to resize and turn it; the other end stays fixed.\n\nPC: wheel zooms at the pointer. Middle/right drag or Space + left drag pans. F fits the map. Ctrl+Z / Ctrl+Shift+Z undo/redo. Enter confirms; Esc cancels. Delete removes the selection. 1–4 switch tools. Q/E rotate. Tab cycles overlapping roads.\n\nPhone: two fingers pan/zoom. Layer selects the other road at an overpass. Bridge spans include ramps at both ends; paint edits the ground underneath.")

func _input(event: InputEvent) -> void:
	# Tab is a GUI navigation key and never reaches unhandled_key_input.
	if event is InputEventKey and event.pressed and (event.physical_keycode == KEY_TAB or event.keycode == KEY_TAB):
		if is_instance_valid(editor_map_panel) and editor_map_panel.visible: return
		_unhandled_key_input(event)

func _unhandled_key_input(event: InputEvent) -> void:
	if is_instance_valid(object_population_panel): return
	if screen != "create" or is_instance_valid(game) or not event is InputEventKey or not event.pressed: return
	var focus: Control = get_viewport().gui_get_focus_owner()
	if focus is LineEdit or focus is TextEdit: return
	var key: Key = event.physical_keycode if event.physical_keycode != 0 else event.keycode
	var handled: bool = true
	if event.ctrl_pressed or event.meta_pressed:
		match key:
			KEY_Z:
				if event.shift_pressed: _redo()
				elif not canvas.ghost.is_empty(): _delete_piece()
				else: _undo()
			KEY_Y: _redo()
			KEY_S: _save_track_explicit()
			_: handled = false
	else:
		match key:
			KEY_F: canvas.fit()
			KEY_EQUAL, KEY_PLUS, KEY_KP_ADD: canvas.zoom_by(1.15)
			KEY_MINUS, KEY_KP_SUBTRACT: canvas.zoom_by(1.0/1.15)
			KEY_ENTER, KEY_KP_ENTER:
				if canvas.mode == "road": canvas.confirm_piece()
				elif canvas.mode in ["paint","pan"]: canvas.confirm_paint()
			KEY_ESCAPE:
				canvas.cancel_gesture()
				canvas.ghost.clear()
				canvas.selected_piece = -1
				editor_geometry = ""
				editor_tools_panel.hide()
				editor_map_panel.hide()
				_build_editor_tools()
			KEY_DELETE, KEY_BACKSPACE:
				if canvas.mode == "paint" and not canvas.paint_points.is_empty():
					canvas.paint_points.pop_back()
					canvas.paint_handle = -1
					canvas.queue_redraw()
				elif canvas.mode == "road": _delete_piece()
				else: _delete_selection()
			KEY_1: _editor_category("road")
			KEY_2: _editor_category("paint")
			KEY_3: _editor_category("objects")
			KEY_4: canvas.choose_start_line()
			KEY_Q: _change_piece("heading",-15.0)
			KEY_E: _change_piece("heading",15.0)
			KEY_TAB: canvas.cycle_piece()
			_: handled = false
	if handled: get_viewport().set_input_as_handled()

func _save_track_explicit() -> void:
	if str(document.get("name", "")).strip_edges().is_empty() or str(document.get("name", "")) == "My circuit":
		_confirm_editor_departure(Callable(), false)
		return
	_save_track_now()

func _save_track_now() -> bool:
	_flush_editor_writes()
	if not _commit_editor_previews(): return false
	_stamp_creator()
	var id: String = str(document.id)
	if editor_save_error == OK and not editor_retry_original and _editor_copy_is_current(editor_saved_snapshot,editor_saved_store,id+".json",editor_saved_disk_hash) and _editor_copy_is_current(editor_wip_snapshot,editor_wip_store,"wip/"+id+".json",editor_wip_disk_hash) and not library.is_published(id):
		library.last_error = ""
		_update_editor_save_state()
		return true
	if _save_draft() != OK:
		_notice("Could not save: "+library.last_error)
		return false
	var original_current: bool = not editor_retry_original and _editor_copy_is_current(editor_saved_snapshot,editor_saved_store,id+".json",editor_saved_disk_hash) and not library.is_published(id)
	if not original_current and library.save_document(document) != OK:
		editor_retry_original = true
		editor_save_error = ERR_FILE_CANT_WRITE
		editor_save_message = "Could not save: "+library.last_error
		_update_editor_save_state()
		_notice("Could not save: "+library.last_error)
		return false
	elif not TrackDocument.validate(document).is_empty():
		_notice("Draft saved. Open Load track to edit it. Before testing: "+TrackDocument.validate(document)[0])
	else:
		# Menus retain a compiled selection independently of the saved-track index.
		# Replace it after committing edits so Race cannot launch its old geometry.
		if selected_track != null and selected_track.identity == "creator_"+str(document.id) and selected_track.metadata.get("creator_document",{}) != document:
			var saved_track: NativeTrack = canvas.native_preview if canvas.native_preview != null and canvas.native_preview.metadata.get("creator_document",{}) == document else TrackCompiler.compile(document)
			if saved_track != null: selected_track = saved_track
		_notice("Saved on this device. Open Load track to edit or test it.")
		if not original_current:
			editor_pending_road_bake = document.duplicate(true)
			if canvas.native_preview != null and canvas.native_preview.metadata.get("creator_document",{}) == document:
				NativeTrackVisual.request_saved_road_bake.call_deferred(canvas.native_preview,get_tree())
				editor_pending_road_bake.clear()
	var saved_title: Label = root_ui.find_child("TrackName",true,false) as Label
	if saved_title != null: saved_title.text = str(document.name)
	editor_saved_snapshot = document.duplicate(true)
	editor_saved_store = library
	if not original_current: editor_saved_disk_hash = FileAccess.get_sha256(library.directory.path_join(id+".json"))
	editor_retry_original = false
	editor_save_error = OK
	editor_save_message = ""
	_update_editor_save_state()
	return true

func _editor_has_unsaved_changes() -> bool:
	if document.is_empty(): return false
	return editor_save_error != OK or _has_pending_editor_work() or editor_saved_snapshot.is_empty() or TrackLibrary.draft_fingerprint(document) != TrackLibrary.draft_fingerprint(editor_saved_snapshot)

func _request_editor_exit() -> void:
	# Apply final write errors before deciding whether departure needs a retry.
	_flush_editor_writes()
	if not _editor_has_unsaved_changes():
		_return_from_editor()
		return
	_confirm_editor_departure(_return_from_editor)

func _return_from_editor() -> void:
	# Closing an editor reached through its own Load action must not create a Back loop.
	if editor_return_screen == "drafts": draft_return_screen = "biome"
	_show_screen(editor_return_screen)

func _confirm_editor_departure(after: Callable, allow_discard: bool = true) -> void:
	if root_ui.find_child("SaveChangesDialog", true, false) != null: return
	var dialog := ConfirmationDialog.new()
	dialog.name = "SaveChangesDialog"
	dialog.title = "Save this draft?"
	dialog.dialog_text = ""
	dialog.ok_button_text = "Save"
	dialog.cancel_button_text = "Cancel"
	var discard := dialog.add_button("Discard", true, "discard")
	discard.visible = allow_discard
	var field := LineEdit.new()
	field.name = "SaveDraftName"
	field.placeholder_text = "Track name"
	field.text = "" if str(document.get("name", "")) == "My circuit" else str(document.get("name", ""))
	field.max_length = 40
	field.custom_minimum_size = Vector2(440, 52)
	field.virtual_keyboard_enabled = true
	dialog.add_child(field)
	var update_save := func(value: String) -> void: dialog.get_ok_button().disabled = value.strip_edges().is_empty()
	field.text_changed.connect(update_save)
	update_save.call(field.text)
	dialog.confirmed.connect(func() -> void:
		dialog.hide() # Saving can open its own success/failure notice.
		document.name = field.text.strip_edges()
		if not _save_track_now():
			dialog.queue_free()
			return
		dialog.queue_free()
		if after.is_valid(): after.call())
	dialog.custom_action.connect(func(action: StringName) -> void:
		if action != &"discard": return
		var id: String = str(document.get("id", ""))
		if TrackDocument.valid_id(id) and library.delete_wip(id) != OK:
			_notice("Could not discard the recovery draft: " + library.last_error)
			return
		dialog.queue_free()
		_discard_editor_previews()
		if after.is_valid(): after.call())
	root_ui.add_child(dialog)
	dialog.canceled.connect(dialog.queue_free)
	dialog.popup_centered_clamped(Vector2i(520, 180))
	preload("res://ui/keyboard_dialog.gd").attach(dialog, field)
	field.text_submitted.connect(func(_value: String) -> void:
		if not dialog.get_ok_button().disabled: dialog.confirmed.emit())
	field.grab_focus()

func _prepare_editor_load() -> bool:
	if not is_instance_valid(canvas): return true
	if _has_pending_editor_work(): return _commit_editor_previews()
	return true

var draft_return_screen: String = "biome"

func _open_drafts() -> void:
	if screen == "create" and _editor_has_unsaved_changes():
		_confirm_editor_departure(_open_drafts_after_resolution)
		return
	_open_drafts_after_resolution()

func _open_drafts_after_resolution() -> void:
	if not _prepare_editor_load(): return
	draft_return_screen = "create" if screen == "create" else "biome"
	_show_screen("drafts")

func _drafts() -> void:
	var browser: VBoxContainer = load("res://ui/draft_browser.gd").new()
	browser.name = "DraftBrowser"
	browser.set("library",library)
	browser.set("lifecycle",lifecycle)
	if editor_return_draft_view.get("directory","") == library.directory:
		browser.set("restore_view",editor_return_draft_view.duplicate())
	editor_return_draft_view = {}
	browser.connect("fork_requested",_fork_track_draft)
	browser.connect("edit_requested",_load_saved_document)
	browser.connect("test_requested",_test_saved_draft)
	browser.connect("publish_requested",_publish_saved_draft)
	browser.connect("store_requested",_navigate_menu_page.bind("store"))
	browser.connect("back_requested",func() -> void: _show_screen(draft_return_screen if not document.is_empty() else "biome"))
	browser.connect("delete_requested",_confirm_delete_draft)
	if get_viewport().get_visible_rect().size.x < 1100 or get_viewport().get_visible_rect().size.y < 620:
		var scroll := ScrollContainer.new()
		scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
		scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
		content.add_child(scroll)
		browser.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		scroll.add_child(browser)
	else: content.add_child(browser)

func _fork_track_draft(source: Dictionary) -> void:
	var copy: Dictionary = source.duplicate(true)
	copy.id = TrackLibrary.unique_id()
	copy.name = str(copy.name)+" copy"
	document = copy
	_stamp_creator()
	if library.save_wip(document) != OK:
		_notice(library.last_error)
		return
	editor_view.clear()
	history.clear()
	redo_history.clear()
	_show_screen("create")
	_notify_creation_slots(str(document.id))

func _read_draft_for_action(id: String) -> Dictionary:
	var loaded: Dictionary = library.load_wip(id.trim_prefix("wip:")) if id.begins_with("wip:") else library.load_document(id)
	if loaded.is_empty():
		_notice("Could not load this draft: "+library.last_error)
	elif library.is_published(str(loaded.id)):
		_notice("This track is published and locked against editing.")
		return {}
	return loaded

func _test_saved_draft(id: String) -> void:
	var loaded: Dictionary = _read_draft_for_action(id)
	if loaded.is_empty(): return
	var route: Dictionary = RoadPieces.route_from_pieces(loaded)
	if not route.ok:
		_notice("Edit this track before testing: "+str(route.errors[0]))
		return
	if not loaded.has("start_line"):
		_notice("Place a start line in the editor before testing.")
		return
	loaded = route.document
	document = loaded
	var track: NativeTrack = TrackCompiler.compile(loaded)
	if track == null:
		_notice("This track needs repairs before testing. Open Edit track for details.")
		return
	if not await _prepare_creator_test(loaded,track): return
	loaded = document
	document = loaded
	editor_view.clear()
	history.clear()
	redo_history.clear()
	track.spawn = _practice_start(track)
	track.spawn_heading = _practice_heading(track)
	await _start_race(track,true)

func _complete_draft_test() -> void:
	if not is_instance_valid(game) or not game.preparation_complete or test_document_snapshot.is_empty(): return
	var witness: TrackSession = game.get("practice_validation")
	if not witness.finished or not bool(game.get("practice_validation_eligible")): return
	if not _draft_test_save_is_current(_draft_test_save_context):
		_clear_draft_test_save_recovery()
		_draft_test_save_context = {"game":game.get_instance_id(),"witness":witness,
			"storage":test_library_snapshot if test_library_snapshot != null else library,
			"scope":test_scope_snapshot,"vehicle":test_vehicle_snapshot,
			"document":test_document_snapshot.duplicate(true),"trajectory":game.race_proof.recording(witness),"was_paused":bool(game.get("paused"))}
	_retry_draft_test_save(_draft_test_save_context)

func _draft_test_save_is_current(context: Dictionary) -> bool:
	return not context.is_empty() and context==_draft_test_save_context and is_instance_valid(game) and game.preparation_complete \
		and game.get_instance_id()==int(context.game) and game.get("practice_validation")==context.witness \
		and test_library_snapshot==context.storage and library==context.storage \
		and lifecycle!=null and lifecycle.scope()==str(context.scope) \
		and test_vehicle_snapshot==str(context.vehicle) and test_document_snapshot==context.document

func _retry_draft_test_save(context: Dictionary) -> void:
	if not _draft_test_save_is_current(context): return
	if context.trajectory.is_empty():
		context.error = "The test recording is incomplete. Restart the test drive to record a new lap."
		_show_draft_test_save_recovery()
		return
	if not context.has("staged"):
		var staged: Dictionary = lifecycle.stage(context.document.duplicate(true),[],str(context.vehicle),context.storage,str(context.scope),context.trajectory)
		if staged.is_empty():
			context.error = lifecycle.last_error if not lifecycle.last_error.is_empty() else "The completed test could not be saved. Free storage, then retry saving this recording."
			_show_draft_test_save_recovery()
			return
		context.staged = staged
	var storage: TrackLibrary = context.storage
	var error: Error = storage.mark_tested(context.document.duplicate(true))
	if error != OK:
		var detail: String = storage.last_error if not storage.last_error.is_empty() else error_string(error)
		context.error = "The test recording is saved, but the test could not be marked complete. "+detail
		_show_draft_test_save_recovery()
		return
	if not bool(context.was_paused) and bool(game.get("paused")): game.toggle_pause(false)
	_clear_draft_test_save_recovery()
	pending_menu_notice = "Test lap saved on this device. Ready to publish."
	if test_return_to_drafts: _leave_race()

func _show_draft_test_save_recovery() -> void:
	if not _draft_test_save_is_current(_draft_test_save_context): return
	if not bool(game.get("paused")): game.toggle_pause(false)
	if is_instance_valid(_draft_test_save_dialog) and not _draft_test_save_dialog.is_queued_for_deletion():
		if not _draft_test_save_dialog.visible: _draft_test_save_dialog.call("popup_message")
		return
	var context: Dictionary = _draft_test_save_context
	var recovery := preload("res://ui/practice_save_recovery.gd").new()
	recovery.return_caption = "Return to drafts" if test_return_to_drafts else "Return to editor"
	recovery.retry_caption = "Restart" if context.trajectory.is_empty() else "Retry saving"
	recovery.dialog_text = str(context.get("error","The completed test could not be saved."))+"\nYour track remains saved on this device."
	_draft_test_save_dialog = recovery
	_own_dialog(recovery)
	recovery.confirmed.connect(func() -> void:
		if _draft_test_save_dialog==recovery: _draft_test_save_dialog = null
		if not _draft_test_save_is_current(context): return
		if context.trajectory.is_empty():
			_clear_draft_test_save_recovery()
			game.restart()
		else: _retry_draft_test_save.call_deferred(context))
	recovery.return_requested.connect(func() -> void:
		_return_from_draft_test_save.call_deferred(context))
	recovery.tree_exited.connect(func() -> void:
		if _draft_test_save_dialog==recovery: _draft_test_save_dialog = null)
	recovery.popup_message()

func _return_from_draft_test_save(context: Dictionary) -> void:
	if not _draft_test_save_is_current(context): return
	_clear_draft_test_save_recovery()
	_leave_race()

func _clear_draft_test_save_recovery() -> void:
	_draft_test_save_context = {}
	if is_instance_valid(_draft_test_save_dialog):
		_draft_test_save_dialog.hide()
		_draft_test_save_dialog.queue_free()
	_draft_test_save_dialog = null

func _publish_saved_draft(id: String) -> void:
	if is_instance_valid(_publication_dialog): return
	if _publication_request_active:
		_notice("Publication is already in progress. Please wait for its status to update.")
		return
	var loaded: Dictionary = _read_draft_for_action(id)
	if loaded.is_empty(): return
	_telemetry_observe("publish_requested",{"biome":str(loaded.get("theme","")),"reason":"publish"})
	if online == null or not online.client.signed_in():
		_notice("Sign in to publish this track to the cloud. Your draft remains saved locally.")
		return
	var original_scope: String = lifecycle.scope()
	var storage: TrackLibrary = library
	var navigation: int = _navigation_generation
	var notice := PublicationPrompt.new()
	_publication_dialog = notice
	notice.configure_publication(lifecycle,loaded,func() -> bool: return lifecycle.scope() == original_scope and library == storage and _navigation_generation == navigation)
	_own_dialog(notice)
	notice.publish_confirmed.connect(_confirm_saved_publication.bind(id,loaded,original_scope,storage,navigation,notice))
	notice.confirmed.connect(_close_publication_prompt.bind(loaded,original_scope,storage,navigation))
	notice.canceled.connect(_close_publication_prompt.bind(loaded,original_scope,storage,navigation))
	notice.popup_message()

func _close_publication_prompt(source: Dictionary, original_scope: String, storage: TrackLibrary, navigation: int) -> void:
	_acknowledge_publication_dialog(source,original_scope)
	if lifecycle.scope() != original_scope or library != storage or _navigation_generation != navigation: return
	var job: Dictionary = lifecycle.status_for(source)
	if job.get("state") not in ["finishing","published"] or not job.get("receipt") is Dictionary: return
	if not document.is_empty() and TrackLibrary.draft_fingerprint(document) == TrackLibrary.draft_fingerprint(source):
		document = {}
		editor_view.clear()
		history.clear()
		redo_history.clear()
	if screen == "create": _open_published_track(job.receipt)

func _confirm_saved_publication(id: String, loaded: Dictionary, original_scope: String, storage: TrackLibrary, navigation: int, notice: PublicationPrompt) -> void:
	if lifecycle.scope() != original_scope or library != storage or _navigation_generation != navigation: return
	var current: Dictionary = library.load_wip(id.trim_prefix("wip:")) if id.begins_with("wip:") else library.load_document(id)
	if current.is_empty() or TrackLibrary.draft_fingerprint(current) != TrackLibrary.draft_fingerprint(loaded):
		notice.submission_finished(false,"This draft changed while confirmation was open. Review the latest version before publishing.")
		return
	_publication_request_active = true
	var accepted_terms: bool = await preload("res://ui/community_safety_ui.gd").ensure_terms(notice,online.client)
	if lifecycle.scope() != original_scope or library != storage or _navigation_generation != navigation:
		_publication_request_active = false
		return
	if not accepted_terms:
		_publication_request_active = false
		if is_instance_valid(notice): notice.submission_finished(false,"Public sharing rules must be accepted online before publishing. Your draft remains saved.")
		return
	current = library.load_wip(id.trim_prefix("wip:")) if id.begins_with("wip:") else library.load_document(id)
	if current.is_empty() or TrackLibrary.draft_fingerprint(current) != TrackLibrary.draft_fingerprint(loaded):
		_publication_request_active = false
		if is_instance_valid(notice): notice.submission_finished(false,"This draft changed before publication. Review the latest version before publishing.")
		return
	var requested: bool = await lifecycle.request_publish(loaded)
	_publication_request_active = false
	if lifecycle.scope() != original_scope: return
	if is_instance_valid(notice): notice.submission_finished(requested,lifecycle.last_error)

func _open_published_track(receipt: Dictionary) -> void:
	# Publishing is a direct navigation to the acknowledged public card.
	# Previous search/feed filters must not hide the track just published.
	browser_state.clear()
	browser_state.focus_track = "cloud_"+str(receipt.track_id)
	browser_state.pinned_version = str(receipt.get("version_id",""))
	if cloud.paged_discovery_available(): browser_state.feed = "new"
	race_area_mode = "free"
	_show_screen("tracks")

func _prepare_creator_test(source: Dictionary, prepared: NativeTrack = null) -> bool:
	if lifecycle == null: return true
	var original_scope: String = lifecycle.scope()
	var fingerprint: String = TrackLibrary.draft_fingerprint(source)
	cloud_starting = true
	var exact: Dictionary = await lifecycle.prepare_test(source.duplicate(true),prepared)
	cloud_starting = false
	if lifecycle.scope() != original_scope or document.is_empty() or TrackLibrary.draft_fingerprint(document) != fingerprint: return false
	if exact.is_empty():
		_notice(lifecycle.last_error)
		return false
	# Keep the canvas bound to the same dictionary throughout a practice loop.
	if document != exact: document = exact
	library.owner_name = str(exact.get("creator",library.owner_name))
	if prepared != null and is_instance_valid(canvas) and _editor_copy_is_current(editor_wip_snapshot,editor_wip_store,"wip/"+str(document.id)+".json",editor_wip_disk_hash): return true
	return library.save_wip(document) == OK

func _lifecycle_changed() -> void:
	if is_instance_valid(publication_notification): publication_notification.set_entries(lifecycle.publication_notifications())
	_remember_publication_news()
	if records != null and cloud != null: cloud.migrate_record_identities(records)
	if is_instance_valid(publish_button) and not document.is_empty():
		publish_button.disabled = not lifecycle.ready_to_publish(document)
		publish_button.tooltip_text = lifecycle.caption(document)
		if is_instance_valid(editor_status): editor_status.text = lifecycle.caption(document)

func _remember_publication_news() -> void:
	if online != null and is_instance_valid(online.client.news) and lifecycle != null:
		online.client.news.remember_publications(lifecycle.publication_receipts())

func _acknowledge_publication_dialog(source: Dictionary, owner_scope: String) -> void:
	if lifecycle.scope() != owner_scope: return
	var job: Dictionary = lifecycle.status_for(source)
	if job.get("state") in ["finishing","published"]:
		lifecycle.acknowledge_publication(str(job.get("receipt",{}).get("version_id","")),owner_scope)

func _dismiss_publication_notification(item: Dictionary) -> void:
	if not lifecycle.acknowledge_publication(str(item.version_id),str(item.scope)) and lifecycle.scope() == item.scope:
		_notice(lifecycle.last_error)

func _view_publication_notification(item: Dictionary) -> void:
	if lifecycle.scope() != item.scope or is_instance_valid(game): return
	if not cloud.remember_publication(item.receipt):
		_notice("Your track is published, but could not be opened on this device. Check available storage and try again.")
		return
	if not lifecycle.acknowledge_publication(str(item.version_id),str(item.scope)):
		_notice(lifecycle.last_error)
		return
	_open_published_track(item.receipt)

func _confirm_delete_draft(id: String, title: String) -> void:
	var dialog := ConfirmationDialog.new()
	dialog.name = "DeleteDraftDialog"
	dialog.title = "Delete draft?"
	dialog.dialog_autowrap = true
	dialog.dialog_text = GameText.message('Delete "%s" and its autosave from this device?\nPublished versions stay available.\nThis cannot be undone.') % title
	dialog.ok_button_text = "Delete draft"
	dialog.confirmed.connect(func() -> void:
		_flush_editor_writes()
		if lifecycle != null and not lifecycle.archive_draft(id):
			_notice(lifecycle.last_error)
			return
		if library.delete_editable(id) != OK:
			_notice(library.last_error)
			return
		if document.get("id","") == id:
			document = {}
			history.clear()
			redo_history.clear()
			editor_view.clear()
		if selected_track != null and selected_track.identity == "creator_"+id:
			selected_track = NativeTrack.read("res://resources/tracks/"+BUILTIN_IDS[0]+".json")
		var favorites: Array = records.settings.get("favorites",[]).duplicate()
		favorites.erase("creator_"+id)
		records.settings.favorites = favorites
		if records.settings.get("last_track","") == "creator_"+id: records.settings.last_track = selected_track.identity
		var settings_error: Error = records.save_records()
		_show_screen("drafts")
		if settings_error != OK: _notice("Draft deleted, but favorite settings could not be saved."))
	_own_dialog(dialog)
	dialog.popup_centered(Vector2i(500,210))
	dialog.get_cancel_button().grab_focus()

func _load_track_dialog() -> void:
	_open_drafts()

func _load_saved_document(id: String) -> void:
	var loaded: Dictionary = _read_draft_for_action(id)
	if loaded.is_empty(): return
	document = loaded
	editor_pending_tools.clear()
	editor_saved_snapshot = library.load_document(str(loaded.id)) if id.begins_with("wip:") else loaded.duplicate(true)
	editor_saved_store = library
	editor_saved_disk_hash = "" # A recovered backup must be committed before it is acknowledged.
	canvas = null # Loading a different document must not capture the outgoing view.
	editor_view.clear()
	history.clear()
	redo_history.clear()
	editor_geometry = ""
	_show_screen("create")
	editor_status.text = "Loaded "+str(document.name)+" for editing."

func _editor_track_preview() -> NativeTrack:
	_finish_preview_thread()
	return _compile_editor_preview(document)

func _compile_editor_preview(source: Dictionary, cancelled: Callable = Callable()) -> NativeTrack:
	# Only the single preview worker (or its joined foreground replacement)
	# accesses this bounded cache. Undo can reuse collision and route data too.
	for index: int in range(editor_compiled_cache.size()):
		var entry: Dictionary = editor_compiled_cache[index]
		if entry.document == source:
			editor_compiled_cache.remove_at(index); editor_compiled_cache.append(entry); return entry.track
	var result: NativeTrack = _compile_editor_preview_uncached(source,cancelled)
	if result != null:
		var size: int = var_to_bytes(preload("res://editor/prepared_track_cache.gd").fields(result)).size()+var_to_bytes(source).size()+var_to_bytes(result.editor_winter_cover).size()
		if size <= EDITOR_COMPILED_BUDGET:
			var total: int = size
			for entry: Dictionary in editor_compiled_cache: total += int(entry.bytes)
			while not editor_compiled_cache.is_empty() and (editor_compiled_cache.size() >= 3 or total > EDITOR_COMPILED_BUDGET): total -= int(editor_compiled_cache.pop_front().bytes)
			editor_compiled_cache.append({"document":source.duplicate(true),"track":result,"bytes":size})
	return result

func _compile_editor_preview_uncached(source: Dictionary, cancelled: Callable = Callable()) -> NativeTrack:
	if TrackDocument.validate(source).is_empty(): return _compile_editor_with_masks(source,cancelled)
	if not TrackDocument.validate(source,false).is_empty(): return null
	# A draft may have an unfinished lap. Render its actual map using a safe
	# preview-only route; never change the saved route or permit racing it.
	var preview_document: Dictionary = source.duplicate(true)
	var fallback: Dictionary = TrackDocument.create_default()
	for key: String in ["points","widths","corners"]: preview_document[key] = fallback[key]
	preview_document.route_override = true
	return _compile_editor_with_masks(preview_document,cancelled)

func _compile_editor_with_masks(source: Dictionary, cancelled: Callable = Callable()) -> NativeTrack:
	var track: NativeTrack = TrackCompiler.compile(source,editor_raster_cache,cancelled)
	if track != null:
		CreatorPreviewMasks.prepare(track,source.paint,editor_raster_cache)
		track.editor_ground_key = preload("res://editor/preview_ground.gd").key_for(track)
		if source.theme == "winter": track.editor_winter_cover = WinterScenery.prepare_cover(track,editor_raster_cache,cancelled)
		if cancelled.is_valid() and cancelled.call(): return null
		# Planning roads are prepared separately, with a distinct cache identity
		# from final racing geometry. Never join road work in a draft-save handler.
	return track


func _confirm_delete_track(id: String, title: String) -> void:
	var dialog := ConfirmationDialog.new()
	dialog.name = "DeleteTrackDialog"
	dialog.title = "Delete saved track?"
	dialog.dialog_text = GameText.message('Delete "%s" from this device?\nThis cannot be undone.') % title
	dialog.ok_button_text = "Delete track"
	dialog.confirmed.connect(_delete_user_track.bind(id))
	_own_dialog(dialog)
	dialog.popup_centered(Vector2i(480,190))
	dialog.get_cancel_button().grab_focus()

func _delete_user_track(id: String) -> void:
	_flush_editor_writes()
	if library.delete_document(id) != OK:
		_notice(library.last_error)
		return
	var identity: String = "creator_"+id
	if document.get("id","") == id:
		document = {}
		history.clear()
		redo_history.clear()
		editor_view.clear()
	if selected_track != null and selected_track.identity == identity:
		selected_track = NativeTrack.read("res://resources/tracks/"+BUILTIN_IDS[0]+".json")
	var favorites: Array = records.settings.get("favorites",[]).duplicate()
	favorites.erase(identity)
	records.settings["favorites"] = favorites
	if records.settings.get("last_track","") == identity: records.settings["last_track"] = selected_track.identity
	var settings_error: Error = records.save_records()
	_show_screen("tracks")
	if settings_error != OK: _notice("Track deleted, but favorite settings could not be saved.")

func _choose_object(kind: String) -> void:
	if is_instance_valid(editor_world): editor_world.warm_prop(kind,CreatorCatalog.default_scale(kind),canvas.stamp_container_color)
	canvas.cancel_gesture()
	canvas.stamp_kind=kind
	canvas.stamp_scale=CreatorCatalog.default_scale(kind)
	object_browser.stamp_scale=canvas.stamp_scale
	canvas.selected_object=-1
	_object_placement("single")

func _container_colour(color: String) -> void:
	if not ContainerPaint.valid(color) or not is_instance_valid(canvas): return
	canvas.stamp_container_color = color
	if is_instance_valid(editor_world): editor_world.warm_prop("container",canvas.stamp_scale,color)
	if is_instance_valid(object_browser):
		object_browser.stamp_container_color = color
		object_browser.refresh()
	if canvas.selected_object < 0: return
	var object: Dictionary = document.objects[canvas.selected_object]
	if object.kind != "container" or ContainerPaint.value(object) == color: return
	_remember()
	object["color"] = color
	_commit_selection()

func _open_object_population() -> void:
	if is_instance_valid(object_population_panel) or not is_instance_valid(canvas): return
	if _has_pending_editor_work():
		_notice("Confirm or cancel the preview before populating.")
		return
	if document.objects.size() >= ObjectPopulation.MAX_OBJECTS:
		_notice("Remove an object before adding more.")
		return
	var errors: Array[String] = TrackDocument.validate(document,false)
	if not errors.is_empty():
		_notice(errors[0])
		return
	if editor_preview_thread != null or canvas.native_preview == null:
		_editor_hint("The track is still being prepared. Try Populate again shortly.")
		return
	canvas.cancel_gesture()
	var preview := ObjectPopulationPanel.new()
	preview.source = document.duplicate(true)
	preview.terrain = canvas.native_preview
	preview.navigation_canvas = canvas
	preview.previous_mode = canvas.mode
	canvas.mode = "pan"
	object_population_panel = preview
	root_ui.add_child(preview)
	preview.preview_changed.connect(func(track: NativeTrack) -> void:
		if screen == "create" and is_instance_valid(editor_world): editor_world.show_track(track))
	preview.cancel_requested.connect(func() -> void: _close_object_population(false))
	preview.apply_requested.connect(func(objects: Array) -> void:
		if document != preview.source:
			_close_object_population(false)
			_editor_hint("The track changed. Open Populate again.")
			return
		if objects.is_empty() or document.objects.size()+objects.size() > ObjectPopulation.MAX_OBJECTS: return
		var admission: String = preload("res://editor/creator_limits.gd").addition_error(document.objects,objects,str(document.theme))
		if not admission.is_empty(): _editor_hint(admission); return
		_remember()
		document.objects.append_array(objects)
		document["automatic_scenery"] = false
		canvas.selected_object = -1
		canvas.mode = "objects"
		_close_object_population(true)
		_save_draft(true)
		_build_editor_tools())

func _close_object_population(applied: bool) -> void:
	if not is_instance_valid(object_population_panel): return
	if is_instance_valid(canvas):
		canvas.cancel_gesture()
		canvas.mode = "objects" if applied else object_population_panel.previous_mode
	object_population_panel.queue_free()
	object_population_panel = null
	if not applied and is_instance_valid(editor_world) and is_instance_valid(canvas):
		editor_world.show_track(canvas.native_preview)

func _object_placement(value: String) -> void:
	canvas.cancel_gesture()
	canvas.run_start=Vector2.INF
	canvas.run_preview.clear()
	canvas.run_shape="curve" if value=="curve" else "line"
	canvas.free_run=value!="road edge"
	canvas.mode="place" if value=="single" else "run"
	object_browser.placement=value
	_build_editor_tools()

func _choose_hazard(kind: String) -> void:
	canvas.cancel_gesture()
	canvas.ghost.clear()
	canvas.stamp_kind=kind
	canvas.stamp_scale=1.0
	canvas.selected_object=-1
	canvas.mode="place"
	_build_editor_tools()
	editor_status.text=CreatorObjects.description(kind)+" / tap to place; Objects > Select to adjust"


const CREATION_BIOME_DESCRIPTIONS: Dictionary = {
	"pine":"Lush forests, open fields and classic racing character. A balanced environment with clear visibility and a broad variety of scenery.",
	"desert":"Sunset canyons, compacted sand roads and dense lingering dust. Build fast, flowing routes through warm open terrain.",
	"night_city":"A moonlit waterfront city with warm street lamps and deep shadows. Shape technical routes that come alive after dark.",
	"winter":"Snow-covered forests, frozen scenery and low-grip ice. Create bright alpine circuits where smooth driving matters.",
	"storm":"Dark forest valleys, heavy rain and lightning over wet asphalt. Design dramatic routes with reduced grip and changing visibility."
}

func _choose_biome(parent: VBoxContainer = null, preview: bool = false) -> void:
	if parent == null: parent = content
	if not preview and screen != "biome": return
	if document.is_empty() and not preview:
		document = TrackDocument.create_blank()
		document.id = TrackLibrary.unique_id()
		_stamp_creator()
	var heading_row := HBoxContainer.new()
	heading_row.add_theme_constant_override("separation",20)
	parent.add_child(heading_row)
	var heading_copy := VBoxContainer.new()
	heading_copy.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	heading_copy.add_theme_constant_override("separation",2)
	heading_row.add_child(heading_copy)
	_heading("NEW TRACK", "Select biome",heading_copy)
	var load_track := MenuStyle.button("LOAD TRACK",_open_drafts)
	load_track.name = "LoadTrack"
	load_track.icon = MenuIcon.texture("folder")
	load_track.custom_minimum_size = Vector2(190,58)
	load_track.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	heading_row.add_child(load_track)
	var selected_biome: String = str(document.get("theme",TrackDocument.THEMES[0]))
	if selected_biome not in TrackDocument.THEMES: selected_biome = TrackDocument.THEMES[0]
	parent.set_meta("biome_theme",selected_biome)
	var cards := HBoxContainer.new()
	cards.name = "BiomePicker"
	cards.add_theme_constant_override("separation",16)
	cards.size_flags_vertical = Control.SIZE_EXPAND_FILL
	parent.add_child(cards)
	for biome: String in TrackDocument.THEMES:
		var card := Button.new()
		card.name = "Biome_"+biome
		card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		card.custom_minimum_size = Vector2(180,260)
		card.clip_contents = true
		card.text = ""
		var selected: bool = biome == selected_biome
		var card_style := MenuStyle.box(Color.TRANSPARENT,0)
		card_style.set_corner_radius_all(0)
		card_style.border_color = MenuStyle.BORDER
		card_style.set_border_width_all(1)
		for state: String in ["normal","hover","pressed","focus"]:
			card.add_theme_stylebox_override(state,card_style)
		var picture := TextureRect.new()
		picture.name = "BiomePicture"
		picture.texture = TrackTile.scenery_texture(biome)
		picture.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		picture.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
		picture.modulate = Color.WHITE if selected else Color(0.62,0.68,0.72)
		picture.mouse_filter = Control.MOUSE_FILTER_IGNORE
		MenuStyle.fill(picture)
		card.add_child(picture)
		var label_panel := PanelContainer.new()
		label_panel.name = "BiomeLabelOverlay"
		label_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
		label_panel.anchor_left = 0.0
		label_panel.anchor_top = 1.0
		label_panel.anchor_right = 1.0
		label_panel.anchor_bottom = 1.0
		label_panel.offset_top = -72
		label_panel.offset_bottom = -8
		var label_style := MenuStyle.box(MenuStyle.ACCENT if selected else Color("091720f2"),0)
		label_style.set_corner_radius_all(0)
		label_panel.add_theme_stylebox_override("panel",label_style)
		var label_center := CenterContainer.new()
		label_center.mouse_filter = Control.MOUSE_FILTER_IGNORE
		label_panel.add_child(label_center)
		var label_row := HBoxContainer.new()
		label_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
		label_row.add_theme_constant_override("separation",10)
		label_center.add_child(label_row)
		var icon := TextureRect.new()
		icon.name = "BiomeIcon"
		icon.modulate = MenuStyle.INK if selected else (Color("c7dfff") if biome != "night_city" else Color("f1f4f3"))
		icon.texture = MenuIcon.texture({"pine":"leaf","desert":"cactus","night_city":"night","winter":"snowflake","storm":"storm"}.get(biome,"biomes"))
		icon.custom_minimum_size = Vector2(30,30)
		icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
		label_row.add_child(icon)
		var label := MenuStyle.label("",26)
		GameText.bind_upper(label,TrackTheme.title(biome))
		label.name = "BiomeTitle"
		label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		if selected: label.add_theme_color_override("font_color",MenuStyle.INK)
		label_row.add_child(label)
		card.add_child(label_panel)
		card.pressed.connect(_preview_creation_biome.bind(biome))
		cards.add_child(card)
	var summary_panel := PanelContainer.new()
	summary_panel.name = "BiomeSummary"
	summary_panel.custom_minimum_size.y = 118
	summary_panel.add_theme_stylebox_override("panel",MenuStyle.card(16))
	parent.add_child(summary_panel)
	var summary_row := HBoxContainer.new()
	summary_row.add_theme_constant_override("separation",20)
	summary_panel.add_child(summary_row)
	var copy := VBoxContainer.new()
	copy.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	copy.add_theme_constant_override("separation",4)
	summary_row.add_child(copy)
	var summary_title := HBoxContainer.new()
	summary_title.add_theme_constant_override("separation",10)
	copy.add_child(summary_title)
	var summary_icon := TextureRect.new()
	summary_icon.name = "BiomeSummaryIcon"
	summary_icon.modulate = Color("c7dfff") if selected_biome != "night_city" else Color("f1f4f3")
	summary_icon.texture = MenuIcon.texture({"pine":"leaf","desert":"cactus","night_city":"night","winter":"snowflake","storm":"storm"}.get(selected_biome,"biomes"))
	summary_icon.custom_minimum_size = Vector2(34,34)
	summary_icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	summary_icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	summary_title.add_child(summary_icon)
	var title := MenuStyle.label("",28)
	GameText.bind_upper(title,TrackTheme.title(selected_biome))
	title.name = "BiomeSummaryTitle"
	summary_title.add_child(title)
	var description := MenuStyle.label(str(CREATION_BIOME_DESCRIPTIONS[selected_biome]),18,true)
	description.name = "BiomeDescription"
	description.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	copy.add_child(description)
	description.resized.connect(_size_creation_biome_description.bind(description))
	description.minimum_size_changed.connect(_size_creation_biome_description.bind(description))
	summary_row.add_child(VSeparator.new())
	var create := MenuStyle.button("CREATE TRACK",func() -> void: _select_creation_biome(str(parent.get_meta("biome_theme"))),true)
	create.name = "CreateTrack"
	create.icon = MenuIcon.texture("create")
	create.add_theme_color_override("icon_normal_color",MenuStyle.INK)
	create.add_theme_color_override("icon_hover_color",MenuStyle.INK)
	create.add_theme_color_override("icon_pressed_color",MenuStyle.INK)
	create.custom_minimum_size = Vector2(250,70)
	create.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	create.add_theme_font_size_override("font_size",26)
	summary_row.add_child(create)

func _size_creation_biome_description(description: Label) -> void:
	if description.size.x <= 0: return
	var font: Font = description.get_theme_font("font")
	var font_size: int = description.get_theme_font_size("font_size")
	var spacing: int = description.get_theme_constant("line_spacing")
	var line_height: float = font.get_height(font_size)
	var metrics: Array = [description.size.x,TranslationServer.get_locale(),font,font_size,spacing,line_height]
	if description.get_meta("biome_description_metrics",[]) == metrics: return
	description.set_meta("biome_description_metrics",metrics)
	# Reserve the tallest localized description at this width, regardless of
	# selection. Recalculate on width/font/locale changes, never on a biome tap.
	var height: float = 0.0
	for source: String in CREATION_BIOME_DESCRIPTIONS.values():
		var paragraph := TextParagraph.new()
		paragraph.width = description.size.x
		paragraph.break_flags = TextServer.BREAK_MANDATORY | TextServer.BREAK_WORD_BOUND | TextServer.BREAK_ADAPTIVE
		paragraph.add_string(GameText.message(source),font,font_size,TranslationServer.get_locale())
		var lines: int = paragraph.get_line_count()
		height = maxf(height,maxf(paragraph.get_size().y,line_height*lines)+maxi(0,lines-1)*spacing)
	description.custom_minimum_size.y = ceilf(height)

func _preview_creation_biome(biome: String) -> void:
	if screen != "biome" or biome not in TrackDocument.THEMES: return
	document.theme = biome
	_update_creation_biome(content,biome)

func _update_creation_biome(parent: VBoxContainer, biome: String) -> void:
	var previous: String = str(parent.get_meta("biome_theme",""))
	if previous == biome or biome not in TrackDocument.THEMES: return
	# Selection owns only these existing controls. Keep the shell, focus and
	# prepared swipe pages alive; no navigation or page warming runs on a tap.
	var cards: HBoxContainer = parent.find_child("BiomePicker",true,false)
	for id: String in [previous,biome]:
		var card: Button = cards.get_node_or_null("Biome_"+id)
		if card == null: continue
		var selected: bool = id == biome
		var picture: TextureRect = card.get_node("BiomePicture")
		picture.modulate = Color.WHITE if selected else Color(0.62,0.68,0.72)
		var band: PanelContainer = card.get_node("BiomeLabelOverlay")
		var style: StyleBoxFlat = band.get_theme_stylebox("panel")
		style.bg_color = MenuStyle.ACCENT if selected else Color("091720f2")
		var icon: TextureRect = card.find_child("BiomeIcon",true,false)
		icon.modulate = MenuStyle.INK if selected else (Color("c7dfff") if id != "night_city" else Color("f1f4f3"))
		var label: Label = card.find_child("BiomeTitle",true,false)
		label.add_theme_color_override("font_color",MenuStyle.INK if selected else MenuStyle.TEXT)
	var summary: PanelContainer = parent.find_child("BiomeSummary",true,false)
	var summary_icon: TextureRect = summary.find_child("BiomeSummaryIcon",true,false)
	var chosen_icon: TextureRect = cards.get_node("Biome_"+biome).find_child("BiomeIcon",true,false)
	summary_icon.texture = chosen_icon.texture
	summary_icon.modulate = Color("c7dfff") if biome != "night_city" else Color("f1f4f3")
	var title: Label = summary.find_child("BiomeSummaryTitle",true,false)
	GameText.bind_upper(title,TrackTheme.title(biome))
	var description: Label = summary.find_child("BiomeDescription",true,false)
	description.text = str(CREATION_BIOME_DESCRIPTIONS[biome])
	parent.set_meta("biome_theme",biome)

func _select_creation_biome(biome: String) -> void:
	if screen != "biome" or biome not in TrackDocument.THEMES: return
	document.theme = biome
	history.clear()
	redo_history.clear()
	_show_screen("create")
	_notify_creation_slots(str(document.id))

func _notify_creation_slots(id: String) -> void:
	if lifecycle == null or online == null or not online.client.signed_in(): return
	var owner_scope: String = lifecycle.scope()
	await lifecycle.refresh_publishing_slots(true)
	if screen == "create" and str(document.get("id","")) == id and lifecycle.scope() == owner_scope and lifecycle.no_publishing_slots():
		_notice(TrackLifecycle.NO_SLOTS)

func _rename_track() -> void:
	var dialog := ConfirmationDialog.new()
	dialog.name="RenameDialog"
	dialog.borderless=true
	dialog.title="Name your track"
	dialog.ok_button_text="Apply name"
	dialog.add_theme_stylebox_override("panel",EditorStyle.box())
	EditorStyle.apply(dialog.get_ok_button())
	EditorStyle.apply(dialog.get_cancel_button())
	dialog.get_ok_button().custom_minimum_size=Vector2(130,44)
	dialog.get_cancel_button().custom_minimum_size=Vector2(110,44)
	var column := VBoxContainer.new()
	column.custom_minimum_size=Vector2(460,116)
	column.add_theme_constant_override("separation",12)
	dialog.add_child(column)
	column.add_child(MenuStyle.label("Give your track a name",22))
	var field := LineEdit.new()
	field.name="CircuitName"
	field.text=str(document.name)
	field.max_length=40
	field.custom_minimum_size=Vector2(440,52)
	field.virtual_keyboard_enabled=true
	EditorStyle.apply(field)
	field.add_theme_font_size_override("font_size",20)
	column.add_child(field)
	field.text_changed.connect(func(value: String) -> void: dialog.get_ok_button().disabled=value.strip_edges().is_empty())
	var apply_name: Callable=func() -> void:
		if field.text.strip_edges().is_empty(): return
		document.name=field.text.strip_edges()
		(root_ui.find_child("TrackName",true,false) as Label).text=document.name
		_save_draft(true)
		if DisplayServer.has_feature(DisplayServer.FEATURE_VIRTUAL_KEYBOARD): DisplayServer.virtual_keyboard_hide()
		dialog.hide(); dialog.queue_free()
	dialog.confirmed.connect(apply_name)
	field.text_submitted.connect(func(_value: String) -> void: apply_name.call())
	dialog.canceled.connect(func() -> void:
		if DisplayServer.has_feature(DisplayServer.FEATURE_VIRTUAL_KEYBOARD): DisplayServer.virtual_keyboard_hide()
		dialog.queue_free())
	root_ui.add_child(dialog)
	dialog.popup_centered_clamped(Vector2i(500,220))
	preload("res://ui/keyboard_dialog.gd").attach(dialog, field)
	field.grab_focus()
	field.select_all()
	if DisplayServer.has_feature(DisplayServer.FEATURE_VIRTUAL_KEYBOARD):
		DisplayServer.virtual_keyboard_show(field.text,field.get_viewport().get_screen_transform()*field.get_global_rect(),DisplayServer.KEYBOARD_TYPE_DEFAULT,40,0,field.text.length())

func _telemetry_observe(name: String, properties: Dictionary = {}, once_key: String = "") -> void:
	if name in ["race_attempt","race_started","race_finished","race_abandoned","race_retried"] and (returning_to_editor or (is_instance_valid(game) and bool(game.get("attempt_practice")))): return
	if product_telemetry != null: product_telemetry.observe(name,properties,once_key)

func _connect_store_telemetry(store: Node) -> void:
	store.purchase_requested.connect(func(product_id: String) -> void:
		if screen == "store" and store.is_visible_in_tree():
			_telemetry_observe("purchase_requested",{"product_id":product_id}))

func _telemetry_track_properties(track: NativeTrack, reason: String = "") -> Dictionary:
	if track == null or str(track.metadata.get("cloud_version","")).length() != 36:
		return {"reason":reason} if not reason.is_empty() else {}
	var value: Dictionary = {"car_id":str(game.get("vehicle_id")) if is_instance_valid(game) else VehicleCatalog.selected,"mode":"creator" if returning_to_editor else "challenge" if challenge_racing or challenge_practice else "rivalry" if rivalry_racing else "free"}
	if track != null:
		var version: String = str(track.metadata.get("cloud_version",""))
		if version.length() == 36: value.track_version_id = version
		value.biome = str(track.metadata.get("theme","pine"))
	var ticket: String = str(cloud_ticket.get("ticket_id",""))
	if ticket.length() == 36: value.ticket_id = ticket
	if not reason.is_empty(): value.reason = reason
	return value

func _telemetry_begin_attempt(track: NativeTrack) -> void:
	if game_configuration != null: game_configuration.set_transport_allowed(false)
	_telemetry_race_started = false
	_telemetry_race_finished = false
	if product_telemetry != null: product_telemetry.set_transport_allowed(false)
	if client_quality != null:
		client_quality.start_race(track,cloud_ticket,not returning_to_editor and is_instance_valid(game) and not bool(game.get("attempt_practice")))
	_telemetry_observe("race_attempt",_telemetry_track_properties(track))

func _telemetry_observe_activity() -> void:
	if product_telemetry == null: return
	var racing: bool = is_instance_valid(game) and not _telemetry_race_finished
	if game_configuration != null: game_configuration.set_transport_allowed(not racing and not cloud_starting and not is_instance_valid(race_loading))
	product_telemetry.set_transport_allowed(not racing and not cloud_starting and not is_instance_valid(race_loading))
	if racing:
		# A coarse observer reads presentation state once/second. No simulation hook.
		var simulation: VehicleSimulation = game.get("sim")
		if not _telemetry_race_started and simulation != null and simulation.state.tick > 0:
			_telemetry_race_started = true
			_telemetry_observe("race_started",_telemetry_track_properties(game.get("native_track")))
		return
	if not is_instance_valid(root_ui) or not root_ui.visible or not is_instance_valid(content): return
	# Settled current content only; prepared neighbours and outgoing pages do not
	# establish an offer even when their render commands are warmed offscreen.
	if is_instance_valid(menu_body) and absf(menu_body.position.x) > 1.0: return
	if screen == "garage":
		var garage: GaragePage = content.find_child("GaragePage",true,false) as GaragePage
		if garage != null:
			for exposure: Dictionary in garage.telemetry_exposures():
				_telemetry_observe("car_exposed",exposure,str(_navigation_generation)+"/garage/"+str(exposure.car_id))
		return
	if screen == "store":
		var store: Node = content.find_child("StorePage",true,false)
		if store != null:
			if game_configuration != null and not store.telemetry_exposures().is_empty(): game_configuration.menu_applied("store",true)
			for product: String in store.telemetry_exposures():
				_telemetry_observe("offer_exposed",{"product_id":product},str(_navigation_generation)+"/"+product)
		return
	if screen != "tracks": return
	var browser: TrackBrowser = content.find_child("TrackBrowser",true,false) as TrackBrowser
	if browser == null: return
	for exposure: Dictionary in browser.telemetry_exposures():
		var properties: Dictionary = {"track_version_id":str(exposure.entry.get("version_id","")),"car_id":VehicleCatalog.selected,"biome":str(exposure.entry.get("theme","")),"mode":"free","position":int(exposure.position)}
		_telemetry_observe("track_exposed",properties,str(_navigation_generation)+"/"+str(properties.track_version_id)+"/"+str(properties.car_id))

func _select_header_vehicle(index: int) -> void:
	if index < 0 or index >= VehicleCatalog.IDS.size() or VehicleCatalog.IDS[index] == VehicleCatalog.selected: return
	_select_vehicle(index)
	if is_instance_valid(_retained_garage) and _retained_garage.records == records and _retained_garage.is_visible_in_tree():
		_retained_garage.refresh_selection()
	if not is_instance_valid(content): return
	var daily_car: OptionButton = content.find_child("DailyCar",true,false)
	if daily_car != null: daily_car.select(index)
	var browser: TrackBrowser = content.find_child("TrackBrowser",true,false) as TrackBrowser
	if browser != null:
		browser._show_detail()
		browser._warm_visible_comparisons(maxi(0,int(browser.gallery.scroll_horizontal/browser.tile_stride)-1))

func _select_vehicle(index: int) -> void:
	var chosen: String = VehicleCatalog.IDS[clampi(index,0,VehicleCatalog.IDS.size()-1)]
	_telemetry_observe("car_selected",{"car_id":chosen})
	records.settings.selected_car = chosen
	var saved: Error = records.save_records()
	VehicleCatalog.selected = chosen
	_refresh_account_car()
	_prefetch_rivalry()
	_prime_free_race_comparisons()
	if saved != OK: _notice("Car selected for this session. Could not save preference: " + error_string(saved))

func _build_surface_toolbar() -> void:
	for child: Node in surface_actions.get_children():
		surface_actions.remove_child(child)
		child.queue_free()
	surface_actions.add_theme_constant_override("separation",12)
	var modes := VBoxContainer.new()
	surface_actions.add_child(modes)
	var heading := MenuStyle.label("Paint mode",18)
	heading.add_theme_color_override("font_color",Color("97dce1"))
	modes.add_child(heading)
	var segments := HBoxContainer.new()
	segments.name = "SurfacePlacementModes"
	segments.add_theme_constant_override("separation",0)
	modes.add_child(segments)
	for entry: Array in [["free","Free","paint_brush"],["area","Area","paint_area"],["line","Line","paint_line"]]:
		var value: String = entry[0]
		var chosen: bool = canvas.paint_mode == value
		var button: Button = EditorButton.make(entry[1],entry[2],func() -> void:
			canvas.cancel_gesture()
			canvas.paint_mode = value
			canvas.mode = "paint"
			canvas.queue_redraw()
			_build_editor_tools(),chosen)
		button.name = "PaintMode_"+value
		button.custom_minimum_size = Vector2(78,68)
		for state: String in ["normal","hover","pressed","hover_pressed"]:
			var style: StyleBoxFlat = EditorStyle.box(chosen or state in ["pressed","hover_pressed"],state=="hover",18)
			if chosen: style.bg_color = Color("087b8d")
			button.add_theme_stylebox_override(state,style)
		segments.add_child(button)
	var brush := VBoxContainer.new()
	brush.custom_minimum_size.x = 178
	surface_actions.add_child(brush)
	var size_label := MenuStyle.label(GameText.message("Brush size  %.1f m") % canvas.brush_width,18)
	size_label.name = "BrushSizeReadout"
	size_label.add_theme_color_override("font_color",Color("97dce1"))
	brush.add_child(size_label)
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel",EditorStyle.box())
	brush.add_child(panel)
	var controls := HBoxContainer.new()
	panel.add_child(controls)
	var slider := HSlider.new()
	slider.name = "BrushSizeSlider"
	slider.min_value = 0.5
	slider.max_value = 40.0
	slider.step = 0.5
	slider.value = canvas.brush_width
	slider.custom_minimum_size = Vector2(112,48)
	slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var rail := StyleBoxFlat.new()
	rail.bg_color = Color("304b54")
	rail.set_corner_radius_all(4)
	rail.content_margin_top = 4
	rail.content_margin_bottom = 4
	slider.add_theme_stylebox_override("slider",rail)
	var fill: StyleBoxFlat = rail.duplicate()
	fill.bg_color = EditorStyle.ACCENT
	slider.add_theme_stylebox_override("grabber_area",fill)
	slider.add_theme_stylebox_override("grabber_area_highlight",fill)
	slider.value_changed.connect(func(value: float) -> void:
		canvas.brush_width = value
		size_label.text = GameText.message("Brush size  %.1f m") % value
		canvas.queue_redraw())
	var smaller: Button = EditorStyle.button("-",func() -> void: slider.value -= 0.5)
	smaller.name = "BrushSmaller"
	smaller.custom_minimum_size = Vector2(36,48)
	controls.add_child(smaller)
	controls.add_child(slider)
	var bigger: Button = EditorStyle.button("+",func() -> void: slider.value += 0.5)
	bigger.name = "BrushBigger"
	bigger.custom_minimum_size = Vector2(36,48)
	controls.add_child(bigger)
	var options: Button = EditorButton.make("","options",func() -> void: editor_tools_panel.visible = not editor_tools_panel.visible)
	options.name = "SurfaceOptions"
	options.tooltip_text = "Brush shape, navigation and road protection"
	options.size_flags_vertical = Control.SIZE_SHRINK_END
	surface_actions.add_child(options)
