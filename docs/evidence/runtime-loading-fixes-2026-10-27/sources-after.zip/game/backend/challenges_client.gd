class_name ChallengesClient
extends Node
## Invitations, retry identity and account fences stay outside the simulation.
signal changed
var client: Node
var result_poll_allowed: Callable
var cloud: Node
var items: Array[Dictionary] = []
var selected: Dictionary = {}
var folder: String = "discover"
var search: String = ""
var mode_filter: String = "all"
var vehicle_filter: String = ""
var sort_order: String = "ending"
var creation_visibility: String = "public"
var busy: bool = false
var error: String = ""
var result_ticket: String = ""
var result_state: String = ""
var outcome: Dictionary = {}
var _generation: int = 0
var _polling: bool = false
var _next_poll: int = 0
var _failures: int = 0
var _scope: String = ""
var _selection_serial: int = 0
var _busy_serial: int = 0
var _folder_refresh_pending: bool = false
var next_cursor: String = ""
var result_code: String = ""
var selected_stage: int = 0
var _next_full_result: int = 0

func _ready() -> void:
	if is_instance_valid(client) and client.has_signal("run_completed"): client.run_completed.connect(poll_result)
	if is_instance_valid(client) and is_instance_valid(client.get("safety")): client.safety.changed.connect(_safety_changed)

func _safety_changed() -> void:
	_next_full_result = 0
	if client.has_method("invalidate_challenge_completions"): client.invalidate_challenge_completions()
	if not is_instance_valid(client.get("safety")): return
	if not _scope.is_empty() and _scope != scope():
		reset()
		changed.emit()
		return
	items = items.filter(func(item: Dictionary) -> bool: return not client.safety.is_blocked(str(item.get("creator_id",""))) and client.safety.allows(item.get("entry",{})))
	if client.safety.is_blocked(str(selected.get("creator_id",""))): selected = {}
	client.safety.mask_public(selected)
	client.safety.mask_public(items)
	changed.emit()
	if client.signed_in() and not busy: refresh.call_deferred()

func scope() -> String:
	return str(client.base_url())+"/"+str(client.player.get("id",""))

func discovery_supported() -> bool:
	var capabilities: Variant = client.get("_capabilities")
	return capabilities is Dictionary and int(capabilities.get("challenge_discovery_version",0)) == 1

func series_supported() -> bool:
	var capabilities: Variant = client.get("_capabilities")
	return capabilities is Dictionary and int(capabilities.get("challenge_series_version",0)) == 1

func custom_tracks_supported() -> bool:
	var capabilities: Variant = client.get("_capabilities")
	return capabilities is Dictionary and int(capabilities.get("challenge_custom_tracks_version",0)) == 1

static func is_series(value: Dictionary) -> bool:
	return value.get("stages") is Array and not value.stages.is_empty()

func race_stage() -> Dictionary:
	if is_series(selected) and selected.get("stages") is Array and selected_stage < selected.stages.size(): return selected.stages[selected_stage]
	return selected

func select_stage(index: int) -> void:
	if index < 0 or not is_series(selected) or index >= selected.stages.size(): return
	selected_stage = index
	changed.emit()

func reset() -> void:
	selected_stage = 0
	_generation += 1
	_selection_serial += 1
	_busy_serial += 1
	_folder_refresh_pending = false
	items.clear()
	selected = {}
	busy = false
	error = ""
	result_ticket = ""
	result_state = ""
	outcome = {}
	_polling = false
	_next_poll = 0
	_next_full_result = 0
	_failures = 0
	_scope = scope()
	next_cursor = ""
	result_code = ""
	search = ""
	mode_filter = "all"
	vehicle_filter = ""
	sort_order = "ending"

static func code_from(value: String) -> String:
	var code: String = value.strip_edges().get_slice("?",0).get_slice("#",0).trim_suffix("/").get_file().replace("-","").replace(" ","").to_upper()
	return code if code.length() == 16 and code.is_valid_hex_number(false) else ""

static func valid_snapshot(value: Variant) -> bool:
	if not value is Dictionary or not value.has_all(["id","code","mode","state","entry","manifest","standings","vehicle_id","ends_at","server_now","creator_id","creator","joined","self_id","share_url"]): return false
	for field: String in ["id","code","creator_id","creator","share_url"]:
		if not preload("res://backend/backend_client.gd")._text(value.get(field)): return false
	if not value.self_id is String: return false
	if code_from(str(value.code)) != value.code or value.mode not in ["beat","group","3x3"] or value.state not in ["active","settling","complete","cancelled"] or value.vehicle_id not in VehicleCatalog.IDS or not value.joined is bool: return false
	if not value.entry is Dictionary or not value.entry.has_all(["name","version_id","track_id","content_hash","points"]): return false
	for field: String in ["name","version_id","track_id","content_hash"]:
		if not preload("res://backend/backend_client.gd")._text(value.entry.get(field)): return false
	if not value.entry.points is Array or value.entry.points.size() < 2 or value.entry.points.size() > 4096: return false
	for point: Variant in value.entry.points:
		if not point is Array or point.size() != 2 or not (point[0] is float or point[0] is int) or not (point[1] is float or point[1] is int) or not is_finite(float(point[0])) or not is_finite(float(point[1])): return false
	if not value.manifest is Dictionary or int(value.manifest.get("laps",0)) != 5 or not value.manifest.get("tick_rate") is float and not value.manifest.get("tick_rate") is int or int(value.manifest.tick_rate) <= 0: return false
	if not value.standings is Array or value.standings.is_empty() or value.standings.size() > 20: return false
	if value.has("stages") and not is_series(value): return false
	if value.has("track_count") and (not preload("res://backend/backend_client.gd")._whole(value.track_count,1,5) or value.track_count != (value.stages.size() if is_series(value) else 1)): return false
	if value.mode == "beat" and not is_series(value) and (not preload("res://backend/backend_client.gd")._whole(value.get("target_ticks"),1,216000) or not preload("res://backend/backend_client.gd")._whole(value.get("target_ms"),1)): return false
	if value.has("attempt_limit") or value.has("attempts_used") or value.has("attempts_remaining"):
		if not value.has_all(["attempt_limit","attempts_used","attempts_remaining"]): return false
		var limit: Variant = value.attempt_limit
		var track_count: int = value.stages.size() if is_series(value) else 1
		if limit != null and (not preload("res://backend/backend_client.gd")._whole(limit,1,25) or int(limit) not in ([9] if value.mode == "3x3" else [track_count,3*track_count,5*track_count])): return false
		if not preload("res://backend/backend_client.gd")._whole(value.attempts_used): return false
		if limit == null:
			if value.attempts_remaining != null: return false
		elif not preload("res://backend/backend_client.gd")._whole(value.attempts_remaining,0,int(limit)) or int(value.attempts_used)+int(value.attempts_remaining) != int(limit): return false
	if value.mode == "3x3" or is_series(value):
		if value.get("scoring") != "total_best_time" or not is_series(value) or value.stages.size() < 2 or value.stages.size() > 5: return false
		if value.mode == "3x3" and (value.stages.size() != 3 or value.get("attempt_limit") != 9): return false
		var versions: Dictionary = {}
		var tracks: Dictionary = {}
		var stage_limit: Variant = value.stages[0].get("attempt_limit") if value.stages[0] is Dictionary else -1
		if stage_limit == null:
			if value.get("attempt_limit") != null: return false
		elif not preload("res://backend/backend_client.gd")._whole(stage_limit,1,5) or int(stage_limit) not in [1,3,5] or value.get("attempt_limit") != int(stage_limit)*value.stages.size(): return false
		for index: int in range(value.stages.size()):
			var stage: Variant = value.stages[index]
			if not stage is Dictionary or not stage.has_all(["index","entry","manifest","standings","attempt_limit","attempts_used","attempts_remaining"]) or stage.index != index or stage.attempt_limit != stage_limit: return false
			var single: Dictionary = value.duplicate(true)
			single.mode = "group"
			single.capacity = 20
			for field: String in ["entry","manifest","standings","attempt_limit","attempts_used","attempts_remaining"]: single[field] = stage[field]
			single.erase("stages")
			single.erase("track_count")
			if not valid_snapshot(single) or versions.has(str(stage.entry.version_id)) or tracks.has(str(stage.entry.track_id)): return false
			tracks[str(stage.entry.track_id)] = true
			versions[str(stage.entry.version_id)] = true
			for field: String in ["laps","tick_rate","vehicle_id","rules_key","physics_version","compiler_version","handling_version","config_hash"]:
				if stage.manifest.get(field) != value.manifest.get(field): return false
		if value.entry != value.stages[0].entry: return false
	var seen: Dictionary = {}
	for row: Variant in value.standings:
		if not row is Dictionary or not row.has_all(["id","name","ticks","ms","rank","run_id"]) or seen.has(str(row.id)): return false
		if not preload("res://backend/backend_client.gd")._text(row.id) or not preload("res://backend/backend_client.gd")._text(row.name): return false
		if row.ticks == null and (row.ms != null or row.rank != null or row.run_id != null): return false
		if value.mode == "3x3" or is_series(value):
			if not preload("res://backend/backend_client.gd")._whole(row.get("completed_tracks"),0,value.stages.size()): return false
			var count: int = 0
			var total: int = 0
			for stage: Dictionary in value.stages:
				var found: bool = false
				for stage_row: Dictionary in stage.standings:
					if str(stage_row.id) == str(row.id):
						found = true
						if stage_row.ticks != null:
							count += 1
							total += int(stage_row.ticks)
				if not found: return false
			if int(row.completed_tracks) != count or (row.ticks != null and (count != value.stages.size() or int(row.ticks) != total)) or (row.ticks == null and count == value.stages.size()): return false
		seen[str(row.id)] = true
		if row.ticks != null and (not preload("res://backend/backend_client.gd")._whole(row.ticks,1,216000*value.stages.size() if is_series(value) else 216000) or not preload("res://backend/backend_client.gd")._whole(row.rank,1,20) or not preload("res://backend/backend_client.gd")._whole(row.ms,1)): return false
	if value.joined != seen.has(str(value.self_id)): return false
	if value.has("visibility") and value.visibility not in ["public","private"]: return false
	if value.has("capacity") and (not preload("res://backend/backend_client.gd")._whole(value.capacity,2,20) or int(value.capacity) != (2 if value.mode == "beat" else 20)): return false
	if value.has("rewards"):
		var rewards: Variant = value.rewards
		if not rewards is Dictionary or not rewards.has_all(["finish","goal","finish_earned","goal_earned","eligible","daily_limit","remaining_today"]): return false
		for field: String in ["finish","goal","daily_limit","remaining_today"]:
			if not preload("res://backend/backend_client.gd")._whole(rewards[field],0,10000): return false
		for field: String in ["finish_earned","goal_earned","eligible"]:
			if not rewards[field] is bool: return false
		if int(rewards.remaining_today) > int(rewards.daily_limit): return false
	return preload("res://backend/backend_client.gd")._whole(value.ends_at) and preload("res://backend/backend_client.gd")._whole(value.server_now)

func _request(path: String, method: HTTPClient.Method = HTTPClient.METHOD_GET, payload: Dictionary = {}, authorized: bool = true) -> Dictionary:
	if _scope != scope(): reset()
	var original: String = scope()
	var generation: int = _generation
	var key: String = ""
	var saved: Dictionary = {}
	var signature: String = ""
	var path_to_keys: String = ""
	if method == HTTPClient.METHOD_POST:
		path_to_keys = cloud.cache_root().path_join("players").path_join(str(client.player.get("id","")).sha256_text()).path_join("challenge-operations.json")
		saved = cloud._read(path_to_keys)
		if saved.has("_read_error"): return {"ok":false,"error":"Could not recover challenge creation. Original retry data was preserved."}
		signature = JSON.stringify([path,payload],"",true).sha256_text()
		key = str(saved.get(signature,client.new_operation_key()))
		saved[signature] = key
		if not cloud._write(path_to_keys,saved): return {"ok":false,"error":"Could not save challenge retry. Check available storage."}
	var response: Dictionary = await client.request_api(path,method,payload,key,authorized)
	if generation != _generation or original != scope(): return {"ok":false,"error":"Account changed"}
	if response.get("ok",false) and not signature.is_empty():
		saved = cloud._read(path_to_keys)
		if not saved.has("_read_error"):
			saved.erase(signature)
			cloud._write(path_to_keys,saved)
	return response

func select_folder(value: String) -> void:
	if value not in ["discover","friends","received","sent"]: return
	if _scope != scope(): reset()
	if folder == value: return
	folder = value
	items.clear()
	selected = {}
	next_cursor = ""
	_selection_serial += 1
	error = ""
	if busy:
		# Keep only the latest folder intent, including changes during detail or
		# mutation requests. The request owner drains it when that reply arrives.
		_folder_refresh_pending = true
		changed.emit()
	else: refresh()

func set_filters(query: String, mode: String, vehicle: String, order: String) -> void:
	if mode not in ["all","beat","group","3x3"] or order not in ["ending","newest"] or (not vehicle.is_empty() and vehicle not in VehicleCatalog.IDS): return
	if _scope != scope(): reset()
	search = query.strip_edges().left(80)
	mode_filter = mode
	vehicle_filter = vehicle
	sort_order = order
	items.clear()
	selected = {}
	next_cursor = ""
	_selection_serial += 1
	if busy:
		_folder_refresh_pending = true
		changed.emit()
	else: refresh()

func _refresh_pending_folder() -> bool:
	if not _folder_refresh_pending: return false
	_folder_refresh_pending = false
	busy = false
	refresh()
	return true

func refresh(append: bool = false) -> void:
	if _scope != scope(): reset()
	if busy: return
	if not client.signed_in() and folder != "discover":
		items.clear()
		error = "Sign in to see your challenges and friends."
		changed.emit()
		return
	var capabilities: Variant = client.get("_capabilities")
	if folder in ["discover","friends"] and capabilities is Dictionary and not discovery_supported():
		items.clear()
		error = "Challenge discovery needs the updated online service. Your joined races are still available."
		changed.emit()
		return
	busy = true
	_busy_serial += 1
	var serial: int = _busy_serial
	var generation: int = _generation
	var requested_folder: String = folder
	var requested_filters: Array = [search,mode_filter,vehicle_filter,sort_order]
	var path: String = "/challenges?folder="+requested_folder if client.signed_in() else "/challenges/discover?"
	if not search.is_empty(): path += "&search="+search.uri_encode()
	if series_supported(): path += "&series=1"
	if custom_tracks_supported(): path += "&custom_tracks=1"
	if mode_filter != "all": path += "&mode="+mode_filter
	if not vehicle_filter.is_empty(): path += "&vehicle="+vehicle_filter.uri_encode()
	if sort_order != "ending": path += "&sort="+sort_order
	if append and not next_cursor.is_empty(): path += "&cursor="+next_cursor.uri_encode()
	changed.emit()
	var response: Dictionary = await _request(path,HTTPClient.METHOD_GET,{},client.signed_in())
	if generation != _generation or serial != _busy_serial or _scope != scope(): return
	if requested_folder != folder or requested_filters != [search,mode_filter,vehicle_filter,sort_order] or (append and _folder_refresh_pending):
		_folder_refresh_pending = true
		_refresh_pending_folder()
		return
	# A burst that returns to the original folder can use its in-flight reply.
	_folder_refresh_pending = false
	busy = false
	if response.get("ok",false) and response.data.get("items") is Array and response.data.items.size() <= 50:
		var incoming: Array[Dictionary] = []
		for item: Variant in response.data.items:
			if not valid_snapshot(item):
				error = "Challenge list could not be loaded. Try again."
				changed.emit()
				return
			incoming.append(item)
		if append:
			for item: Dictionary in incoming:
				if items.size() < 100 and not items.any(func(existing: Dictionary) -> bool: return existing.code == item.code): items.append(item)
		else: items = incoming
		for item: Dictionary in incoming:
			if str(item.code) == str(selected.get("code","")): selected = item
		next_cursor = str(response.data.next_cursor) if response.data.get("next_cursor") is String and items.size() < 100 else ""
		if selected.is_empty() and not incoming.is_empty(): selected = incoming[0]
		error = ""
	else: error = friendly(str(response.get("error","")))
	changed.emit()
	if not selected.is_empty() and not items.any(func(item: Dictionary) -> bool: return str(item.code) == str(selected.code)):
		await open(str(selected.code))

func open(value: String) -> void:
	if _scope != scope(): reset()
	var code: String = code_from(value)
	if code.is_empty():
		error = "Enter a challenge code or invitation link."
		changed.emit()
		return
	_selection_serial += 1
	var serial: int = _selection_serial
	busy = true
	_busy_serial += 1
	var busy_serial: int = _busy_serial
	var generation: int = _generation
	changed.emit()
	var response: Dictionary = await _request("/challenges/"+code+("/me" if client.signed_in() else ""),HTTPClient.METHOD_GET,{},client.signed_in())
	if generation != _generation or busy_serial != _busy_serial or _scope != scope(): return
	if _refresh_pending_folder(): return
	if serial != _selection_serial: return
	busy = false
	if response.get("ok",false) and valid_snapshot(response.data):
		if str(selected.get("code","")) != str(response.data.code): selected_stage = 0
		selected = response.data
		error = ""
	else: error = friendly(str(response.get("error","")))
	changed.emit()

func create_challenge(payload: Dictionary) -> void:
	await _mutate("/challenges",payload)

func join() -> void:
	if selected.is_empty(): return
	await _mutate("/challenges/"+str(selected.code)+"/join")

func rematch() -> void:
	if selected.is_empty(): return
	await _mutate("/challenges/"+str(selected.code)+"/rematch",{"duration_seconds":604800})

func cancel() -> void:
	if selected.is_empty(): return
	await _mutate("/challenges/"+str(selected.code)+"/cancel")

func _mutate(path: String, payload: Dictionary = {}) -> void:
	if _scope != scope(): reset()
	if busy: return
	busy = true
	_busy_serial += 1
	var serial: int = _busy_serial
	var generation: int = _generation
	error = ""
	changed.emit()
	var response: Dictionary = await _request(path,HTTPClient.METHOD_POST,payload)
	if generation != _generation or serial != _busy_serial or _scope != scope(): return
	if _refresh_pending_folder(): return
	busy = false
	if response.get("ok",false) and valid_snapshot(response.data):
		if str(selected.get("code","")) != str(response.data.code): selected_stage = 0
		selected = response.data
	else: error = friendly(str(response.get("error","")))
	changed.emit()

func source(version: String, vehicle: String, ticket_id: String = "") -> Dictionary:
	var response: Dictionary = await _request("/challenges/sources?version_id="+version.uri_encode()+"&vehicle_id="+vehicle.uri_encode()+("&ticket_id="+ticket_id.uri_encode() if not ticket_id.is_empty() else ""))
	if response.get("ok",false) and not ticket_id.is_empty() and (response.data.get("status") == "skipped" or (response.data.get("status") == "failed" and response.data.get("retryable",false))):
		# Choosing this completed run as a new competitive target needs its path
		# checked. Ordinary non-improving completions never make this request.
		var requested: Dictionary = await _request("/runs/"+str(response.data.run_id)+"/retry",HTTPClient.METHOD_POST,{})
		if requested.get("ok",false): return {"run_id":requested.data.run_id,"status":requested.data.status,"ms":null}
		return {"status":"unavailable","error":friendly(str(requested.get("error","")))}
	return response.data if response.get("ok",false) else {"status":"unavailable","error":friendly(str(response.get("error","")))}

func ticket(stage_override: int = -1) -> Dictionary:
	var stage_index: int = selected_stage if stage_override < 0 else stage_override
	if selected.is_empty() or not selected.get("joined",false) or selected.state != "active":
		error = "Challenge ended. Choose an active challenge." if not selected.is_empty() and selected.get("state") != "active" else "Open and join the challenge to race again."
		return {}
	if is_series(selected) and (stage_index < 0 or stage_index >= selected.stages.size()):
		error = "Select a challenge track to race."
		return {}
	var original: String = scope()
	var serial: int = _selection_serial
	var code: String = str(selected.code)
	var response: Dictionary = await _request("/challenges/"+code+"/tickets"+("?stage="+str(stage_index) if is_series(selected) else ""),HTTPClient.METHOD_POST)
	if original != scope() or serial != _selection_serial or str(selected.get("code","")) != code: return {}
	if not response.get("ok",false):
		error = friendly(str(response.get("error","")))
		changed.emit()
		return {}
	if int(response.data.get("expires_at",0)) <= client.server_now():
		error = "Race invitation expired. Try again for a fresh start."
		changed.emit()
		return {}
	var budget: Dictionary = selected.stages[stage_index] if is_series(selected) else selected
	for field: String in ["attempt_limit","attempts_used","attempts_remaining"]:
		if response.data.has(field): budget[field] = response.data[field]
	error = ""
	response.data["_challenge_stage"] = stage_index
	return response.data

func ghost(stage_override: int = -1) -> Dictionary:
	var stage_index: int = selected_stage if stage_override < 0 else stage_override
	if selected.is_empty(): return {}
	if is_series(selected) and (stage_index < 0 or stage_index >= selected.stages.size()): return {}
	var path: String = "/challenges/"+str(selected.code)+"/ghost"+("?stage="+str(stage_index) if is_series(selected) else "")
	var original: String = scope()
	var generation: int = _generation
	if client.has_method("fetch_recording"):
		var recording: Dictionary = await client.fetch_recording(path,client.signed_in())
		return recording if original == scope() and generation == _generation and not selected.is_empty() and path.begins_with("/challenges/"+str(selected.code)+"/") else {}
	var response: Dictionary = await _request(path,HTTPClient.METHOD_GET,{},false)
	if not response.get("ok",false): return {}
	return preload("res://backend/weekly_rivalry_client.gd")._validate_ghost(response.data.get("recording",{}))

func begin_result(ticket_id: String) -> void:
	result_ticket = ticket_id
	result_code = str(selected.get("code",""))
	result_state = "upload_pending"
	outcome = {}
	_next_poll = 0
	_next_full_result = Time.get_ticks_msec()+10000
	_failures = 0

func _merge_pending(data: Dictionary) -> Dictionary:
	if data.get("schema") != "bmt-challenge-pending-v1" or data.get("status") not in ["upload_pending","queued","verifying"] or not data.get("challenge_pending") is Dictionary: return {}
	var update: Dictionary = data.challenge_pending
	if selected.is_empty() or update.get("id") != selected.get("id") or update.get("code") != result_code or update.get("self_id") != str(client.player.get("id","")): return {}
	var merged: Dictionary = selected.duplicate(true)
	for key: String in ["state","ends_at","server_now","remaining_seconds","attempt_limit","attempts_used","attempts_remaining","rewards"]:
		if not update.has(key): return {}
		merged[key] = update[key]
	if is_series(merged):
		if not update.get("stages") is Array or update.stages.size() != merged.stages.size(): return {}
		var seen: Dictionary = {}
		for stage: Variant in update.stages:
			if not stage is Dictionary or not preload("res://backend/backend_client.gd")._whole(stage.get("index"),0,merged.stages.size()-1): return {}
			var index: int = int(stage.index)
			if seen.has(index): return {}
			seen[index] = true
			for key: String in ["attempt_limit","attempts_used","attempts_remaining"]:
				if not stage.has(key): return {}
				merged.stages[index][key] = stage[key]
	return merged if valid_snapshot(merged) else {}

func poll_result() -> void:
	if result_poll_allowed.is_valid() and not bool(result_poll_allowed.call()): return
	if _polling or result_ticket.is_empty() or result_state in ["verified","skipped","rejected","expired"]: return
	var recent: Dictionary = client.recent_run(result_ticket) if client.has_method("recent_run") else {}
	var confirmed: bool = recent.get("status") in ["verified","skipped"] and _failures == 0
	if Time.get_ticks_msec() < _next_poll and not confirmed: return
	var expected: String = result_ticket
	var original: String = scope()
	_polling = true
	var completion: Dictionary = client.recent_completion(expected) if client.has_method("recent_completion") and _failures == 0 else {}
	var cached: Variant = completion.get("challenge_result")
	var compact: bool = client.get("_capabilities") is Dictionary and int(client._capabilities.get("challenge_pending_version",0)) == 1 and Time.get_ticks_msec() < _next_full_result and valid_snapshot(selected)
	var response: Dictionary
	if cached is Dictionary and valid_snapshot(cached.get("challenge")) and cached.challenge.get("code") == result_code and cached.challenge.get("self_id") == str(client.player.get("id","")):
		response = {"ok":true,"status":200,"data":cached.duplicate(true)}
		if is_instance_valid(client.get("safety")): client.safety.mask_public(response.data)
	else:
		response = await _request("/challenge-results/"+expected+("?compact=true" if compact else ""))
	_polling = false
	if expected != result_ticket or original != scope(): return
	var data: Dictionary = response.get("data",{}) if response.get("data") is Dictionary else {}
	var pending_only: bool = data.get("schema") == "bmt-challenge-pending-v1"
	if pending_only: data.challenge = _merge_pending(data)
	var valid: bool = response.get("ok",false) and valid_snapshot(data.get("challenge")) and data.get("status") in ["upload_pending","queued","verifying","verified","skipped","rejected","failed","expired"]
	var jitter: int = int(Crypto.new().generate_random_bytes(1)[0])*10
	_next_poll = Time.get_ticks_msec()+maxi(1000,int(data.get("poll_after_ms",2500)))+jitter
	if not valid:
		_next_full_result = 0
		_failures = mini(_failures+1,5)
		var wait_msec: int = maxi(int(response.get("retry_after",0))*1000,mini(60000,2500*int(pow(2,_failures))))
		_next_poll = Time.get_ticks_msec()+wait_msec+jitter
		error = "Result saved. Reconnect to verify it."
	else:
		if not pending_only: _next_full_result = Time.get_ticks_msec()+10000
		_failures = 0
		if str(selected.get("code","")) == result_code: selected = response.data.challenge
		result_state = str(response.data.get("status","upload_pending"))
		outcome = response.data.get("outcome",{}) if response.data.get("outcome") is Dictionary else {}
		error = ""
		if result_state == "failed":
			if response.data.get("failure_code") == "verifier_unavailable":
				result_state = "retry_pending"
				_next_poll = Time.get_ticks_msec()+15000+jitter
				error = "Your race is saved. Verification will retry."
			else:
				result_state = "rejected"
				error = "This race could not be verified."
		elif result_state in ["rejected","expired"]: error = "This race did not enter the challenge standings."
	changed.emit()

static func friendly(message: String) -> String:
	if message in ["NETWORK_ERROR","REQUEST_START_FAILED","NOT_CONFIGURED"]: return "Challenges unavailable. Check your connection and try again."
	if message in ["DATABASE_UNAVAILABLE","STORAGE_UNAVAILABLE","INVALID_RESPONSE"]: return "Challenges unavailable. Try again."
	if message == "Not Found": return "Challenges are not available yet."
	if message == "SIGN_IN_REQUIRED": return "Sign in to create or join a challenge."
	return message if not message.is_empty() else "Challenges unavailable. Try again."
