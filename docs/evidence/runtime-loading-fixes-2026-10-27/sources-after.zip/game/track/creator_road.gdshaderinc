#include "res://track/surface_detail.gdshaderinc"
#include "res://track/kerb_paint.gdshaderinc"

uniform sampler2D overlay_mask : filter_nearest, repeat_disable;
uniform sampler2D verge_blend_mask : filter_linear, repeat_disable;
uniform sampler2D road_mask : filter_linear, repeat_disable;
uniform vec2 road_mask_texel;
uniform vec4 sand_color : source_color;
uniform vec2 map_extent;
uniform vec4 road_color : source_color;
uniform vec4 asphalt_base_color : source_color;
uniform bool gravel = false;
uniform bool grass_shoulder = false;
uniform bool grass = false;
uniform bool kerb = false;
uniform bool asphalt_surface = false;
uniform bool edge_fringe = false;
uniform bool raised_road_edge = false;
uniform bool road_marking = false;
uniform bool winter_width_data = false;
uniform vec4 kerb_pale : source_color = vec4(0.87,0.867,0.827,1.0);
uniform vec4 grass_color : source_color;
varying vec3 world_position;
varying float bank_slope;
varying float winter_half_width;
varying vec4 desert_join;

void vertex() {
	bank_slope = 1.0-NORMAL.y;
	winter_half_width = COLOR.r*32.0;
	desert_join = COLOR;
	world_position = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}

// Filter only the decorative sand join; road/marking masks stay exact.
float sand_coverage(vec2 uv) {
	vec2 d = 0.65 / vec2(textureSize(verge_blend_mask,0));
	float value = texture(verge_blend_mask,uv).b * 4.0;
	value += 2.0*(texture(verge_blend_mask,uv+vec2(d.x,0.0)).b+texture(verge_blend_mask,uv-vec2(d.x,0.0)).b);
	value += 2.0*(texture(verge_blend_mask,uv+vec2(0.0,d.y)).b+texture(verge_blend_mask,uv-vec2(0.0,d.y)).b);
	value += texture(verge_blend_mask,uv+d).b+texture(verge_blend_mask,uv-d).b;
	value += texture(verge_blend_mask,uv+vec2(d.x,-d.y)).b+texture(verge_blend_mask,uv+vec2(-d.x,d.y)).b;
	float sand = value / 16.0;
	if (sand > 0.001 && sand < 0.999) {
		sand = 1.0-grass_fringe(mix(0.55,0.98,1.0-sand),world_position.xz);
	}
	return sand;
}

void fragment() {
	vec2 map_uv = (world_position.xz + map_extent) / (map_extent * 2.0);
	// Every painted cell wins over the procedural road, including asphalt
	// paint used to open a junction. Obstacles keep their native footprints.
	if (any(lessThan(map_uv, vec2(0.0))) || any(greaterThan(map_uv, vec2(1.0)))
			|| texture(overlay_mask, map_uv).r < 0.5) { discard; }
	// Keep-road protects the road mesh, not its grass skirt or gravel fringe.
	vec3 mask = texture(overlay_mask,map_uv).rgb;
	float loose_road = piece_materials && (asphalt_surface || road_marking) ? texture(road_mask,map_uv).g : 0.0;
	if (road_marking && loose_road > 0.5) { discard; }
	if ((grass || gravel) && mask.g < 0.5 && mask.b < 0.5) { discard; }
	float sand = 0.0;
	if (gravel || (grass && !winter_snow && !desert_dunes)) { sand = sand_coverage(map_uv); }
	float relief_weight = grass ? (1.0-sand) : 0.0;
	// Avoid shading a base that the fixed material role immediately replaces.
	if (asphalt_surface && icy_road && !edge_fringe) { ALBEDO = winter_wear_width(UV,world_position.xz,winter_width_data ? winter_half_width : 5.0); }
	else if (asphalt_surface && packed_sand) { ALBEDO = compacted_road(road_color.rgb,edge_fringe ? UV2 : UV); }
	else if (!(grass || gravel || kerb)) { ALBEDO = surface_detail(road_color.rgb, world_position.xz, asphalt_surface); }
	if (asphalt_surface && packed_sand && desert_join.a > 0.001) {
		float along = atan(desert_join.g*2.0-1.0,desert_join.r*2.0-1.0)*10.0/6.28318530718;
		vec2 other_uv = vec2(along,(desert_join.b-0.5)*32.0);
		ALBEDO = mix(ALBEDO,compacted_road(road_color.rgb,other_uv),desert_join.a);
	}
	if (asphalt_surface && !wet_road && !icy_road && !packed_sand) {
		ALBEDO = directional_asphalt(ALBEDO,world_position.xz,UV2);
	}
	float wet_coverage = wet_road && asphalt_surface ? 1.0 : 0.0;
	if (edge_fringe && !icy_road) {
		// UV.y spans the cosmetic blend strip (1.95 m for desert), so
		// curves never inherit the coarse canonical surface-grid staircase.
		float breakup = pigment(world_position.xz * (packed_sand ? 0.18 : 5.5) + vec2(4.1, 13.7));
		float cutoff = 0.84 + (breakup - 0.5) * 0.22;
		// Reuse the grass/sand shoulder's settled + broken fringe blend.
		// Remap it across a wider band, retaining texture through the transition.
		float asphalt_coverage = packed_sand ? 1.0-desert_bank_coverage(UV.y,world_position.xz) : 1.0 - smoothstep(cutoff - 0.30, cutoff + 0.20, UV.y);
		// Below the raised lip this is sand, with only sparse asphalt crumbs.
		if (raised_road_edge) asphalt_coverage = 0.08*(1.0-smoothstep(0.0,0.35,UV.y))*breakup;
		vec3 shoulder = packed_sand ? desert_shoulder(sand_color.rgb,world_position.xz) : sand_detail(sand_color.rgb, world_position.xz);
		ALBEDO = mix(shoulder, ALBEDO, asphalt_coverage);
		// Six-centimetre soft contact band, filtered with the existing strip UV.
		if (raised_road_edge) ALBEDO *= 1.0-0.18*(1.0-smoothstep(0.0,0.30,UV.y))*(0.75+0.25*breakup);
		wet_coverage *= asphalt_coverage;
	}
	if (raised_road_edge && !edge_fringe) ALBEDO *= desert_join.a;
	if (road_marking) {
		// Preserve a continuous readable line while breaking up its pigment
		// with mild fading and sparse asphalt-coloured chips.
		float fade = pigment(world_position.xz * 1.9 + vec2(27.0, 8.0)) * 0.12;
		float chip_noise = pigment(world_position.xz * 13.0 + vec2(5.0, 41.0));
		float chip_aa = max(fwidth(chip_noise) * 0.75, 0.025);
		float chips = smoothstep(0.66 - chip_aa, 0.78 + chip_aa, chip_noise) * 0.42;
		vec3 worn_asphalt = surface_detail(asphalt_base_color.rgb, world_position.xz, true);
		ALBEDO = mix(ALBEDO, worn_asphalt, fade + chips);
	}
	if (grass) {
		ALBEDO = painted_grass(road_color.rgb,world_position.xz);
		if (!winter_snow && !desert_dunes) ALBEDO = mix(ALBEDO,sand_detail(sand_color.rgb,world_position.xz),sand);
	}
	if (kerb) {
		// Fit complete equal blocks to each exposed run. An odd count starts
		// and ends white; no arbitrary half-red slivers at curve boundaries.
		float count = max(1.0,2.0*floor(UV.y/3.0)+1.0);
		float block_length = max(UV.y/count,0.001);
		float tip = smoothstep(0.0, min(block_length,1.8), min(UV.x,UV.y-UV.x));
		if (UV2.x > mix(0.12,1.0,tip)) { discard; }
		float phase = mod(UV.x+block_length,block_length*2.0);
		float aa = max(fwidth(UV.x),0.001);
		float pale = smoothstep(block_length-aa,block_length+aa,phase);
		if (UV.x < aa || UV.x > UV.y-aa) { pale = 1.0; }
		ALBEDO = racing_kerb_paint(mix(road_color.rgb,kerb_pale.rgb,pale),world_position.xz,UV.x,1.0);
	}
	if (gravel) {
		ALBEDO = packed_sand ? desert_shoulder(road_color.rgb,world_position.xz) : sand_detail(road_color.rgb,world_position.xz);
		if (packed_sand) {
			float contact = 1.0-smoothstep(0.10,0.32,UV.y);
			ALBEDO *= 1.0-contact*0.025;
		}
		float fringe;
		if (packed_sand) {
			float drift_edge = UV.y+(texture(surface_factors,world_position.xz/28.0).g-0.5)*0.24*4.0*UV.y*(1.0-UV.y);
			fringe = smoothstep(0.58,1.0,drift_edge)*(1.0-sand);
		} else { fringe = (hybrid_grass ? shoulder_fringe(UV.y,world_position.xz) : grass_fringe(UV.y,world_position.xz))*(1.0-sand); }
		ALBEDO = mix(ALBEDO,painted_grass(grass_color.rgb,world_position.xz),fringe);
		relief_weight = fringe;
		if (grass_shoulder) {
			// Real sloped sand replaces the old lower, flat contact strip.
			vec2 grit_uv = world_position.xz/2.0;
			vec3 grit = texture(desert_apron,grit_uv).rgb-texture(desert_apron,grit_uv,4.0).rgb;
			ALBEDO = max(ALBEDO+grit*0.28*(1.0-fringe),vec3(0.0));
			float profile_across = clamp((0.027-world_position.y)/0.065,0.0,1.0);
			ALBEDO *= 1.0-0.16*(1.0-smoothstep(0.0,0.16,profile_across));
			if (UV.x < -0.5) { ALBEDO = desert_join.rgb; relief_weight = 0.0; }
		}
	}
	if (loose_road > 0.0 && asphalt_surface) {
		float coverage = edge_fringe ? 1.0-smoothstep(0.3,1.0,UV.y) : 1.0;
		vec3 stone = road_gravel_color(sand_color.rgb,world_position.xz);
		if (raised_road_edge && !edge_fringe) { stone *= desert_join.a; }
		ALBEDO = mix(ALBEDO,stone,loose_road*coverage);
		wet_coverage *= 1.0-loose_road;
	}
	ROUGHNESS = 1.0;
 SPECULAR = 0.0;
 if (icy_road && asphalt_surface && !edge_fringe) {
  vec2 road_uv = winter_road_uv(UV);
  vec4 finish = texture(ice_finish,road_uv);
  float frost = winter_edge_frost(UV,world_position.xz,winter_width_data ? winter_half_width : 5.0);
  vec2 ice_response = winter_reflective_finish(finish,frost);
  ROUGHNESS = ice_response.x;
  SPECULAR = ice_response.y;
  NORMAL = winter_road_ice_normal(finish.rg,NORMAL,VIEW_MATRIX,world_position.xz,road_uv);
  RADIANCE = winter_seam_radiance(NORMAL,VIEW,INV_VIEW_MATRIX,winter_seam_weight(finish,frost));
 }
 if (wet_road && wet_coverage > 0.0) {
  ROUGHNESS = mix(1.0,wet_road_roughness(world_position.xz),wet_coverage);
  SPECULAR = wet_road_specular(world_position.xz)*wet_coverage;
 }
 if (wet_road && (road_marking || kerb)) {
  ALBEDO *= 0.90;
  ROUGHNESS = kerb ? 0.30 : 0.24;
  SPECULAR = 0.5;
 }
	bool verge_detail = grass_shoulder && UV.x < -0.5;
	NORMAL = grass_relief(world_position.xz,NORMAL,VIEW_MATRIX,verge_detail ? 0.0 : relief_weight);
	NORMAL = sand_relief(world_position.xz,NORMAL,VIEW_MATRIX,verge_detail ? 0.0 : (grass || gravel) ? (1.0-relief_weight)*(grass_shoulder ? 0.25 : 1.0) : 0.0);
	if (loose_road > 0.0 && asphalt_surface) NORMAL = sand_relief(world_position.xz,NORMAL,VIEW_MATRIX,loose_road*0.6);
	NORMAL = winter_snow_relief(world_position.xz,NORMAL,VIEW_MATRIX,(grass || gravel) ? 1.0 : 0.0);
	// Cosmetic skirts/loose sand carry dunes; the firm timed road stays smooth.
	NORMAL = dune_relief(world_position.xz,NORMAL,VIEW_MATRIX,grass ? 1.0 : (gravel ? smoothstep(0.6,1.0,UV.y)*(1.0-sand) : 0.0));
 if (desert_dunes && (grass || gravel)) {
  vec3 mineral = texture(surface_factors,world_position.xz/24.0,0.65).rgb;
  float footprint = length(fwidth(world_position.xz));
  vec2 finish = mineral_sun_finish(mineral,footprint,1.0);
  ROUGHNESS = finish.x;
  SPECULAR = finish.y;
  if (grass) NORMAL = mineral_terrain_normal(mineral,footprint,1.0,NORMAL,VIEW_MATRIX);
 }
 if (wet_road) NORMAL = wet_road_relief(world_position.xz,NORMAL,VIEW_MATRIX,wet_coverage);
	if (winter_snow && !kerb && !road_marking) {
		float powder = winter_ground_powder(world_position.xz,asphalt_surface ? 1.0 : 0.22);
		ALBEDO = mix(ALBEDO,vec3(0.92,0.945,0.97),powder);
		ROUGHNESS = mix(ROUGHNESS,1.0,powder);
		SPECULAR *= 1.0-powder;
		NORMAL = normalize(mix(NORMAL,(VIEW_MATRIX*vec4(0.0,1.0,0.0,0.0)).xyz,powder));
		RADIANCE *= 1.0-powder;
	}
}
