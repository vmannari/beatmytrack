class_name PropWinterCraft
extends RefCounted
## Original snow construction, dressed snowman and hollow candle lanterns.
const KINDS: Array[String] = ["igloo","snowman","snow_castle","snow_lantern","ice_lantern","ice_compact"]
const BREAKABLE: Array[String] = ["snowman","snow_lantern","ice_lantern"]
const SNOW := Color(0.83,0.90,0.94,0.0)
const SHADE := Color(0.63,0.75,0.82,0.0)
const ICE := Color(0.60,0.81,0.88,0.45)
const COAL := Color(0.075,0.105,0.12,0.0)
const SCARF := Color(0.52,0.16,0.13,0.0)
static var surfaces: Dictionary = {}

static func material(ice: bool = false) -> ShaderMaterial:
	if not surfaces.has(ice):
		var result:=ShaderMaterial.new()
		result.shader=preload("res://track/winter_craft_ice.gdshader") if ice else preload("res://track/winter_craft_snow.gdshader")
		if not ice: result.set_shader_parameter("castle_snow",preload("res://assets/textures/winter_snow_v1.png"))
		surfaces[ice]=result
	return surfaces[ice]

static func append(tool: SurfaceTool, kind: String, center: Vector3, scale: float, turn: float) -> bool:
	if kind not in KINDS: return false
	var local:=SurfaceTool.new(); local.begin(Mesh.PRIMITIVE_TRIANGLES)
	match kind:
		"igloo": _igloo(local)
		"snowman": _snowman(local)
		"snow_castle": _castle(local)
		"snow_lantern": _snow_lantern(local)
		"ice_lantern": _ice_lantern(local)
		"ice_compact": preload("res://track/prop_ice_compact.gd").append(local)
	PropGeometry.append_transformed(tool,local,center,scale,turn)
	return true

static func _smooth(tool: SurfaceTool, points: Array, color: Color, normal: Vector3, group: int = 0) -> void:
	tool.set_color(color); tool.set_smooth_group(group)
	var flip: bool=(points[1]-points[0]).cross(points[2]-points[0]).dot(normal)<0.0
	for i: int in range(1,points.size()-1):
		for j: int in ([0,i,i+1] if flip else [0,i+1,i]): tool.add_vertex(points[j])

static func ball(tool: SurfaceTool, p: Vector3, radius: Vector3, color: Color, segments: int = 24, rows: int = 10, worn: bool = true) -> void:
	var rings: Array=[]
	for row: int in range(1,rows):
		var ring: Array[Vector3]=[]
		var latitude: float=-PI*0.5+PI*row/rows
		for i: int in range(segments):
			var a: float=TAU*i/segments
			var wear: float=1.0+(0.018*sin(a*5.0+latitude*3.0)+0.009*cos(a*7.0-latitude*5.0) if worn else 0.0)
			ring.append(p+Vector3(cos(a)*cos(latitude),sin(latitude),sin(a)*cos(latitude))*radius*wear)
		rings.append(ring)
	for row: int in range(rings.size()-1):
		for i: int in range(segments):
			var j: int=(i+1)%segments
			var normal: Vector3=(rings[row][i]+rings[row+1][j])*0.5-p
			_smooth(tool,[rings[row][i],rings[row][j],rings[row+1][j],rings[row+1][i]],color,normal)
	for i: int in range(segments):
		var j: int=(i+1)%segments
		_smooth(tool,[rings[0][j],rings[0][i],p-Vector3(0,radius.y,0)],color,Vector3.DOWN)
		_smooth(tool,[rings[-1][i],rings[-1][j],p+Vector3(0,radius.y,0)],color,Vector3.UP)

static func _lathe(tool: SurfaceTool, profile: Array, color: Color, segments: int = 32, center: Vector3 = Vector3.ZERO) -> void:
	for row: int in range(profile.size()-1):
		var lo: Vector2=profile[row]; var hi: Vector2=profile[row+1]
		for i: int in range(segments):
			var a: float=TAU*i/segments; var b: float=TAU*(i+1)/segments
			var points: Array=[center+Vector3(cos(a)*lo.x,lo.y,sin(a)*lo.x),center+Vector3(cos(b)*lo.x,lo.y,sin(b)*lo.x),center+Vector3(cos(b)*hi.x,hi.y,sin(b)*hi.x),center+Vector3(cos(a)*hi.x,hi.y,sin(a)*hi.x)]
			var normal:=Vector3(cos((a+b)*0.5),0,sin((a+b)*0.5))
			if hi.y<lo.y: normal=-normal
			if is_equal_approx(lo.y,hi.y): normal=Vector3.UP if hi.x<lo.x else Vector3.DOWN
			_smooth(tool,points,color,normal,1)

static func _dome_point(a: float, e: float, radius: float) -> Vector3:
	return Vector3(sin(a)*cos(e),sin(e)*(2.93/3.12),-cos(a)*cos(e))*radius

static func _snow_face(tool: SurfaceTool, points: Array, color: Color, normal: Vector3, group: int = -1) -> void:
	# Trimmed arch patches can end in a triangle. Never emit zero-area fans.
	color.a = 0.22 # Packed architectural snow; candle/material tags stay separate.
	for i: int in range(1,points.size()-1):
		if (points[i]-points[0]).cross(points[i+1]-points[0]).length_squared() > 1e-16:
			_smooth(tool,[points[0],points[i],points[i+1]],color,normal,group)

static func _portal_latitude(a: float) -> float:
	if absf(wrapf(a,-PI,PI)) >= 0.285: return 0.0
	# Intersection of the spherical shell and the tunnel's inner barrel.
	# The tunnel overlaps this cut, so neither its roof nor the shell floats.
	var lo: float = 0.0; var hi: float = 0.52
	for iteration: int in range(12):
		var e: float = (lo+hi)*0.5
		var x: float = sin(a)*cos(e)*3.12
		var roof: float = 0.42+sqrt(maxf(0.0,0.87*0.87-x*x))
		if sin(e)*2.93 < roof: lo = e
		else: hi = e
	return hi

static func _dome_patch(tool: SurfaceTool, a0: float, a1: float, e0: float, e1: float, radius: float, color: Color, bevel: bool = false, inward: bool = false) -> void:
	var steps: Array = [0.0,0.09,0.91,1.0] if bevel else [0.0,1.0]
	var trimmed: bool = e0 < maxf(_portal_latitude(a0),maxf(_portal_latitude(a1),_portal_latitude((a0+a1)*0.5)))
	for i: int in range(steps.size()-1):
		for j: int in range(steps.size()-1):
			var points: Array[Vector3] = []
			for uv: Vector2 in [Vector2(steps[i],steps[j]),Vector2(steps[i+1],steps[j]),Vector2(steps[i+1],steps[j+1]),Vector2(steps[i],steps[j+1])]:
				var a: float = lerpf(a0,a1,uv.x)
				var e: float = maxf(lerpf(e0,e1,uv.y),_portal_latitude(a))
				e = minf(e,e1)
				var edge: float = maxf(absf(uv.x*2.0-1.0),absf(uv.y*2.0-1.0))
				var r: float = radius-(0.045*smoothstep(0.80,1.0,edge) if bevel else 0.0)
				points.append(_dome_point(a,e,r))
			var n: Vector3 = _dome_point((a0+a1)*0.5,(e0+e1)*0.5,1.0)
			_snow_face(tool,points,color,-n if inward else n,-1 if trimmed else 3 if inward else 2)

static func _igloo(tool: SurfaceTool) -> void:
	# Continuous seated joint bed and an actual hollow shell, with a fitted cut.
	for row: int in range(10):
		for i: int in range(48):
			var a: float = TAU*i/48-PI
			for inner: bool in [false,true]:
				_dome_patch(tool,a,a+TAU/48,row*PI/20,(row+1)*PI/20,2.87 if inner else 3.035,SHADE.darkened(0.20) if inner else SNOW.darkened(0.13),false,inner)
	# Running-bond, gently pillowed snow blocks. Seams have shallow blue beds,
	# never daylight cracks; the changing course count respects the dome taper.
	for row: int in range(9):
		var e0: float = row*PI/18+0.0018
		var e1: float = (row+1)*PI/18-0.0018
		var count: int = maxi(5,roundi(26.0*cos((e0+e1)*0.5)))
		for i: int in range(count):
			var a: float = TAU*(float(i)+(0.5 if row%2 else 0.0))/count-PI
			var color: Color = SNOW.darkened(0.018+0.012*sin(i*2.31+row*4.1))
			_dome_patch(tool,a+0.0015,a+TAU/count-0.0015,e0,e1,3.12+0.007*sin(i*3.1+row),color,true)
	# Three short courses of wedge-shaped tunnel blocks, with bevelled front
	# arrises and a continuous recessed soffit. All joints are physically seated.
	for course: int in range(3):
		for i: int in range(9):
			_arch_block(tool,Vector3(0,0.42,-4.12+course*0.60),PI*i/9+0.003,PI*(i+1)/9-0.003,0.80,1.105,0.61,SNOW.darkened(0.012*((i+course)%3)))
	for sign_value: float in [-1.0,1.0]:
		for course: int in range(3):
			_soft_brick(tool,Vector3(sign_value*0.954,0.20,-3.815+course*0.60),Vector3(0.305,0.43,0.61),SNOW,0.045)
	_soft_brick(tool,Vector3(0,-0.018,-2.0),Vector3(1.59,0.05,4.24),SHADE.darkened(0.14),0.015)
	# Wind-packed footing remains inside the original circular collision edge.
	for i: int in range(18):
		var a: float = 0.34+(TAU-0.68)*i/17
		ball(tool,Vector3(sin(a)*2.96,0.07,-cos(a)*2.96),Vector3(0.16,0.11,0.16),SNOW,8,4)
	ball(tool,Vector3(0,2.914,0),Vector3(0.23,0.036,0.23),SNOW,20,6)

static func _soft_brick(tool: SurfaceTool, center: Vector3, size: Vector3, color: Color, bevel: float = 0.045, turn: float = 0.0) -> void:
	# Four rectangular rings retain a broad, calm face and rounded snow arrises
	# with less than half the triangles of the general-purpose octagonal box.
	var half: Vector3 = size*0.5
	var b: float = minf(bevel,minf(half.x,minf(half.y,half.z))*0.65)
	var rings: Array = []
	for row: int in range(4):
		var inset: float = b if row in [0,3] else 0.0
		var y: float = [-half.y,-half.y+b,half.y-b,half.y][row]
		var ring: Array[Vector3] = []
		for q: Vector2 in [Vector2(-half.x+inset,-half.z+inset),Vector2(half.x-inset,-half.z+inset),Vector2(half.x-inset,half.z-inset),Vector2(-half.x+inset,half.z-inset)]:
			ring.append(center+Vector3(q.x,y,q.y).rotated(Vector3.UP,turn))
		rings.append(ring)
	for row: int in range(3):
		for i: int in range(4):
			var j: int = (i+1)%4
			var normal: Vector3 = (rings[row][i]+rings[row][j]+rings[row+1][j]+rings[row+1][i])*0.25-center
			_snow_face(tool,[rings[row][i],rings[row][j],rings[row+1][j],rings[row+1][i]],color.darkened(0.055 if row == 0 else 0.0),normal)
	_snow_face(tool,rings[3],color.lightened(0.025),Vector3.UP)
	_snow_face(tool,rings[0],color.darkened(0.12),Vector3.DOWN)

static func _arch_block(tool: SurfaceTool, origin: Vector3, a0: float, a1: float, inner: float, outer: float, depth: float, color: Color) -> void:
	# Closed annular voussoir with inset front/back bevels and curved crown.
	var rings: Array = []
	for row: int in range(4):
		var inset: float = 0.025 if row in [0,3] else 0.0
		var z: float = [0.0,0.035,depth-0.035,depth][row]
		var ring: Array[Vector3] = []
		for q: Vector2 in [Vector2(a0+inset/outer,outer-inset),Vector2((a0+a1)*0.5,outer-inset),Vector2(a1-inset/outer,outer-inset),Vector2(a1-inset/outer,inner+inset),Vector2((a0+a1)*0.5,inner+inset),Vector2(a0+inset/outer,inner+inset)]:
			ring.append(origin+Vector3(cos(q.x)*q.y,sin(q.x)*q.y,z))
		rings.append(ring)
	for row: int in range(3):
		for i: int in range(6):
			var j: int = (i+1)%6
			var n: Vector3 = Vector3(cos((a0+a1)*0.5),sin((a0+a1)*0.5),0)
			if i in [3,4]: n = -n
			elif i == 2: n = Vector3(-sin(a1),cos(a1),0)
			elif i == 5: n = Vector3(sin(a0),-cos(a0),0)
			_snow_face(tool,[rings[row][i],rings[row][j],rings[row+1][j],rings[row+1][i]],color.darkened(0.09 if i in [3,4] else 0.0),n)
	_snow_face(tool,rings[0],color,Vector3.FORWARD)
	_snow_face(tool,rings[3],color.darkened(0.04),Vector3.BACK)

static func _snowman(tool: SurfaceTool) -> void:
	ball(tool,Vector3(0,0.64,0),Vector3(0.75,0.70,0.68),SNOW)
	ball(tool,Vector3(0.035,1.46,0.015),Vector3(0.54,0.54,0.51),SNOW)
	ball(tool,Vector3(-0.015,2.13,0),Vector3(0.40,0.40,0.38),SNOW)
	# Attached pebbles follow the actual spherical face; a tapered carrot points out.
	for x: float in [-0.14,0.12]: ball(tool,Vector3(x,2.22,-0.345),Vector3(0.045,0.046,0.036),COAL,12,6,false)
	PropGeometry.tube(tool,Vector3(-0.01,2.13,-0.36),Vector3(-0.015,2.08,-0.76),0.075,0.008,Color(0.76,0.34,0.12,0),10)
	for i: int in range(5):
		var x: float=-0.16+i*0.074
		ball(tool,Vector3(x,2.01+0.13*pow(x/0.2,2),-0.35+absf(x)*0.18),Vector3.ONE*0.024,COAL,8,4,false)
	for y: float in [1.18,1.44,1.68]:
		var z: float=-sqrt(maxf(0.0,1.0-pow((y-1.46)/0.54,2)))*0.51+0.015
		ball(tool,Vector3(0.035,y,z-0.014),Vector3(0.046,0.048,0.026),COAL,10,5,false)
	# Wrapped cloth collar and two thickness-seated trailing scarf ends.
	_lathe(tool,[Vector2(0.34,1.82),Vector2(0.38,1.85),Vector2(0.36,1.95),Vector2(0.31,1.97)],SCARF)
	PropGeometry.box(tool,Vector3(0.17,1.61,-0.498),Vector3(0.18,0.54,0.033),SCARF,0.018)
	PropGeometry.box(tool,Vector3(-0.05,1.71,-0.49),Vector3(0.15,0.39,0.035),SCARF.lightened(0.04),0.018)
	for i: int in range(5): PropGeometry.box(tool,Vector3(0.10+i*0.033,1.32,-0.50),Vector3(0.015,0.07,0.022),SCARF,0.005)
	for sign_value: float in [-1.0,1.0]:
		var a:=Vector3(sign_value*0.43,1.56,0); var b:=Vector3(sign_value*1.29,1.93,0.06)
		PropGeometry.tube(tool,a,b,0.052,0.022,Color(0.30,0.24,0.18,0),8)
		PropGeometry.tube(tool,b-Vector3(sign_value*0.22,0.09,0),b+Vector3(sign_value*0.06,0.24,0.08),0.028,0.009,Color(0.35,0.28,0.20,0),7)
	# Rolled brim, tapered felt crown and a snow-dusted top.
	_lathe(tool,[Vector2(0.01,2.43),Vector2(0.47,2.43),Vector2(0.49,2.47),Vector2(0.46,2.51),Vector2(0.29,2.51),Vector2(0.27,2.91),Vector2(0.24,2.94),Vector2(0.001,2.94)],COAL)
	_lathe(tool,[Vector2(0.295,2.53),Vector2(0.292,2.60)],SCARF)
	ball(tool,Vector3(0.015,2.945,0.015),Vector3(0.245,0.035,0.24),SNOW,20,6)

static func _castle(tool: SurfaceTool) -> void:
	preload("res://track/prop_snow_castle.gd").append(tool)

static func _candle(tool: SurfaceTool) -> void:
	_lathe(tool,[Vector2(0.001,0.10),Vector2(0.18,0.10),Vector2(0.18,0.145),Vector2(0.135,0.16),Vector2(0.13,0.30),Vector2(0.001,0.30)],Color(0.81,0.72,0.53,0),20)
	PropGeometry.tube(tool,Vector3(0,0.29,0),Vector3(0,0.345,0),0.012,0.008,COAL,6)
	ball(tool,Vector3(0,0.38,0),Vector3(0.052,0.105,0.043),Color(1.0,0.55,0.16,1),14,8,false)
	ball(tool,Vector3(0,0.36,-0.016),Vector3(0.023,0.055,0.020),Color(1.0,0.86,0.51,1),10,6,false)

static func _snow_lantern(tool: SurfaceTool) -> void:
	for row: int in range(4):
		var count: int=[9,8,6,4][row]
		var reach: float=[0.64,0.52,0.35,0.17][row]
		for i: int in range(count):
			var a: float=TAU*i/count+(0.13 if row%2 else 0.0)
			if row<2 and absf(wrapf(a,-PI,PI))<0.38: continue
			ball(tool,Vector3(sin(a)*reach,0.19+row*0.30,-cos(a)*reach),Vector3(0.235,0.215,0.23),SNOW.lerp(Color(0.95,0.84,0.65,0),0.05 if row<2 else 0.0),16,8)
	_candle(tool)

static func _ice_lantern(tool: SurfaceTool) -> void:
	# Closed annular ice wall, thick rounded rim, visible hollow and real candle.
	_lathe(tool,[Vector2(0.001,0.02),Vector2(0.53,0.02),Vector2(0.58,0.07),Vector2(0.65,0.91),Vector2(0.63,1.01),Vector2(0.49,1.025),Vector2(0.455,0.94),Vector2(0.40,0.17),Vector2(0.001,0.17)],ICE,40)
	# Narrow trapped-air vertical seams remain inside the wall, not floating glass.
	for i: int in range(11):
		var a: float=i*2.39
		var radius: float=0.55+(i%3)*0.018
		PropGeometry.tube(tool,Vector3(cos(a)*radius,0.22,sin(a)*radius),Vector3(cos(a+0.025)*(radius+0.04),0.73+(i%3)*0.05,sin(a+0.025)*(radius+0.04)),0.006,0.002,Color(0.85,0.94,0.97,0.45),5)
	_candle(tool)
