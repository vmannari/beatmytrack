shader_type spatial;
render_mode diffuse_burley, cull_back;
uniform sampler2D castle_snow : source_color, filter_linear_mipmap_anisotropic, repeat_enable;
varying vec3 craft_position;
varying vec3 craft_normal;
void vertex() {
	craft_position=(MODEL_MATRIX*vec4(VERTEX,1.0)).xyz;
	craft_normal=normalize(MODEL_NORMAL_MATRIX*NORMAL);
}
void fragment() {
	vec3 pigment=COLOR.rgb;
	if (!OUTPUT_IS_SRGB) pigment=mix(pigment/12.92,pow((pigment+0.055)/1.055,vec3(2.4)),step(vec3(0.04045),pigment));
	float filter_width=length(fwidth(craft_position));
	float fine=1.0-smoothstep(0.008,0.05,filter_width);
	float grain=fract(sin(dot(floor(craft_position*160.0),vec3(19.1,73.7,31.3)))*43758.5453);
	ALBEDO=pigment*(1.0+(grain-0.5)*0.045*fine);
	ROUGHNESS=0.91; SPECULAR=0.20;
	if (COLOR.a>0.35 && COLOR.a<0.50) {
		// Thick carved ice stays in the original opaque draw: no sorted shells,
		// screen copy or extra light. Frosted cuts soften the polished edges.
		float rim=pow(1.0-clamp(dot(normalize(NORMAL),normalize(VIEW)),0.0,1.0),3.0);
		float frost=smoothstep(0.47,0.49,COLOR.a);
		float crystals=smoothstep(0.96,0.995,grain)*fine;
		ALBEDO=pigment*(0.90+rim*0.28+crystals*0.10);
		// Quiet trapped fracture planes distinguish carved ice from car paint.
		float plane=sin(dot(craft_position,vec3(2.7,1.9,1.3))+sin(craft_position.z*3.1+craft_position.y)*0.42);
		float aa=max(fwidth(plane),0.001);
		float fracture=1.0-smoothstep(0.003,0.018+aa,abs(plane));
		ALBEDO=mix(ALBEDO,pigment*1.42,fracture*0.42*(1.0-frost));
		ROUGHNESS=mix(0.16,0.52,frost); SPECULAR=0.65;
		RIM=0.28; RIM_TINT=0.15;
	}
	if (COLOR.a>0.15 && COLOR.a<0.30) {
		// Opaque packed snow: subdued broad compression and filtered crystals.
		// The tag belongs only to architecture; snowmen and candles retain theirs.
		float packing=sin(craft_position.x*13.7+sin(craft_position.z*8.3))*sin(craft_position.y*17.1+craft_position.z*11.9);
		ALBEDO*=1.0+packing*0.018;
		vec3 n=normalize(craft_normal);
		vec3 crystals=sin(craft_position.yzx*151.0+cos(craft_position.zxy*117.0));
		crystals-=n*dot(crystals,n);
		NORMAL=normalize(NORMAL+(VIEW_MATRIX*vec4(crystals,0.0)).xyz*0.055*fine);
		ROUGHNESS=0.94; SPECULAR=0.16;
	}
	if (COLOR.a>0.5 && COLOR.a<0.7) {
		// The castle uses the world's original snow artwork and bank value range.
		// Triplanar projection keeps the carved walls and rounded crests coherent.
		vec3 n=normalize(craft_normal);
		vec3 weights=pow(abs(n),vec3(4.0));
		weights/=max(dot(weights,vec3(1.0)),0.0001);
		vec3 snow=texture(castle_snow,craft_position.zy/11.0).rgb*weights.x
			+texture(castle_snow,craft_position.xz/11.0).rgb*weights.y
			+texture(castle_snow,craft_position.xy/11.0).rgb*weights.z;
		vec3 original=snow*0.82;
		float blue=smoothstep(0.015,0.15,original.b-original.r);
		vec3 artwork=mix(original,vec3(original.b*0.98,original.b,original.b*1.01),blue*0.42);
		float detail=dot(artwork,vec3(0.2126,0.7152,0.0722));
		ALBEDO=vec3(clamp(detail*1.06+0.09,0.0,0.82))*COLOR.rgb;
		// Filtered relief follows the same artwork; it adds no silhouette noise.
		vec3 px=dFdx(craft_position); vec3 py=dFdy(craft_position);
		vec3 rx=cross(py,n); vec3 ry=cross(n,px);
		float determinant=dot(px,rx);
		if (abs(determinant)>0.000001) {
			vec3 gradient=(rx*dFdx(detail)+ry*dFdy(detail))/determinant;
			NORMAL=normalize((VIEW_MATRIX*vec4(normalize(n-gradient*0.10),0.0)).xyz);
		}
		ROUGHNESS=1.0; SPECULAR=0.08;
	}
	if (COLOR.a>0.9) { EMISSION=pigment*2.2; ROUGHNESS=1.0; }
}
