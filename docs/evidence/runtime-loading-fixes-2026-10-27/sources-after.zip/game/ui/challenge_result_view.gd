extends VBoxContainer
## Presentation of server-owned results. This run and the best standing stay distinct.
signal race_requested
signal share_requested
signal rematch_requested
signal cancel_requested
signal back_requested
signal stage_requested(index: int)

var snapshot: Dictionary = {}
var outcome: Dictionary = {}
var result_state: String = ""
var selected_stage: int = 0
var busy: bool = false
var signed_in: bool = false
var _layout: BoxContainer
var _summary: VBoxContainer
var _board: VBoxContainer
var _clock: Label
var _received_at: int

class TrackArtwork extends Control:
	var artwork: Texture2D
	var points := PackedVector2Array()
	func _ready() -> void:
		mouse_filter = Control.MOUSE_FILTER_IGNORE
		clip_contents = true
		resized.connect(queue_redraw)
	func _draw() -> void:
		if artwork != null:
			var factor: float = maxf(size.x/artwork.get_width(),size.y/artwork.get_height())
			var crop: Vector2 = size/factor
			draw_texture_rect_region(artwork,Rect2(Vector2.ZERO,size),Rect2((artwork.get_size()-crop)*0.5,crop))
		# The title has its own solid backing; keep the scenic image readable.
		draw_rect(Rect2(Vector2.ZERO,size),Color("07151b26"))
		if points.size() < 2: return
		var bounds := Rect2(points[0],Vector2.ZERO)
		for point: Vector2 in points: bounds = bounds.expand(point)
		var area := Rect2(Vector2(size.x*0.43,18),Vector2(size.x*0.51,size.y-36))
		var scale: float = minf(area.size.x/maxf(bounds.size.x,0.1),area.size.y/maxf(bounds.size.y,0.1))
		var origin: Vector2 = area.position+(area.size-bounds.size*scale)*0.5
		var route := PackedVector2Array()
		for point: Vector2 in points: route.append(origin+(point-bounds.position)*scale)
		if route[0].distance_to(route[-1]) > 0.01: route.append(route[0])
		draw_polyline(route,Color("07151bba"),8,true)
		draw_polyline(route,MenuStyle.TEXT,3,true)
		for x: int in range(4):
			for y: int in range(3):
				draw_rect(Rect2(route[0]+Vector2(x*3-6,y*3-4.5),Vector2(3,3)),MenuStyle.TEXT if (x+y)%2 == 0 else MenuStyle.INK)

func _ready() -> void:
	name = "ChallengeDetail"
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_theme_constant_override("separation",14)
	_received_at = Time.get_ticks_msec()
	var scroll := ScrollContainer.new()
	scroll.name = "ChallengeResultContentScroll"
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(scroll)
	_layout = BoxContainer.new()
	_layout.name = "ChallengeResultColumns"
	_layout.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_layout.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_layout.add_theme_constant_override("separation",18)
	scroll.add_child(_layout)
	_summary = VBoxContainer.new()
	_summary.name = "ChallengeResultSummary"
	_summary.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_summary.size_flags_stretch_ratio = 0.38
	_summary.add_theme_constant_override("separation",12)
	_layout.add_child(_summary)
	_track_summary()
	_personal_result()
	_board = _panel(_layout,"ChallengeResultBoard",20)
	_board.get_parent().size_flags_stretch_ratio = 0.62
	_standings()
	_rewards()
	_actions()
	resized.connect(_resize_layout)
	_resize_layout()
	var timer := Timer.new()
	timer.wait_time = 1.0
	timer.autostart = true
	timer.timeout.connect(_update_clock)
	add_child(timer)
	_update_clock()

func _series() -> bool:
	return ChallengesClient.is_series(snapshot)

func _stage() -> Dictionary:
	return snapshot.stages[clampi(selected_stage,0,snapshot.stages.size()-1)] if _series() else snapshot

func _own() -> Dictionary:
	for row: Dictionary in snapshot.get("standings",[]):
		if str(row.id) == str(snapshot.get("self_id","")): return row
	return {}

func _target() -> Variant:
	if snapshot.mode == "beat" and not _series(): return snapshot.get("target_ms")
	for row: Dictionary in snapshot.get("standings",[]):
		if row.get("ms") != null: return row.ms
	return null

func _track_summary() -> void:
	var shell := PanelContainer.new()
	shell.name = "ChallengeTrackPreview"
	shell.clip_contents = true
	shell.add_theme_stylebox_override("panel",MenuStyle.box(Color("10232f"),0))
	_summary.add_child(shell)
	var contents := VBoxContainer.new()
	contents.add_theme_constant_override("separation",0)
	shell.add_child(contents)
	var art := TrackArtwork.new()
	art.name = "ChallengeRoute"
	art.custom_minimum_size.y = 154
	art.artwork = TrackTile.scenery_texture(str(_stage().entry.get("theme","pine")))
	for point: Array in _stage().entry.points: art.points.append(Vector2(point[0],-point[1]))
	contents.add_child(art)
	var inset := MarginContainer.new()
	inset.add_theme_constant_override("margin_left",16)
	inset.add_theme_constant_override("margin_right",16)
	inset.add_theme_constant_override("margin_top",12)
	inset.add_theme_constant_override("margin_bottom",14)
	contents.add_child(inset)
	var copy := VBoxContainer.new()
	copy.add_theme_constant_override("separation",4)
	inset.add_child(copy)
	_label(copy,"CUSTOM CHALLENGE" if _series() and snapshot.mode != "3x3" else "3×3 SERIES" if _series() else "TIME ATTACK" if snapshot.mode == "beat" else "GROUP RACE",13,MenuStyle.ACCENT)
	var title := _label(copy,str(_stage().entry.name),30)
	title.name = "ChallengeResultTrackName"
	title.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	var creator := _label(copy,"by "+str(snapshot.creator),15,MenuStyle.MUTED)
	creator.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	var facts := _label(copy,"5 laps  ·  "+VehicleCatalog.title(str(snapshot.vehicle_id)),16,MenuStyle.MUTED)
	facts.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	if _series():
		var stages := HFlowContainer.new()
		stages.add_theme_constant_override("h_separation",6)
		copy.add_child(stages)
		for stage: Dictionary in snapshot.stages:
			var index: int = int(stage.index)
			var button := MenuStyle.tab("Track "+str(index+1),func() -> void: stage_requested.emit(index),index == selected_stage)
			button.name = "ChallengeStage_"+str(index)
			button.custom_minimum_size = Vector2(76,52)
			button.add_theme_font_size_override("font_size",18)
			button.tooltip_text = str(stage.entry.name)
			button.disabled = busy
			stages.add_child(button)

func _personal_result() -> void:
	var own: Dictionary = _own()
	var verified: bool = result_state in ["verified","skipped"] and bool(outcome.get("counted",false))
	var rejected: bool = result_state in ["verified","skipped","rejected","expired"] and not verified
	var panel := _panel(_summary,"ChallengePersonalResult",18)
	panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var status := HBoxContainer.new()
	panel.add_child(status)
	var icon := TextureRect.new()
	icon.texture = MenuIcon.texture("check" if verified else "close" if rejected else "resume")
	icon.custom_minimum_size = Vector2(20,20)
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon.modulate = MenuStyle.POSITIVE if verified else MenuStyle.MUTED
	status.add_child(icon)
	var feedback: String = "Race completed" if result_state == "skipped" and verified else "Target beaten" if verified and outcome.get("beaten",false) and snapshot.mode == "beat" else "Time verified" if verified else "Not counted" if rejected else "Verifying"
	if verified and outcome.get("gap_ms") != null: feedback += GameText.message("  %+.3f s") % (float(outcome.gap_ms)/1000.0)
	var status_label := _label(status,feedback,17,MenuStyle.POSITIVE if verified else MenuStyle.MUTED)
	status_label.name = "ChallengeResultFeedback"
	status_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	var this_run: bool = verified and outcome.get("ms") != null
	var value: Variant = outcome.ms if this_run else own.get("ms")
	_label(panel,("THIS RUN · TRACK "+str(int(outcome.stage_index)+1) if _series() and outcome.has("stage_index") else "THIS RUN") if this_run else "YOUR COMBINED BEST" if _series() else "YOUR BEST",13,MenuStyle.MUTED)
	var time := _label(panel,MenuStyle.time_text(float(value)/1000.0) if value != null else "—",64)
	time.name = "ChallengeResultTime"
	var position := HBoxContainer.new()
	panel.add_child(position)
	var rank := _label(position,"#%02d" % int(own.rank) if own.get("rank") != null else "—",32,MenuStyle.ACCENT)
	rank.name = "ChallengeResultRank"
	var caption := _label(position,"CURRENT POSITION" if own.get("rank") != null else GameText.message("%d / %d tracks complete") % [int(own.get("completed_tracks",0)),snapshot.stages.size()] if _series() else "No ranked time yet",13,MenuStyle.MUTED)
	caption.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	caption.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	caption.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	if this_run and own.get("ms") != null and (_series() or int(own.ms) != int(outcome.ms)):
		_label(panel,("Combined best  " if _series() else "Your best  ")+MenuStyle.time_text(float(own.ms)/1000.0),16,MenuStyle.MUTED)
	if not verified:
		var help := _label(panel,"This run did not enter the standings." if rejected else "Your result is being checked. Standings show verified best times.",15,MenuStyle.MUTED)
		help.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART

func _standings() -> void:
	var top := HBoxContainer.new()
	_board.add_child(top)
	var title := _label(top,"STANDINGS",26)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_clock = _label(top,"",15,MenuStyle.MUTED)
	var target := HBoxContainer.new()
	target.add_theme_constant_override("separation",16)
	_board.add_child(target)
	var timing := VBoxContainer.new()
	timing.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	timing.add_theme_constant_override("separation",2)
	target.add_child(timing)
	_label(timing,"TARGET TIME" if snapshot.mode == "beat" and not _series() else "LEADING TOTAL" if _series() else "LEADING TIME",13,MenuStyle.MUTED)
	var value: Variant = _target()
	var time := _label(timing,MenuStyle.time_text(float(value)/1000.0) if value != null else "—",38,MenuStyle.ACCENT)
	time.name = "ChallengeTargetTime"
	var own: Dictionary = _own()
	if own.get("ms") != null and value != null:
		var difference: int = int(own.ms)-int(value)
		var tied: bool = snapshot.mode != "beat" and snapshot.standings.any(func(row: Dictionary) -> bool: return str(row.id) != str(own.id) and row.get("ms") != null and int(row.ms) == int(own.ms))
		var gap := _label(target,"Target beaten" if difference < 0 else "Tied with target" if difference == 0 and snapshot.mode == "beat" else "Joint lead" if difference == 0 and tied else "You lead" if difference == 0 else GameText.message("+%.3f s to lead") % (float(difference)/1000.0),17,MenuStyle.POSITIVE if difference < 0 or difference == 0 and snapshot.mode != "beat" else MenuStyle.MUTED)
		gap.name = "ChallengePersonalGap"
		gap.custom_minimum_size.x = 130
		gap.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		gap.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_board.add_child(HSeparator.new())
	var header_inset := MarginContainer.new()
	header_inset.add_theme_constant_override("margin_left",10)
	header_inset.add_theme_constant_override("margin_right",10)
	_board.add_child(header_inset)
	var header := HBoxContainer.new()
	header.name = "ChallengeStandingsHeader"
	header_inset.add_child(header)
	_row(header,"#","DRIVER","TOTAL" if _series() else "BEST TIME","GAP (s)",true)
	var scroll := ScrollContainer.new()
	scroll.name = "ChallengeStandingsScroll"
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.custom_minimum_size.y = 164
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_board.add_child(scroll)
	var align_header: Callable = _align_standings_header.bind(weakref(header_inset),weakref(scroll))
	scroll.get_v_scroll_bar().visibility_changed.connect(align_header)
	align_header.call_deferred()
	var table := VBoxContainer.new()
	table.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	table.add_theme_constant_override("separation",6)
	scroll.add_child(table)
	for driver: Dictionary in snapshot.get("standings",[]):
		var player: bool = str(driver.id) == str(snapshot.self_id)
		var card := PanelContainer.new()
		card.name = "ChallengeDriver_"+str(driver.id)
		card.custom_minimum_size.y = 52
		card.add_theme_stylebox_override("panel",MenuStyle.box(MenuStyle.ACCENT if player else Color("152c3a"),10))
		table.add_child(card)
		var values := HBoxContainer.new()
		card.add_child(values)
		var gap: String = "—"
		if driver.get("ms") != null and value != null:
			var delta: int = int(driver.ms)-int(value)
			gap = "—" if delta == 0 else "%+.3f" % (float(delta)/1000.0)
		var time_text: String = MenuStyle.time_text(float(driver.ms)/1000.0) if driver.get("ms") != null else GameText.message("%d/%d tracks") % [int(driver.get("completed_tracks",0)),snapshot.stages.size()] if _series() else "—"
		_row(values,str(int(driver.rank)) if driver.get("rank") != null else "—",str(driver.name),time_text,gap,false,player)
	if snapshot.standings.size() <= 1 and snapshot.state == "active":
		var waiting := VBoxContainer.new()
		waiting.name = "ChallengeResultInvitation"
		waiting.add_theme_constant_override("separation",4)
		table.add_child(waiting)
		var heading := _label(waiting,"Waiting for challengers",23,MenuStyle.MUTED)
		heading.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		var help := _label(waiting,"Share this challenge to invite another driver.",15,MenuStyle.MUTED)
		help.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	var facts := HBoxContainer.new()
	_board.add_child(facts)
	var drivers := _label(facts,GameText.message("%d / %d drivers") % [snapshot.standings.size(),int(snapshot.get("capacity",2 if snapshot.mode == "beat" else 20))],15,MenuStyle.MUTED)
	drivers.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var remaining: Variant = _stage().get("attempts_remaining")
	var tries := _label(facts,"Unlimited tries" if remaining == null else "No tries remaining" if int(remaining) <= 0 else str(int(remaining))+" tries remaining",15,MenuStyle.MUTED)
	tries.name = "ChallengeResultTries"

func _row(parent: HBoxContainer, rank: String, driver: String, time: String, gap: String, header: bool = false, player: bool = false) -> void:
	parent.add_theme_constant_override("separation",8)
	for index: int in range(4):
		var label := _label(parent,[rank,driver,time,gap][index],13 if header else 18,MenuStyle.INK if player else MenuStyle.MUTED if header else MenuStyle.TEXT)
		label.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		if index == 1: label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		else:
			label.custom_minimum_size.x = [28,0,102,70][index]
			if index > 1: label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT

func _rewards() -> void:
	var rewards: Dictionary = snapshot.get("rewards",{})
	if rewards.is_empty(): return
	if snapshot.mode == "beat" and str(snapshot.creator_id) == str(snapshot.self_id): return
	var panel := _panel(_board,"ChallengeRewardProgress",12)
	panel.get_parent().size_flags_vertical = Control.SIZE_SHRINK_END
	var heading := HBoxContainer.new()
	panel.add_child(heading)
	var title := _label(heading,"CHALLENGE REWARDS",13,MenuStyle.MUTED)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var all_earned: bool = rewards.get("finish_earned",false) and rewards.get("goal_earned",false)
	_label(heading,"Earned" if all_earned else "Sign in to earn" if not signed_in else "Ended" if snapshot.state != "active" else "Daily limit reached" if not rewards.get("eligible",false) else "",14,MenuStyle.POSITIVE if all_earned else MenuStyle.MUTED)
	for index: int in range(2):
		var earned: bool = bool(rewards.get("finish_earned" if index == 0 else "goal_earned",false))
		var row := HBoxContainer.new()
		panel.add_child(row)
		var goal := _label(row,("✓  " if earned else "•  ")+("Finish five laps" if index == 0 else "Beat the target" if snapshot.mode == "beat" else "Outrun a rival & lead"),15,MenuStyle.POSITIVE if earned else MenuStyle.MUTED)
		goal.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		goal.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		_label(row,"Earned" if earned else "Ended" if snapshot.state != "active" else "Daily limit" if signed_in and not rewards.get("eligible",false) else GameText.message("+%d Coins") % int(rewards.get("finish" if index == 0 else "goal",0)),16,MenuStyle.POSITIVE if earned else MenuStyle.ACCENT)

func _align_standings_header(header_reference: WeakRef, scroll_reference: WeakRef) -> void:
	# Verification can replace this entire view before the deferred layout runs.
	var header: MarginContainer = header_reference.get_ref()
	var scroll: ScrollContainer = scroll_reference.get_ref()
	if not is_instance_valid(header) or not is_instance_valid(scroll): return
	if not header.is_inside_tree() or header.is_queued_for_deletion() or scroll.is_queued_for_deletion(): return
	var bar: VScrollBar = scroll.get_v_scroll_bar()
	header.add_theme_constant_override("margin_right",10+(ceili(bar.size.x) if bar.visible else 0))

func _actions() -> void:
	var actions := HFlowContainer.new()
	actions.name = "ChallengeActions"
	actions.alignment = FlowContainer.ALIGNMENT_END
	actions.add_theme_constant_override("h_separation",8)
	actions.add_theme_constant_override("v_separation",8)
	add_child(actions)
	var share := _button(actions,"Share",func() -> void: share_requested.emit())
	share.icon = MenuIcon.texture("share")
	var own: Dictionary = _own()
	var winning: bool = own.get("ticks") != null and (int(own.rank) == 1 if snapshot.mode != "beat" or _series() else int(own.ticks) < int(snapshot.target_ticks))
	if winning and not _series(): _button(actions,"Rematch",func() -> void: rematch_requested.emit())
	if str(snapshot.creator_id) == str(snapshot.self_id) and snapshot.state == "active":
		var cancel := _button(actions,"",func() -> void: cancel_requested.emit())
		cancel.icon = MenuIcon.texture("close")
		cancel.tooltip_text = "Cancel challenge"
		cancel.custom_minimum_size.x = 52
	var exhausted: bool = _stage().get("attempts_remaining") != null and int(_stage().attempts_remaining) <= 0
	var creator: bool = snapshot.mode == "beat" and not _series() and str(snapshot.creator_id) == str(snapshot.self_id)
	var unavailable: bool = exhausted or snapshot.state != "active" or creator
	_button(actions,"Back to Challenges",func() -> void: back_requested.emit(),unavailable).name = "ChallengeResultsBack"
	var race := _button(actions,"No tries remaining" if exhausted else "Challenge ended" if snapshot.state != "active" else "Waiting for opponent" if creator else "Race again",func() -> void: race_requested.emit(),not unavailable)
	race.name = "ChallengeRace"
	race.disabled = busy or unavailable

func _update_clock() -> void:
	if _clock == null: return
	var remaining: int = maxi(0,int(snapshot.ends_at)-int(snapshot.server_now)-(Time.get_ticks_msec()-_received_at)/1000)
	_clock.text = str(snapshot.state).capitalize() if snapshot.state != "active" else "Ending" if remaining == 0 else GameText.message("%dd %02dh left") % [remaining/86400,(remaining%86400)/3600] if remaining >= 86400 else GameText.message("%02dh %02dm left") % [remaining/3600,(remaining%3600)/60]

func _resize_layout() -> void:
	if _layout == null: return
	var narrow: bool = size.x < 760
	var compact: bool = not narrow and size.y < 560
	_layout.vertical = narrow
	_summary.custom_minimum_size.x = 0 if narrow else 290
	_board.get_parent().custom_minimum_size.x = 0 if narrow else 400
	# A short landscape viewport should reveal the result before the scenery.
	var personal: Control = _summary.get_node("ChallengePersonalResultPanel")
	_summary.move_child(personal,0 if compact else 1)
	personal.size_flags_vertical = Control.SIZE_SHRINK_BEGIN if compact else Control.SIZE_EXPAND_FILL
	(_summary.find_child("ChallengeRoute",true,false) as Control).custom_minimum_size.y = 80 if compact else 120 if _series() else 154
	(_summary.find_child("ChallengeResultTime",true,false) as Label).add_theme_font_size_override("font_size",56 if compact else 64)
	(_board.find_child("ChallengeStandingsScroll",true,false) as Control).custom_minimum_size.y = 100 if compact else 164

func _panel(parent: Control, identity: String, padding: int) -> VBoxContainer:
	var panel := PanelContainer.new()
	panel.name = identity+"Panel"
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var style := MenuStyle.box(Color("0b1c27f5"),padding)
	style.border_color = Color("2b4352")
	style.set_border_width_all(1)
	panel.add_theme_stylebox_override("panel",style)
	parent.add_child(panel)
	var column := VBoxContainer.new()
	column.name = identity
	column.add_theme_constant_override("separation",10)
	panel.add_child(column)
	return column

func _label(parent: Node, text: String, font_size: int, color: Color = MenuStyle.TEXT) -> Label:
	var label := MenuStyle.label(text,font_size)
	label.add_theme_color_override("font_color",color)
	parent.add_child(label)
	return label

func _button(parent: Node, text: String, action: Callable, primary: bool = false) -> Button:
	var button := MenuStyle.button(text,action,primary)
	button.custom_minimum_size.y = 52
	button.add_theme_font_size_override("font_size",20)
	button.disabled = busy
	parent.add_child(button)
	return button
