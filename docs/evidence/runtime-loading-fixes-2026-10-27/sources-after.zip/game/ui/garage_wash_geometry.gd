extends RefCounted
## Original closed microfiber mitt/cuff and a shallow lather surface; shared menu meshes.
static var meshes: Dictionary = {}

static func nozzle() -> ArrayMesh:
	if meshes.has("nozzle"): return meshes.nozzle
	var tool := SurfaceTool.new()
	tool.begin(Mesh.PRIMITIVE_TRIANGLES)
	for section: Vector3 in [Vector3(0.033,0.12,0.04),Vector3(0.044,0.055,-0.055),Vector3(0.027,0.035,-0.10)]:
		var barrel := CylinderMesh.new()
		barrel.top_radius = section.x*0.85
		barrel.bottom_radius = section.x
		barrel.height = section.y
		barrel.radial_segments = 20
		_append(tool,barrel,Transform3D(Basis(Vector3.RIGHT,PI*0.5),Vector3(0,0,section.z)))
	tool.index()
	meshes.nozzle = tool.commit()
	return meshes.nozzle

static func mitt() -> ArrayMesh:
	if meshes.has("mitt"): return meshes.mitt
	var sphere := SphereMesh.new()
	sphere.radius = 1.0
	sphere.height = 2.0
	sphere.radial_segments = 32
	sphere.rings = 12
	var tool := SurfaceTool.new()
	tool.begin(Mesh.PRIMITIVE_TRIANGLES)
	var centre := Vector3(0,0.027,-0.014)
	var axes := Vector3(0.083,0.027,0.117)
	_append(tool,sphere,Transform3D(Basis.from_scale(axes),centre))
	_append(tool,sphere,Transform3D(Basis(Vector3.UP,-0.38)*Basis.from_scale(Vector3(0.034,0.022,0.061)),Vector3(0.073,0.024,0.019)))
	# Closed tiny loops give the nap a soft real silhouette, without extra draws.
	for band: int in range(5):
		var latitude: float = 0.18 + float(band)*0.25
		for index: int in range(16):
			var angle: float = float(index)*TAU/16.0 + float(band)*0.19
			var n := Vector3(cos(angle)*cos(latitude),sin(latitude),sin(angle)*cos(latitude))
			var normal: Vector3 = (n/axes).normalized()
			var at: Vector3 = centre+n*axes
			var tangent: Vector3 = normal.cross(Vector3.FORWARD).normalized()
			var across: Vector3 = normal.cross(tangent)
			var bend: Vector3 = tangent*0.0012
			var tip: Vector3 = at+normal*(0.0035+float(index%3)*0.0007)+bend
			var ring: Array[Vector3] = []
			for side: int in range(3):
				var phase: float = float(side)*TAU/3.0
				ring.append(at+(tangent*cos(phase)+across*sin(phase))*0.0015)
			for side: int in range(3): _face(tool,[ring[side],ring[(side+1)%3],tip],(ring[side]+ring[(side+1)%3])*0.5-at,[Vector2.ZERO,Vector2.RIGHT,Vector2(0.5,1)])
			_face(tool,[ring[0],ring[2],ring[1]],-normal,[Vector2.ZERO,Vector2.RIGHT,Vector2.ONE])
	tool.index()
	meshes.mitt = tool.commit()
	return meshes.mitt

static func cuff() -> ArrayMesh:
	if meshes.has("cuff"): return meshes.cuff
	var tool := SurfaceTool.new()
	tool.begin(Mesh.PRIMITIVE_TRIANGLES)
	for index: int in range(40):
		var a: float = float(index)*TAU/40.0
		var b: float = float(index+1)*TAU/40.0
		var outer: Array[Vector3] = []
		var inner: Array[Vector3] = []
		for angle: float in [a,b]:
			var rib: float = 1.0+cos(angle*20.0)*0.022
			outer.append(Vector3(cos(angle)*0.065*rib,0.027+sin(angle)*0.021*rib,0.080))
			inner.append(Vector3(cos(angle)*0.058,0.027+sin(angle)*0.014,0.080))
		var span := Vector3(0,0,0.032)
		var radial := Vector3(cos((a+b)*0.5),sin((a+b)*0.5)*2.0,0).normalized()
		var uv: Array[Vector2] = [Vector2(float(index)/40.0,0),Vector2(float(index+1)/40.0,0),Vector2(float(index+1)/40.0,1),Vector2(float(index)/40.0,1)]
		_face(tool,[outer[0],outer[1],outer[1]+span,outer[0]+span],radial,uv)
		_face(tool,[inner[0],inner[1],inner[1]+span,inner[0]+span],-radial,uv)
		_face(tool,[inner[0],inner[1],outer[1],outer[0]],Vector3.FORWARD,uv)
		_face(tool,[inner[0]+span,inner[1]+span,outer[1]+span,outer[0]+span],Vector3.BACK,uv)
	tool.index()
	meshes.cuff = tool.commit()
	return meshes.cuff

static func lather() -> ArrayMesh:
	if meshes.has("lather"): return meshes.lather
	var tool := SurfaceTool.new()
	tool.begin(Mesh.PRIMITIVE_TRIANGLES)
	tool.set_color(Color(0,0,0,1))
	for ring: int in range(5):
		var inner: float = float(ring)/5.0
		var outer: float = float(ring+1)/5.0
		for index: int in range(24):
			var points: Array[Vector3] = []
			var uv: Array[Vector2] = []
			for polar: Vector2 in [Vector2(inner,index),Vector2(inner,index+1),Vector2(outer,index+1),Vector2(outer,index)]:
				var angle: float = polar.y*TAU/24.0
				var p := Vector2(cos(angle),sin(angle))*polar.x
				var outline: float = 0.89+sin(angle*5.0)*0.065+sin(angle*9.0+0.4)*0.035
				var q: Vector2 = p*outline
				# A connected shallow pillowy volume replaces flat individual bubble stamps.
				var crown: float = sqrt(maxf(0.0,1.0-polar.x*polar.x))*0.055
				crown *= 1.0+sin(q.x*5.0+0.7)*cos(q.y*4.0)*0.13
				points.append(Vector3(q.x,crown,q.y))
				uv.append(p*0.5+Vector2.ONE*0.5)
			if ring == 0: _face(tool,[points[0],points[2],points[3]],Vector3.UP,[uv[0],uv[2],uv[3]])
			else: _face(tool,points,Vector3.UP,uv)
	tool.index()
	tool.generate_normals()
	tool.deindex()
	# Small rounded air pockets emerge from a continuous dense base, rather than holes.
	var bubble := SphereMesh.new()
	bubble.radius = 1.0
	bubble.height = 2.0
	bubble.radial_segments = 8
	bubble.rings = 4
	tool.set_color(Color(1,0,0,1))
	var centres: Array[Vector2] = [Vector2(-0.26,0.05),Vector2(0.17,-0.15),Vector2(0.43,0.26),Vector2(-0.02,0.40),Vector2(-0.36,-0.38),Vector2(0.04,-0.52),Vector2(0.63,-0.30),Vector2(-0.60,0.13),Vector2(-0.25,0.66),Vector2(0.48,0.60),Vector2(-0.62,-0.46)]
	for index: int in range(centres.size()):
		var at: Vector2 = centres[index]
		var radius: float = 0.11+float(index%4)*0.018
		var height: float = sqrt(maxf(0.0,1.0-at.length_squared()))*0.048
		_append(tool,bubble,Transform3D(Basis.from_scale(Vector3(radius,0.055+float(index%3)*0.01,radius)),Vector3(at.x,height,at.y)),true)
	tool.index()
	meshes.lather = tool.commit()
	return meshes.lather

static func _append(tool: SurfaceTool, mesh: Mesh, pose: Transform3D, projected_uv: bool = false) -> void:
	var arrays: Array = mesh.surface_get_arrays(0)
	var points: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
	var normals: PackedVector3Array = arrays[Mesh.ARRAY_NORMAL]
	var uv: PackedVector2Array = arrays[Mesh.ARRAY_TEX_UV]
	var indices: PackedInt32Array = arrays[Mesh.ARRAY_INDEX]
	var inverse: Basis = pose.basis.inverse().transposed()
	for index: int in indices:
		tool.set_normal((inverse*normals[index]).normalized())
		var point: Vector3 = pose*points[index]
		tool.set_uv(Vector2(point.x,point.z)*0.5+Vector2.ONE*0.5 if projected_uv else uv[index])
		tool.add_vertex(point)

static func _face(tool: SurfaceTool, points: Array[Vector3], outward: Vector3, uv: Array[Vector2]) -> void:
	var normal: Vector3 = outward.normalized()
	var reverse: bool = (points[1]-points[0]).cross(points[2]-points[0]).dot(normal) > 0.0
	for triangle: int in range(1,points.size()-1):
		for index: int in ([0,triangle+1,triangle] if reverse else [0,triangle,triangle+1]):
			tool.set_normal(normal)
			tool.set_uv(uv[index])
			tool.add_vertex(points[index])
