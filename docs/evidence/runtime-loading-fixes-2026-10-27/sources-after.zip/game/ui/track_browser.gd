class_name TrackBrowser
extends VBoxContainer

signal home_requested
signal race_requested(track: NativeTrack)
signal track_selected(track: NativeTrack)
signal preparation_requested(track: NativeTrack)
signal edit_requested(document: Dictionary)
signal delete_requested(id: String, title: String)
signal import_requested
signal notice(message: String)
signal share_requested(entry: Dictionary)
signal rivalry_requested
signal challenges_requested
signal daily_requested
signal entry_chosen(entry: Dictionary)

var selection_only: bool = false
var selected_versions: PackedStringArray = []
var _selection_actions: GridContainer

var library: TrackLibrary
var records: LocalRecords
var builtin_ids: Array[String]
var selected_track: NativeTrack
var state: Dictionary
var page_preview: bool = false:
	set(value):
		page_preview = value
		if value and discovery != null: discovery.comparisons.cancel_speculation()
var catalog: TrackCatalog
var matches: Array[Dictionary] = []
var grid: GridContainer
var detail: VBoxContainer
var count_label: Label
var random_button: Button
var discovery := TrackDiscoveryProvider.new()
var race_button: Button
var loading: bool = true
var detail_costs: Dictionary = {}
var selecting: bool = false
var preview_entry: Dictionary = {}
var pending_records: Label
var _resolve_job: RefCounted
var _requested_entry: Dictionary = {}
var _working_entry: Dictionary = {}
var _selection_serial: int = 0
var _working_serial: int = 0
var _cloud_detail_pending: Dictionary = {}
var _comparison_selection: String = ""
var rng := RandomNumberGenerator.new()
var cloud: Node
var cloud_status: Label
var gallery: ScrollContainer
var gallery_content: Control
const HERO_FADE_SECONDS: float = 0.42
var _slide_distance: float = 0.0
var _outgoing_panels: Array[Control] = []
var _outgoing_serial: int = -1
var _hero_direction: float = 1.0
var _section_motion: Tween
var _section_offset: float = 0.0
var records_panel: PanelContainer
var _hero_serial: int = -1
var _hero_scenery: Control
var _hero_art: TextureRect
var hero: PanelContainer
const FilterDrawer = preload("res://ui/track_filter_drawer.gd")
var filter_dialog: FilterDrawer
var filter_button: Button
const SearchDrawer = preload("res://ui/track_search_drawer.gd")
var search_dialog: SearchDrawer
var _tile_start: int = -1
var _query_signature: String = ""
var tile_stride: int = 202
var gallery_slot: Control
var _cloud_catalog_state: Array = []
var _page_dirty: bool = false
var _detail_state: Array = []
var _comparison_view_key: String = ""
var _detail_loading: bool = false
const COMPARISON_NOTICE_DELAY_MS: int = 2500
var _detail_wait_started: int = 0
var _detail_wait_key: String = ""
var _warming_window: String = ""
var _hero_state: Array = []
var list_open: bool = true
var track_list: ScrollContainer
var list_content: Control
var list_grid: GridContainer
var _list_columns: int = 1
var _list_stride := Vector2(240,192)
var _list_start: int = -1
var _list_layout_pending: bool = false
const VIEW_SLIDE_SECONDS: float = 0.32
var _view_slot: Control
var _track_page: VBoxContainer
var _view_blocker: ScrollContainer
var _view_motion: Tween
var _view_progress: float = 0.0
var _preparation_key: Array = []
var _preparation_since: int = 0
var _preparation_sent: bool = false
const PREPARATION_SETTLE_MS: int = 650
const COMPARISON_REUSE = preload("res://backend/comparison_reuse.gd")
var _comparison_attempts: Dictionary = {}

func _ready() -> void:
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_theme_constant_override("separation",8)
	rng.randomize()
	discovery.changed.connect(_discovery_changed)
	discovery.comparisons.completed.connect(_comparison_warmed)
	if catalog == null: catalog = TrackCatalog.new(library)
	var body := HBoxContainer.new()
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(body)
	_build_mode_rail(body)
	var main := VBoxContainer.new()
	main.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	main.add_theme_constant_override("separation",8)
	body.add_child(main)
	_view_slot = Control.new()
	_view_slot.name = "TrackViewSlot"
	_view_slot.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_view_slot.clip_contents = true
	main.add_child(_view_slot)
	_build_track_list(_view_slot)
	_track_page = VBoxContainer.new()
	_track_page.name = "TrackDetailPage"
	_track_page.add_theme_constant_override("separation",8)
	_view_slot.add_child(_track_page)
	_view_slot.resized.connect(func() -> void: _set_view_progress(_view_progress))
	var hero_slot := Control.new()
	hero_slot.name = "HeroSlot"
	hero_slot.size_flags_vertical = Control.SIZE_EXPAND_FILL
	# Leave room for complete charts, track cards and actions below the menu header.
	hero_slot.custom_minimum_size.y = 160
	hero_slot.clip_contents = true
	_track_page.add_child(hero_slot)
	hero = PanelContainer.new()
	hero.name = "RaceHero"
	hero.size_flags_vertical = Control.SIZE_EXPAND_FILL
	hero.custom_minimum_size.y = 0
	hero.clip_contents = true
	hero.add_theme_stylebox_override("panel",MenuStyle.box(Color.TRANSPARENT,0))
	hero_slot.add_child(hero)
	MenuStyle.fill(hero)
	var records_slot := Control.new()
	records_slot.name = "RecordsSlot"
	records_slot.custom_minimum_size.y = 180
	records_slot.clip_contents = true
	_track_page.add_child(records_slot)
	var selection := PanelContainer.new()
	records_panel = selection
	selection.add_theme_stylebox_override("panel",MenuStyle.box(Color("091720dd"),12))
	records_slot.add_child(selection)
	MenuStyle.fill(selection)
	records_slot.resized.connect(func() -> void: records_panel.size = records_slot.size)
	detail = VBoxContainer.new()
	selection.add_child(detail)
	pending_records = MenuStyle.label("",18,true)
	pending_records.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	selection.add_child(pending_records)
	pending_records.hide()
	gallery_slot = Control.new()
	gallery_slot.name = "GallerySlot"
	gallery_slot.custom_minimum_size.y = 140
	gallery_slot.resized.connect(_layout_gallery)
	_track_page.add_child(gallery_slot)
	gallery = preload("res://ui/track_carousel.gd").new()
	gallery.name = "TrackCarousel"
	gallery.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_SHOW_NEVER
	gallery.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	gallery.custom_minimum_size.y = 140
	gallery.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	gallery.scroll_deadzone = 12
	gallery.follow_focus = false
	gallery_slot.add_child(gallery)
	gallery_content = Control.new()
	gallery_content.custom_minimum_size.y = 140
	gallery.add_child(gallery_content)
	grid = GridContainer.new()
	grid.columns = 12
	grid.add_theme_constant_override("h_separation",12)
	gallery_content.add_child(grid)
	gallery.get_h_scroll_bar().value_changed.connect(func(_value: float) -> void: _render_tiles())
	# Scroll ownership also keeps a touch on moving content out of primary
	# menu navigation. The real gallery gesture owners pause during the slide.
	_view_blocker = ScrollContainer.new()
	_view_blocker.name = "TrackViewTransitionInput"
	_view_blocker.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_view_blocker.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_view_slot.add_child(_view_blocker)
	MenuStyle.fill(_view_blocker)
	_view_blocker.hide()
	count_label = MenuStyle.label("Loading?",12,true)
	count_label.clip_text = true
	main.add_child(count_label)
	count_label.hide()
	_build_actions()
	get_node("PlayActions").reparent(main)
	filter_dialog = FilterDrawer.new()
	filter_dialog.catalog = catalog
	filter_dialog.discovery = discovery
	filter_dialog.records = records
	filter_dialog.server_feeds = cloud != null and cloud.paged_discovery_available()
	add_child(filter_dialog)
	filter_dialog.applied.connect(func(filters: Dictionary) -> void:
		state.merge(filters,true)
		_refresh()
		if cloud != null: cloud.query_discovery(state,records.settings.get("favorites",[]),records.settings.get("raced_tracks",[])))
	filter_dialog.closed.connect(_enable_gallery_input)
	search_dialog = SearchDrawer.new()
	search_dialog.catalog = catalog
	search_dialog.discovery = discovery
	search_dialog.records = records
	search_dialog.cloud = cloud
	add_child(search_dialog)
	search_dialog.applied.connect(func(search: Dictionary) -> void:
		state.merge(search,true)
		state.page = 0
		_refresh()
		if cloud != null: cloud.query_discovery(state,records.settings.get("favorites",[]),records.settings.get("raced_tracks",[])))
	search_dialog.selected.connect(_select)
	search_dialog.closed.connect(_enable_gallery_input)
	if cloud != null:
		cloud.changed.connect(_cloud_changed)
		cloud_status = count_label
	_set_list_open(true)
	call_deferred("_load_catalog")

func _build_track_list(parent: Control) -> void:
	track_list = preload("res://ui/vertical_swipe_scroll.gd").new()
	track_list.name = "TrackList"
	track_list.size_flags_vertical = Control.SIZE_EXPAND_FILL
	track_list.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	# Reserve the scrollbar's width even for short lists, keeping columns stable.
	track_list.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_RESERVE
	track_list.follow_focus = false
	track_list.scroll_deadzone = 12
	parent.add_child(track_list)
	list_content = Control.new()
	list_content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	track_list.add_child(list_content)
	list_grid = GridContainer.new()
	list_grid.name = "TrackListCards"
	list_grid.add_theme_constant_override("h_separation",12)
	list_grid.add_theme_constant_override("v_separation",12)
	list_content.add_child(list_grid)
	track_list.resized.connect(_queue_list_layout)
	list_content.resized.connect(_queue_list_layout)
	track_list.get_v_scroll_bar().value_changed.connect(func(_value: float) -> void: _render_list())

func _queue_list_layout() -> void:
	if _list_layout_pending: return
	_list_layout_pending = true
	_layout_list.call_deferred()

func _layout_list() -> void:
	_list_layout_pending = false
	if not is_inside_tree() or not list_open: return
	var anchor: int = int(track_list.scroll_vertical/_list_stride.y)*_list_columns-_list_column_offset
	var width: float = maxf(1.0,list_content.size.x)
	var previous_columns: int = _list_columns
	_list_columns = maxi(1,floori((width+12.0)/236.0))
	_list_column_offset = posmod(-_window_shift,_list_columns) if _window_generation >= 0 else 0
	_list_stride = Vector2(floorf((width+12.0)/_list_columns),204)
	list_grid.columns = _list_columns
	_update_list_extent()
	if previous_columns != _list_columns: track_list.scroll_vertical = maxi(0,int((anchor+_list_column_offset)/_list_columns)*int(_list_stride.y))
	_list_start = -1
	_render_list(true)

func _update_list_extent() -> void:
	list_content.custom_minimum_size.y = maxf(1.0,ceilf(float(_page_total()+_list_column_offset)/_list_columns)*_list_stride.y-12.0)

func _render_list(reconcile: bool = false) -> void:
	if not list_open or not is_instance_valid(list_grid): return
	var first_row: int = maxi(0,floori(track_list.scroll_vertical/_list_stride.y)-1)
	var first: int = first_row*_list_columns
	var end: int = mini(_page_total()+_list_column_offset,first+(ceili(track_list.size.y/_list_stride.y)+3)*_list_columns)
	var paged: bool = cloud != null and cloud.paged_discovery_available() and is_instance_valid(cloud.discovery_pages) and cloud.discovery_pages.total >= 0
	if paged:
		var visible_first: int = int(track_list.scroll_vertical/_list_stride.y)*_list_columns-_list_column_offset
		_prefetch_tracks(visible_first,ceili(track_list.size.y/_list_stride.y)*_list_columns)
	elif cloud != null and not page_preview and end >= matches.size() and track_list.scroll_vertical > 0:
		cloud.load_more()
	if first == _list_start and not reconcile: return
	_list_start = first
	var retained: Dictionary = {}
	for child: Node in list_grid.get_children():
		var index: int = int(child.get_meta("catalog_index",-1))
		var entry: Dictionary = _list_entry(index,paged) if index >= first and index < end else {}
		if entry.is_empty() or not child is TrackTile or str(child.entry.get("id","")) != str(entry.get("id","")):
			list_grid.remove_child(child)
			child.queue_free()
		else: retained[index] = child
	list_grid.position = Vector2(0,first_row*_list_stride.y)
	for index: int in range(first,end):
		var entry: Dictionary = _list_entry(index,paged)
		var tile: Control
		if retained.has(index):
			tile = retained[index]
			if reconcile: (tile as TrackTile).update_entry(entry,entry.id in records.settings.get("favorites",[]),int(records.settings.get("track_ratings",{}).get(str(entry.id),0)),selection_only and str(entry.get("version_id","")) in selected_versions)
		elif entry.is_empty():
			# A partial leading row keeps retained cards in their original columns
			# after cache eviction. No unloaded track receives a card or a label.
			if index >= _list_column_offset: continue
			tile = Control.new()
			tile.mouse_filter = Control.MOUSE_FILTER_IGNORE
			tile.set_meta("catalog_index",index)
			list_grid.add_child(tile)
		else:
			var card := TrackTile.new()
			card.entry = entry
			card.selected = selection_only and str(entry.get("version_id","")) in selected_versions
			card.favorite = entry.id in records.settings.get("favorites",[])
			card.personal_rating = int(records.settings.get("track_ratings",{}).get(str(entry.id),0))
			card.name = "ListTrack_"+str(entry.id)
			card.set_meta("catalog_index",index)
			card.pressed.connect(_select_tile.bind(card))
			card.favorite_requested.connect(_favorite_id.bind(str(entry.id)))
			card.focus_entered.connect(_focus_list_card.bind(card))
			list_grid.add_child(card)
			tile = card
		tile.custom_minimum_size = _list_stride-Vector2(12,12)
		tile.size_flags_horizontal = Control.SIZE_FILL
		list_grid.move_child(tile,index-first)
	if _page_total() == 0:
		var unresolved: bool = loading or (cloud != null and cloud.paged_discovery_available() and (not is_instance_valid(cloud.discovery_pages) or cloud.discovery_pages.total < 0 or cloud.discovery_pages.loading))
		var empty := MenuStyle.label("Loading tracks..." if unresolved else "No tracks found. Change your filters or search.",20,true)
		if cloud != null and is_instance_valid(cloud.discovery_pages) and not cloud.discovery_pages.error.is_empty(): empty.text = cloud.discovery_pages.error
		empty.name = "TrackListEmptyState"
		empty.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		empty.custom_minimum_size.x = _list_stride.x-12
		empty.custom_minimum_size.y = 128
		list_grid.add_child(empty)

func _list_entry(index: int, paged: bool) -> Dictionary:
	var card_index: int = index-_list_column_offset if paged else index
	return matches[card_index] if card_index >= 0 and card_index < matches.size() else {}

func _prefetch_tracks(first: int, visible_count: int) -> void:
	if page_preview or cloud == null or not cloud.paged_discovery_available() or not is_instance_valid(cloud.discovery_pages): return
	var window: Node = cloud.discovery_pages
	if window.total < 0 or not window.error.is_empty(): return
	var index: int = clampi(first,0,maxi(0,matches.size()-1))
	var network_index: int = int(matches[index].get("discovery_index",index)) if not matches.is_empty() else 0
	window.request_visible.call_deferred(network_index,maxi(1,visible_count))

func _focus_list_card(card: TrackTile) -> void:
	var top: int = int(int(card.get_meta("catalog_index"))/_list_columns)*int(_list_stride.y)
	if top < track_list.scroll_vertical: track_list.scroll_vertical = top
	elif top+_list_stride.y-12 > track_list.scroll_vertical+track_list.size.y:
		track_list.scroll_vertical = ceili(top+_list_stride.y-12-track_list.size.y)

func _set_list_open(value: bool, animate: bool = false) -> void:
	if value and discovery != null: discovery.comparisons.cancel_speculation()
	if list_open and not value: _comparison_selection = ""
	list_open = value
	race_button.visible = not value
	for button: Button in [random_button,filter_button,find_child("RaceSearch",true,false)]:
		button.size_flags_horizontal = Control.SIZE_EXPAND_FILL if value else Control.SIZE_FILL
	if value:
		_queue_list_layout()
	else:
		_layout_gallery.call_deferred()
	if _view_motion != null:
		_view_motion.kill()
		_view_motion = null
	var destination: float = 0.0 if value else 1.0
	if animate and is_inside_tree() and not page_preview and not is_equal_approx(destination,_view_progress):
		track_list.show()
		_track_page.show()
		_view_blocker.show()
		get_viewport().gui_release_focus()
		_set_view_progress(_view_progress)
		_view_motion = create_tween()
		_view_motion.tween_method(_set_view_progress,_view_progress,destination,VIEW_SLIDE_SECONDS*absf(destination-_view_progress)).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
		_view_motion.tween_callback(_finish_view_transition)
		_enable_gallery_input()
	else:
		_set_view_progress(destination)
		_finish_view_transition()

func _set_view_progress(value: float) -> void:
	_view_progress = value
	# A scrollbar minimum can add offsets while this slot is initially empty.
	# Match the settled slot explicitly before applying the vertical push.
	if track_list.size != _view_slot.size: track_list.size = _view_slot.size
	if _track_page.size != _view_slot.size: _track_page.size = _view_slot.size
	var distance: float = _view_slot.size.y
	_track_page.position = Vector2(0.0,(value-1.0)*distance)
	track_list.position = Vector2(0.0,value*distance)

func _finish_view_transition() -> void:
	_view_motion = null
	track_list.visible = list_open
	_track_page.visible = not list_open
	_view_blocker.hide()
	_enable_gallery_input()

func _open_track_view() -> void:
	if not list_open: return
	_set_list_open(false,true)

func _close_track_view() -> void:
	state.erase("pinned_version")
	_selection_serial += 1
	if cloud != null and cloud.client.has_method("cancel_public_reads"): cloud.client.cancel_public_reads(get_instance_id())
	if _resolve_job != null: _resolve_job.cancel()
	_requested_entry = {}
	preview_entry = {}
	selecting = false
	if _section_motion != null: _section_motion.kill()
	_clear_outgoing_section()
	_set_section_offset(0.0)
	_hero_serial = -1
	_hero_state = []
	_detail_state = []
	_set_list_open(true,true)

func _show_creator_tracks(creator: String) -> void:
	state.merge(FilterDrawer.DEFAULTS,true)
	for key: String in ["name","creator","focus_track","random_on_open"]: state.erase(key)
	state.search = creator
	state.search_kind = 2
	state.page = 0
	_close_track_view()
	_refresh()
	if cloud != null: cloud.query_discovery(state,records.settings.get("favorites",[]),records.settings.get("raced_tracks",[]))

func _enable_gallery_input() -> void:
	var modal_open: bool = (is_instance_valid(filter_dialog) and filter_dialog.visible) or (is_instance_valid(search_dialog) and search_dialog.visible)
	var enabled: bool = _view_motion == null and not modal_open
	gallery.set_process_input(enabled and not list_open)
	track_list.set_process_input(enabled and list_open)

func _load_catalog() -> void:
	if not is_inside_tree(): return
	if page_preview:
		# Adjacent menu preparation reads cached metadata only. No random choice,
		# download, account write or HTTP request may start during a page drag.
		if cloud != null:
			_sync_cloud_catalog()
			catalog.indexed_revision = library.revision
		loading = false
		_refresh()
		_show_detail()
		return
	if catalog.indexed_revision == library.revision:
		if cloud != null: _sync_cloud_catalog()
		loading = false
		_refresh()
		_show_detail()
		_random_on_open()
		if cloud != null: cloud.query_discovery(state,records.settings.get("favorites",[]),records.settings.get("raced_tracks",[]))
		return
	loading = true
	catalog.clear_resolved()
	await get_tree().process_frame
	if not is_inside_tree(): return
	var revision: int = library.revision
	var slice_start: int = Time.get_ticks_usec()
	catalog.entries.clear()
	_cloud_catalog_state.clear()
	if cloud != null:
		_sync_cloud_catalog()
		loading = false
		catalog.indexed_revision = revision
		_refresh()
		_show_detail()
		_random_on_open()
		cloud.query_discovery(state,records.settings.get("favorites",[]),records.settings.get("raced_tracks",[]))
		return
	for index: int in range(builtin_ids.size()):
		catalog.add_builtin(builtin_ids[index])
		if Time.get_ticks_usec()-slice_start >= 3000:
			count_label.text = GameText.message("Loading circuits  /  %d of %d") % [index+1,builtin_ids.size()]
			await get_tree().process_frame
			if not is_inside_tree(): return
			slice_start = Time.get_ticks_usec()
	_refresh()
	var ids: Array[String] = catalog.local_ids()
	for index: int in range(ids.size()):
		catalog.add_local(ids[index])
		if Time.get_ticks_usec()-slice_start >= 3000:
			count_label.text = GameText.message("Indexing saved tracks  /  %d of %d") % [index+1,ids.size()]
			await get_tree().process_frame
			if not is_inside_tree(): return
			slice_start = Time.get_ticks_usec()
	catalog.add_shared_tracks()
	if cloud != null: _sync_cloud_catalog()
	loading = false
	catalog.indexed_revision = revision
	_refresh()
	_random_on_open()
	if cloud != null: cloud.query_discovery(state,records.settings.get("favorites",[]),records.settings.get("raced_tracks",[]))

func activate_page() -> void:
	if not page_preview: return
	page_preview = false
	_comparison_selection = ""
	# The cached controls and metadata are already current. Rebuilding both
	# sections here introduces a visible hitch just as the page finishes arriving.
	if catalog.indexed_revision != library.revision:
		_load_catalog()
	else:
		if _page_dirty:
			if cloud != null: _cloud_changed()
			_refresh()
			_show_detail()
			_page_dirty = false
		_random_on_open()
		_show_detail()
		_warm_visible_comparisons(maxi(0,int(gallery.scroll_horizontal/tile_stride)-1))
		if cloud != null: cloud.query_discovery(state,records.settings.get("favorites",[]),records.settings.get("raced_tracks",[]))

func _sync_cloud_catalog() -> bool:
	if cloud == null: return false
	var current: Array = [cloud.entries, records.settings.get("favorites",[]), cloud.client.base_url(), cloud.client.player.get("id",""), cloud.client.signed_in()]
	if cloud.paged_discovery_available() and is_instance_valid(cloud.discovery_pages): current.append([cloud.discovery_pages.total,cloud.discovery_pages.generation,cloud.discovery_pages.loading])
	if current == _cloud_catalog_state: return false
	cloud.add_to_catalog(catalog,discovery,records.settings.get("favorites",[]))
	_sync_discovery_window()
	_cloud_catalog_state = current.duplicate(true)
	return true

var _window_generation: int = -1
var _window_shift: int = 0
var _list_column_offset: int = 0

func _sync_discovery_window() -> void:
	if cloud == null or not cloud.paged_discovery_available():
		_window_generation = -1
		_window_shift = 0
		_list_column_offset = 0
		return
	if not is_instance_valid(cloud.discovery_pages): return
	var window = cloud.discovery_pages
	if _window_generation != int(window.generation):
		_window_generation = int(window.generation)
		_window_shift = 0
		_list_column_offset = 0
		gallery.call("_stop_snap")
		gallery.scroll_horizontal = 0
		track_list.scroll_vertical = 0
		return
	if window.total < 0: return
	# Presentation contains actual cards only. Cursor slots can have gaps after
	# authority filtering, and the leading reload page is never a visible row.
	var shift: int = 0
	var incoming: Array = discovery.query(catalog,state,records.settings.get("favorites",[]),records.settings.get("track_ratings",{}),records.settings.get("raced_tracks",[]))
	var positions: Dictionary = {}
	for index: int in range(incoming.size()): positions[str(incoming[index].version_id)] = index
	for index: int in range(matches.size()):
		var version: String = str(matches[index].get("version_id",""))
		if positions.has(version):
			shift = int(positions[version])-index
			break
	_window_shift += shift
	if shift != 0:
		var new_offset: int = posmod(-_window_shift,_list_columns)
		var list_shift: int = shift+new_offset-_list_column_offset
		_list_column_offset = new_offset
		gallery.call("_stop_snap")
		gallery.scroll_horizontal = maxi(0,gallery.scroll_horizontal+shift*tile_stride)
		track_list.scroll_vertical = maxi(0,track_list.scroll_vertical+int(list_shift/_list_columns)*int(_list_stride.y))
		_tile_start = -1
		_list_start = -1

func _cloud_changed() -> void:
	if page_preview:
		_page_dirty = true
		return
	if is_instance_valid(cloud_status): cloud_status.text = cloud.status
	if not _sync_cloud_catalog(): return
	_refresh()
	_random_on_open()
	if not selecting:
		if list_open: return
		for entry: Dictionary in catalog.entries:
			if str(entry.id) == selected_track.identity and str(entry.get("version_id","")) != str(selected_track.metadata.get("cloud_version","")):
				if not str(state.get("pinned_version","")).is_empty() and state.pinned_version == selected_track.metadata.get("cloud_version",""): continue
				_select(entry)
				return
		_show_detail()

func _selected_is_available() -> bool:
	if cloud == null: return true
	if is_instance_valid(cloud.client.get("safety")) and not cloud.client.safety.allows(selected_track.metadata.get("cloud_entry",selected_track.metadata)): return false
	if cloud.paged_discovery_available() and selected_track.metadata.has("cloud_version"):
		return not cloud.retained_entry(selected_track.identity).is_empty()
	return selected_track.metadata.has("cloud_version") and catalog.entries.any(func(entry: Dictionary) -> bool: return str(entry.id) == selected_track.identity)

func _random_on_open() -> void:
	if selection_only: return
	var focus_id: String = str(state.get("focus_track",""))
	if not focus_id.is_empty():
		for entry: Dictionary in matches:
			if str(entry.id) != focus_id: continue
			if cloud == null or not cloud.paged_discovery_available() or (is_instance_valid(cloud.discovery_pages) and cloud.discovery_pages.total >= 0): state.erase("focus_track")
			_select(entry)
			_reveal_track.call_deferred(focus_id)
			return
	if state.get("random_on_open",false):
		if cloud != null and cloud.paged_discovery_available() and (not is_instance_valid(cloud.discovery_pages) or cloud.discovery_pages.total < 0): return
		state.erase("random_on_open")
		_random()

func _reveal_track(identity: String) -> void:
	# Scroll after the container has laid out its complete virtual carousel.
	if not is_inside_tree(): return
	await get_tree().process_frame
	if not is_inside_tree() or list_open or identity != str(preview_entry.get("id",selected_track.identity)): return
	for index: int in range(matches.size()):
		if str(matches[index].id) != identity: continue
		gallery.call("_stop_snap")
		gallery.scroll_horizontal = index*tile_stride
		_render_tiles(true)
		return

func _clear(parent: Node) -> void:
	for child: Node in parent.get_children():
		parent.remove_child(child)
		child.queue_free()

func _refresh() -> void:
	if not is_instance_valid(grid): return
	matches = discovery.query(catalog,state,records.settings.get("favorites",[]),records.settings.get("track_ratings",{}),records.settings.get("raced_tracks",[]))
	var signature: String = str([state.get("section","all"),state.get("feed","recommended"),state.get("search",""),state.get("search_kind",0),state.get("theme","all"),state.get("sort","name"),state.get("minimum_rating",0.0),state.get("race_count","any"),state.get("age_days",0),state.get("race_history","any")])
	if signature != _query_signature:
		gallery.call("_stop_snap")
		gallery.scroll_horizontal = 0
		track_list.scroll_vertical = 0
	_query_signature = signature
	var track_count: int = _page_total()
	gallery_content.custom_minimum_size.x = maxi(1,track_count*tile_stride-12)
	_update_list_extent()
	_render_list(true)
	_render_tiles(true)
	if matches.is_empty() and grid.get_child_count() == 0:
		var empty := MenuStyle.label("No tracks found.\nTry another name or creator,\nor change your filters.",20,true)
		var unresolved: bool = loading or (cloud != null and cloud.paged_discovery_available() and (not is_instance_valid(cloud.discovery_pages) or cloud.discovery_pages.total < 0 or cloud.discovery_pages.loading))
		if state.get("section") == "favorites" and str(state.get("name","")).is_empty() and str(state.get("creator","")).is_empty():
			empty.text = "Your favorites start here.\nSelect a circuit and tap its star."
		if state.get("section","all") == "all" and state.get("feed","recommended") != "recommended" and not discovery.available:
			empty.text = "This discovery feed needs online data.\nYour local tracks are in Recommended."
		if unresolved:
			empty.text = "Loading tracks..."
			if cloud != null and is_instance_valid(cloud.discovery_pages) and not cloud.discovery_pages.error.is_empty(): empty.text = cloud.discovery_pages.error
		empty.name = "DiscoveryEmptyState"
		empty.custom_minimum_size.y = 128
		grid.add_child(empty)
	count_label.text = GameText.plural("{count} / {total} circuit","{count} / {total} circuits",matches.size(),{"total":catalog.entries.size()}) + (GameText.message(" · indexing…") if loading else "")
	if cloud != null: count_label.text += " · "+str(cloud.status)
	count_label.tooltip_text = GameText.message("%d matching tracks out of %d in your library") % [matches.size(),catalog.entries.size()]
	if cloud != null and cloud.has_method("paged_discovery_available") and cloud.paged_discovery_available():
		count_label.text = cloud.status
		count_label.tooltip_text = "Loaded track cards. Scroll to browse more; Refresh updates the ordering."
	random_button.disabled = matches.is_empty() or loading
	var filter_count: int = FilterDrawer.active_count(state)
	filter_button.text = "Filters"+(" - %d" % filter_count if filter_count > 0 else "")
	filter_button.add_theme_color_override("font_color",MenuStyle.ACCENT if filter_count > 0 else MenuStyle.TEXT)
	filter_button.add_theme_color_override("icon_normal_color",MenuStyle.ACCENT if filter_count > 0 else MenuStyle.TEXT)
	if filter_dialog.visible: filter_dialog.refresh_choices()
	if search_dialog != null and search_dialog.visible: search_dialog.refresh_results()

func _render_tiles(reconcile: bool = false) -> void:
	if not is_instance_valid(grid): return
	if cloud != null and cloud.paged_discovery_available() and is_instance_valid(cloud.discovery_pages) and cloud.discovery_pages.total >= 0:
		if not list_open: _prefetch_tracks(int(gallery.scroll_horizontal/tile_stride),ceili(gallery.size.x/maxf(1.0,tile_stride)))
	elif not list_open and cloud != null and gallery.scroll_horizontal > 0 and int(gallery.scroll_horizontal/tile_stride)+12 >= matches.size():
		cloud.load_more()
	var first: int = maxi(0,int(gallery.scroll_horizontal/tile_stride)-1)
	_warm_visible_comparisons(first)
	if first == _tile_start and not reconcile: return
	# Keep overlapping cards alive: scrolling one card must not rebuild twelve
	# buttons, resample every route and invalidate all their draw commands.
	_tile_start = first
	var end: int = mini(matches.size(),first+12)
	var wanted: Dictionary = {}
	for index: int in range(first,end): wanted[str(matches[index].id)] = index
	var retained: Dictionary = {}
	for child: Node in grid.get_children():
		var identity: String = str(child.entry.id) if child is TrackTile else ""
		if not wanted.has(identity):
			grid.remove_child(child)
			child.queue_free()
		else: retained[identity] = child
	grid.position.x = first*tile_stride+float(gallery.get("overscroll_offset"))
	for index: int in range(first,end):
		var entry: Dictionary = matches[index]
		if retained.has(str(entry.id)):
			var existing: TrackTile = retained[str(entry.id)]
			if int(existing.get_meta("catalog_index")) != index: existing.set_meta("catalog_index",index)
			if reconcile: existing.update_entry(entry,entry.id in records.settings.get("favorites",[]),int(records.settings.get("track_ratings",{}).get(str(entry.id),0)),entry.id == preview_entry.get("id",selected_track.identity))
			grid.move_child(existing,index-first)
			continue
		var tile := TrackTile.new()
		tile.set_meta("catalog_index",index)
		tile.compact = true
		tile.entry = entry
		tile.favorite = entry.id in records.settings.get("favorites",[])
		tile.personal_rating = int(records.settings.get("track_ratings",{}).get(str(entry.id),0))
		tile.selected = entry.id == preview_entry.get("id",selected_track.identity)
		tile.name = "Track_"+str(entry.id)
		tile.pressed.connect(_select_tile.bind(tile))
		tile.focus_entered.connect(_focus_tile.bind(tile))
		tile.favorite_requested.connect(_favorite_id.bind(str(entry.id)))
		grid.add_child(tile)
		grid.move_child(tile,index-first)
		tile.custom_minimum_size = Vector2(tile_stride-12,140)
		tile.size_flags_horizontal = Control.SIZE_FILL

func _layout_gallery() -> void:
	if not is_instance_valid(grid): return
	gallery.call("_stop_snap")
	var first: int = roundi(float(gallery.scroll_horizontal)/tile_stride)
	var slots: int = maxi(1,floori((gallery_slot.size.x+12.0)/202.0))
	tile_stride = floori((gallery_slot.size.x+12.0)/slots)
	gallery.position.x = (gallery_slot.size.x-(slots*tile_stride-12))*0.5
	gallery.size = Vector2(slots*tile_stride-12,140)
	gallery.set("snap_stride",tile_stride)
	# Cards prepared while the detail was hidden must adopt its settled width.
	for tile: Control in grid.get_children(): tile.custom_minimum_size.x = tile_stride-12
	gallery_content.custom_minimum_size.x = maxi(1,_page_total()*tile_stride-12)
	gallery.scroll_horizontal = first*tile_stride
	_tile_start = -1
	_render_tiles()

func _random() -> void:
	if cloud != null and cloud.paged_discovery_available():
		if not is_instance_valid(cloud.discovery_pages) or cloud.discovery_pages.total <= 0: return
		random_button.disabled = true
		var metadata: Dictionary = await cloud.discovery_pages.random_entry(selected_track.identity)
		if not is_inside_tree(): return
		random_button.disabled = false
		if metadata.is_empty():
			var detail: String = str(cloud.discovery_pages.error)
			notice.emit(detail if not detail.is_empty() else "No matching tracks are available. Refresh to retry.")
			return
		var public_entry: Dictionary = cloud.entry_from_metadata(metadata)
		gallery.call("_stop_snap")
		for index: int in range(matches.size()):
			if str(matches[index].get("version_id","")) == str(metadata.version_id):
				gallery.scroll_horizontal = index*tile_stride
				break
		_render_tiles(true)
		_select(public_entry)
		return
	var entry: Dictionary = TrackCatalog.random_entry(matches,selected_track.identity,rng)
	if entry.is_empty(): return
	gallery.call("_stop_snap")
	gallery.scroll_horizontal = matches.find(entry)*tile_stride
	_select(entry)

func _page_total() -> int:
	# Remote totals/cursor windows describe fetch coordinates, never empty cards.
	return matches.size()

func telemetry_exposures() -> Array[Dictionary]:
	# Count only actual cards occupying >= half their area in the active view.
	var result: Array[Dictionary] = []
	if page_preview or _view_motion != null or not is_visible_in_tree() or not is_instance_valid(gallery) or not is_instance_valid(grid): return result
	var active_gallery: ScrollContainer = track_list if list_open else gallery
	var active_grid: GridContainer = list_grid if list_open else grid
	var viewport: Rect2 = active_gallery.get_global_rect().intersection(get_viewport().get_visible_rect())
	for child: Node in active_grid.get_children():
		if not child is TrackTile or not child.is_visible_in_tree(): continue
		var card: Rect2 = child.get_global_rect()
		if card.get_area() <= 0 or viewport.intersection(card).get_area() < card.get_area()*0.5: continue
		result.append({"entry":child.entry,"position":int(child.entry.get("discovery_index",child.get_meta("catalog_index",0)))})
	return result

func _warm_visible_comparisons(first: int) -> void:
	if list_open or page_preview or cloud == null or not cloud.client.has_method("signed_in") or not cloud.client.signed_in(): return
	var entries: Array = []
	var versions: PackedStringArray = []
	var visible: int = maxi(1,ceili(gallery.size.x/maxf(1.0,tile_stride)))
	for index: int in range(first,mini(_page_total(),first+visible+2)):
		var entry: Dictionary = matches[index] if index < matches.size() else {}
		if not entry.is_empty() and entry.has("version_id"):
			if _comparison_selection == _comparison_selection_key(selected_track) and str(entry.version_id) == str(selected_track.metadata.get("cloud_version","")): continue
			entries.append(entry)
			versions.append(str(entry.version_id))
	var identity: String = VehicleCatalog.selected+"/"+"/".join(versions)
	if entries.is_empty() or _warming_window == identity: return
	_warming_window = identity
	discovery.prime_comparisons(cloud.client,entries,VehicleCatalog.selected)

func _select(entry: Dictionary) -> void:
	if selection_only:
		if not str(entry.get("version_id","" )).is_empty(): entry_chosen.emit(entry.duplicate(true))
		return
	if str(state.get("pinned_version","")) != str(entry.get("version_id","")): state.erase("pinned_version")
	var from_list: bool = list_open
	_open_track_view()
	if from_list: _reveal_track.call_deferred(str(entry.id))
	if selected_track.metadata.get("metadata_only",false) and not preview_entry.is_empty() and preview_entry.get("version_id","") == entry.get("version_id",""): return
	var cached: NativeTrack = catalog.cached_track(entry)
	if cached == selected_track and not selecting and preview_entry.is_empty() and _resolve_job == null:
		# The selected track's comparison is a snapshot, not a refresh action.
		# A newly opened page still hydrates its initially selected track once.
		if not page_preview and cloud != null and cached.metadata.has("cloud_version") and _comparison_selection != _comparison_selection_key(cached):
			_load_cloud_detail(cached)
		_show_detail()
		return
	if not page_preview and cloud != null and entry.get("source","") == "cloud" and cloud.client.has_method("signed_in") and cloud.client.signed_in():
		var nearby: Array = [entry]
		var index: int = matches.find(entry)
		if index >= 0:
			for neighbor: int in range(maxi(0,index-2),mini(matches.size(),index+4)):
				if neighbor != index: nearby.append(matches[neighbor])
		discovery.prime_comparisons(cloud.client,nearby,VehicleCatalog.selected)
	if cloud != null and cloud.client.has_method("cancel_public_reads"): cloud.client.cancel_public_reads(get_instance_id())
	var previous_id: String = str(preview_entry.get("id",selected_track.identity))
	var previous_index: int = -1
	var next_index: int = -1
	for index: int in range(matches.size()):
		if str(matches[index].id) == previous_id: previous_index = index
		if str(matches[index].id) == str(entry.id): next_index = index
	_hero_direction = -1.0 if previous_index >= 0 and next_index >= 0 and next_index < previous_index else 1.0
	_selection_serial += 1
	if _resolve_job != null: _resolve_job.cancel()
	if entry.get("source","") == "cloud":
		_detail_wait_started = Time.get_ticks_msec()
		_detail_wait_key = "metadata:"+str(_selection_serial)
	_requested_entry = {}
	if cached != null:
		_finish_selection({"track":cached,"draft":{}})
		race_button.disabled = selecting or _resolve_job != null
		if race_button.disabled: race_button.text = "Loading track..."
	else:
		selecting = true
		preview_entry = entry
		race_button.disabled = true
		race_button.text = "Loading track..."
		# Keep the complete previous section visible until the next one is ready.
		if _section_motion != null: _section_motion.kill()
		_clear_outgoing_section()
		_set_section_offset(0.0)
		hero.modulate.a = 1.0
		records_panel.modulate.a = 1.0
		if entry.source == "cloud" or from_list:
			# Public route metadata is enough to draw the hero before downloading
			# or compiling the race geometry. Old scores must not follow it.
			_show_hero(str(entry.name).to_upper(),str(entry.get("theme","pine")))
			detail.hide()
			pending_records.text = ""
			pending_records.show()
			_reveal_slow_selection(_selection_serial)
	for tile: Node in grid.get_children():
		if tile is TrackTile:
			var chosen: bool = tile.entry.id == entry.id
			if tile.selected != chosen:
				tile.selected = chosen
				tile.queue_redraw()
	if cached != null: return
	var serial: int = _selection_serial
	if entry.source == "cloud" and entry.has("version_id"):
		selected_track = cloud.presentation_track(entry) if cloud.has_method("presentation_track") else preload("res://backend/cloud_tracks.gd").metadata_track(entry)
		selecting = false
		track_selected.emit(selected_track)
		_show_detail()
		return
	if entry.source == "cloud" and cloud != null and cloud.client.has_method("signed_in") and cloud.client.signed_in():
		_show_preview_comparison(entry,serial,VehicleCatalog.selected)
	if entry.source == "cloud" and cloud != null:
		# Present the metadata before any disk validation or HTTP work.
		await get_tree().process_frame
		await get_tree().process_frame
		if not is_inside_tree() or serial != _selection_serial: return
		var downloaded: bool = await cloud.download(entry)
		if not is_inside_tree() or serial != _selection_serial: return
		if not downloaded:
			selecting = false
			pending_records.text = "Track unavailable."
			race_button.text = "Select track again to retry"
			notice.emit(cloud.last_error)
			return
	_requested_entry = entry
	_start_selection()

func _show_preview_comparison(entry: Dictionary, serial: int, vehicle: String) -> void:
	var scope: String = _comparison_scope()
	discovery.comparisons.configure(cloud.client,discovery.snapshot_cache.path+".comparisons.json" if not discovery.snapshot_cache.path.is_empty() else "",discovery.snapshot_cache.scope)
	var value: Dictionary = await discovery.comparisons.fetch(str(entry.get("version_id","")),vehicle)
	if not is_inside_tree() or scope != _comparison_scope() or (not selecting and not selected_track.metadata.get("metadata_only",false)) or serial != _selection_serial or VehicleCatalog.selected != vehicle or preview_entry.get("version_id","") != entry.get("version_id",""): return
	var snapshot: Dictionary = {}
	if value.get("packet") is Dictionary and _apply_cloud_comparison(snapshot,value.packet,selected_track if not selected_track.content_hash.is_empty() else null):
		for field: String in ["friends","board_error"]:
			if value.has(field): snapshot[field] = value[field]
		_show_detail(snapshot)
	elif selected_track.metadata.get("metadata_only",false):
		_show_detail({"comparison_error":value.get("comparison_error","Comparison unavailable")})

func _start_selection() -> void:
	if _resolve_job != null or _requested_entry.is_empty(): return
	_working_entry = _requested_entry
	_requested_entry = {}
	_working_serial = _selection_serial
	var cached: NativeTrack = catalog.cached_track(_working_entry)
	if cached != null:
		_finish_selection({"track":cached,"draft":{}})
		return
	# Bind the script's static resolver, so the worker never owns a closing UI.
	var resolver: Script = get_script()
	_resolve_job = preload("res://editor/work_job.gd").start(resolver._resolve_work.bind(library.directory,_working_entry.duplicate(true)),get_tree())
	if _resolve_job.done and _resolve_job.thread == null:
		_resolve_job = null
		selecting = false
		pending_records.text = "Track unavailable."
		race_button.text = "Select track again to retry"
		notice.emit("The track could not be loaded. Please try again.")

func _reveal_slow_selection(serial: int) -> void:
	await get_tree().create_timer(COMPARISON_NOTICE_DELAY_MS/1000.0).timeout
	if is_inside_tree() and serial == _selection_serial and selecting and not preview_entry.is_empty(): pending_records.text = "Loading..."

static func _resolve_work(cancelled: Callable, directory: String, entry: Dictionary) -> Dictionary:
	return _resolve_track(directory,entry,cancelled)

static func _resolve_track(directory: String, entry: Dictionary, cancelled: Callable = Callable()) -> Dictionary:
	if cancelled.is_valid() and cancelled.call(): return {"track":null,"draft":{}}
	if entry.source == "cloud": return {"track":preload("res://backend/cloud_tracks.gd").compile_entry(entry,cancelled),"draft":{}}
	var source := TrackLibrary.new(str(entry.get("library_directory", directory)))
	if entry.source == "builtin": return {"track":NativeTrack.read(entry.path),"draft":{}}
	var draft: Dictionary = source.load_document(entry.local_id)
	return {"track":null if draft.is_empty() else TrackCompiler.compile(draft,{},cancelled),"draft":draft}

func _process(_delta: float) -> void:
	if selection_only: return
	_poll_preparation_hint()
	if _resolve_job == null or not _resolve_job.done: return
	var result: Dictionary = _resolve_job.result
	_resolve_job = null
	if result.track != null: catalog.remember_track(_working_entry,result.track)
	if _working_serial != _selection_serial:
		_start_selection()
		if _requested_entry.is_empty() and not selecting and preview_entry.is_empty():
			race_button.disabled = not _selected_is_available()
			race_button.text = "RACE "+str(selected_track.metadata.get("title",selected_track.metadata.get("name",selected_track.identity))).to_upper() if not race_button.disabled else "Choose a track"
		return
	_finish_selection(result)

func _poll_preparation_hint() -> void:
	if page_preview or list_open or not is_visible_in_tree() or _view_motion != null or _section_motion != null or selecting or selected_track == null:
		_preparation_since = 0
		return
	var key: Array = [selected_track.get_instance_id(),_selection_serial,VehicleCatalog.selected,str(selected_track.metadata.get("cloud_version",""))]
	if key != _preparation_key:
		_preparation_key = key; _preparation_since = 0; _preparation_sent = false
	if _preparation_sent: return
	if _preparation_since == 0: _preparation_since = Time.get_ticks_msec(); return
	if Time.get_ticks_msec()-_preparation_since < PREPARATION_SETTLE_MS: return
	_preparation_sent = true
	preparation_requested.emit(selected_track)

func _exit_tree() -> void:
	discovery.comparisons.cancel_speculation()
	_selection_serial += 1
	if _view_motion != null:
		_view_motion.kill()
		_set_view_progress(0.0 if list_open else 1.0)
		_finish_view_transition()
	if cloud != null and cloud.client.has_method("cancel_public_reads"): cloud.client.cancel_public_reads(get_instance_id())
	if _resolve_job != null:
		# The tree-owned reaper joins completed workers independently of this UI.
		_resolve_job.cancel()
		_resolve_job = null

func _finish_selection(result: Dictionary) -> void:
	var track: NativeTrack = result.track
	if track == null:
		selecting = false
		race_button.disabled = true
		race_button.text = "Select track again to retry"
		var draft: Dictionary = result.draft
		if not draft.is_empty():
			race_button.text = "Track needs repair"
			pending_records.hide()
			detail.show()
			_clear(detail)
			var draft_title := MenuStyle.label(str(draft.name)+" - draft",23)
			draft_title.clip_text = true
			draft_title.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
			draft_title.tooltip_text = draft_title.text
			detail.add_child(draft_title)
			var errors: Array[String] = TrackDocument.validate(draft)
			var issue := MenuStyle.label(errors[0] if not errors.is_empty() else "Track needs repair before driving.",18,true)
			issue.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			detail.add_child(issue)
			detail.add_child(MenuStyle.label("Open Create to repair this draft.",18,true))
			return
		pending_records.text = "Track unavailable."
		notice.emit("This track could not be opened. Its saved route may need repair or reimporting.")
		return
	selected_track = track
	selecting = false
	preview_entry = {}
	pending_records.hide()
	detail.show()
	track_selected.emit(track)
	_show_detail()

func _comparison_selection_key(track: NativeTrack) -> String:
	var local: Dictionary = records.records.get(records.key_for(track,HandlingSelection.config()),{}) if not track.content_hash.is_empty() else {}
	return "%d:%s:%d:%d:%d" % [track.get_instance_id(),VehicleCatalog.selected,_selection_serial,int(local.get("race_ms",0)),int(local.get("flying_ms",0))]

func _comparison_scope() -> String:
	var origin: String = str(cloud.client.base_url()) if cloud.client.has_method("base_url") else ""
	var raw: Variant = cloud.client.get("player")
	var owner: String = str(raw.get("id","")) if raw is Dictionary else ""
	return str([origin,owner,discovery.snapshot_cache.scope])

func _comparison_warmed(identity: String) -> void:
	if page_preview or not selected_track.metadata.get("metadata_only",false): return
	if identity == discovery.comparisons.key(str(selected_track.metadata.cloud_version),VehicleCatalog.selected):
		_comparison_selection = ""
		_show_detail()

func _load_cloud_detail(track: NativeTrack) -> void:
	var scope: String = _comparison_scope()
	var serial: int = _selection_serial
	var vehicle: String = VehicleCatalog.selected
	var key: String = records.key_for(track,HandlingSelection.config())
	var request_key: String = _comparison_selection_key(track)
	if _cloud_detail_pending.has(request_key): return
	_comparison_selection = request_key
	_comparison_attempts[request_key] = Time.get_ticks_msec()
	while _comparison_attempts.size() > 32: _comparison_attempts.erase(_comparison_attempts.keys()[0])
	_cloud_detail_pending[request_key] = true
	if _detail_wait_key != request_key:
		_detail_wait_key = request_key
		_detail_wait_started = Time.get_ticks_msec()
		_reveal_slow_comparison(request_key)
	cloud.client.cancel_public_reads(get_instance_id())
	var snapshot: Dictionary = discovery.record_snapshot(key)
	var had_comparison: bool = _comparison_ready(snapshot)
	var preloader = discovery.comparisons
	preloader.configure(cloud.client,discovery.snapshot_cache.path+".comparisons.json" if not discovery.snapshot_cache.path.is_empty() else "",discovery.snapshot_cache.scope)
	var warmed: Dictionary = preloader.peek(str(track.metadata.cloud_version),vehicle)
	if not had_comparison and warmed.get("packet") is Dictionary and _apply_cloud_comparison(snapshot,warmed.packet,track):
		for field: String in ["friends","board_error"]:
			if warmed.has(field): snapshot[field] = warmed[field]
		discovery.remember_record(key,snapshot)
	# The score list and distributions are independent. Neither read waits for
	# the other, and neither holds the already resolved hero offscreen.
	_load_cloud_leaderboard(track,serial,vehicle,key)
	if snapshot.get("comparison_scope","") != "all" or int(snapshot.get("comparison_bins",0)) != RaceComplete.COMPARISON_BINS:
		for obsolete: String in ["race_distribution","lap_distribution","race_rank","race_top_percent","test_population","population"]: snapshot.erase(obsolete)
	if cloud.client.signed_in():
		var local: Dictionary = records.records.get(key,{})
		var race_ms: int = _personal_best_ms(snapshot,local,"race")
		var lap_ms: int = _personal_best_ms(snapshot,local,"lap")
		var race_ticks: int = roundi(float(race_ms)*VehicleSimulation.TICK_RATE/1000.0) if race_ms > 0 else 0
		var lap_ticks: int = roundi(float(lap_ms)*VehicleSimulation.TICK_RATE/1000.0) if lap_ms > 0 else 0
		var comparison: Dictionary = await preloader.comparison(str(track.metadata.cloud_version),vehicle,race_ticks,lap_ticks,[race_ticks,lap_ticks],_snapshot_frame(snapshot))
		if not is_inside_tree() or scope != _comparison_scope() or track != selected_track or serial != _selection_serial or VehicleCatalog.selected != vehicle or request_key != _comparison_selection_key(track):
			_cloud_detail_pending.erase(request_key)
			return
		# The leaderboard may have completed while the histogram was in flight.
		var latest: Dictionary = discovery.record_snapshot(key)
		for field: String in ["friends","board_error"]:
			if latest.has(field): snapshot[field] = latest[field]
			elif warmed.has(field): snapshot[field] = warmed[field]
		if not comparison.ok or not _apply_cloud_comparison(snapshot,comparison.data,track):
			snapshot.comparison_error = "Comparison unavailable"
	else:
		snapshot.comparison_error = "Sign in to compare"
	_cloud_detail_pending.erase(request_key)
	discovery.remember_record(key,snapshot)
	if is_inside_tree() and serial == _selection_serial: _show_detail()

func _reveal_slow_comparison(request_key: String) -> void:
	await get_tree().create_timer(COMPARISON_NOTICE_DELAY_MS/1000.0).timeout
	if is_inside_tree() and _detail_wait_key == request_key:
		var snapshot: Dictionary = discovery.record_snapshot(records.key_for(selected_track,HandlingSelection.config()))
		if _cloud_detail_pending.has(request_key) or not snapshot.has("friends"): _show_detail()

func _load_cloud_leaderboard(track: NativeTrack, serial: int, vehicle: String, key: String) -> void:
	var scope: String = _comparison_scope()
	var preloader = discovery.comparisons
	var version: String = str(track.metadata.cloud_version)
	var shared: Dictionary = preloader.peek(version,vehicle)
	if shared.has("friends") or preloader.board_pending(version,vehicle):
		while not shared.has("friends") and preloader.board_pending(version,vehicle):
			await preloader.completed
			if not is_inside_tree() or scope != _comparison_scope() or track != selected_track or serial != _selection_serial or VehicleCatalog.selected != vehicle: return
			shared = preloader.peek(version,vehicle)
		if shared.has("friends"):
			var snapshot: Dictionary = discovery.record_snapshot(key)
			snapshot.friends = shared.friends
			snapshot.board_error = shared.get("board_error","")
			discovery.remember_record(key,snapshot)
			if is_inside_tree() and serial == _selection_serial: _show_detail()
			return
	var response: Dictionary = await cloud.client.request_public("/track-versions/"+str(track.metadata.cloud_version)+"/leaderboard?vehicle_id="+vehicle.uri_encode()+"&limit=3",get_instance_id())
	if not is_inside_tree() or scope != _comparison_scope() or track != selected_track or serial != _selection_serial or VehicleCatalog.selected != vehicle:
		return
	var standings: Array = []
	if response.ok:
		for item: Dictionary in response.data.items:
			standings.append({"player":"%d. %s" % [int(item.rank),str(item.display_name)],"country_code":str(item.get("country_code","")),"race_ms":float(item.time_ticks)*1000.0/120.0})
	var snapshot: Dictionary = discovery.record_snapshot(key)
	snapshot.friends = standings
	snapshot.board_error = "" if response.ok else str(response.error)
	preloader.remember_board(version,vehicle,standings,str(snapshot.board_error))
	discovery.remember_record(key,snapshot)
	if is_inside_tree() and serial == _selection_serial: _show_detail()

func _apply_cloud_comparison(snapshot: Dictionary, data: Dictionary, track: NativeTrack) -> bool:
	if data.get("population_scope","") != "all" or not data.get("race") is Dictionary or not data.get("best_lap") is Dictionary: return false
	var board: String = str(data.get("board_id",""))
	if not RaceComplete._valid_distribution(data.race,"race",board) or not RaceComplete._valid_distribution(data.best_lap,"best_lap",board): return false
	var key: String = records.key_for(track,HandlingSelection.config()) if track != null else ""
	var local: Dictionary = records.records.get(key,{}) if track != null else {}
	for metric: String in ["race","best_lap"]:
		var histogram: Dictionary = data[metric]
		var counts: Array[int] = []
		var edges: Array[float] = []
		for bin: Dictionary in histogram.bins:
			counts.append(int(bin.count))
			edges.append(float(bin.from_ticks)*1000.0/VehicleSimulation.TICK_RATE)
		if not histogram.bins.is_empty(): edges.append(float(histogram.bins[-1].to_ticks_exclusive)*1000.0/VehicleSimulation.TICK_RATE)
		var own: float = float(local.get("race_ms" if metric == "race" else "flying_ms",0))
		if histogram.get("own_best_ticks") != null:
			var verified: float = float(histogram.own_best_ticks)*1000.0/VehicleSimulation.TICK_RATE
			own = minf(own,verified) if own > 0 else verified
		var markers: Array[Dictionary] = []
		if own > 0: markers.append({"value_ms":roundi(own),"label":"YOU","color":MenuStyle.ACCENT})
		var low: float = float(histogram.minimum_ticks) if histogram.get("minimum_ticks") != null else 0.0
		var high: float = float(histogram.maximum_ticks) if histogram.get("maximum_ticks") != null else 0.0
		var prefix: String = "race" if metric == "race" else "lap"
		snapshot[prefix+"_distribution"] = {"bins":counts,"edges_ms":edges,"min_ms":low*1000.0/VehicleSimulation.TICK_RATE,"max_ms":high*1000.0/VehicleSimulation.TICK_RATE,"markers":markers}
		if own > 0: snapshot[prefix+"_ms"] = roundi(own)
		snapshot[prefix+"_comparison"] = histogram.get("comparison")
		if metric == "race" and histogram.get("comparison") is Dictionary:
			snapshot.race_rank = int(histogram.comparison.position)
			snapshot.race_top_percent = int(histogram.comparison.top_percent)
			snapshot.population = int(histogram.comparison.population)
	snapshot.comparison_scope = "all"
	snapshot.comparison_bins = RaceComplete.COMPARISON_BINS
	snapshot._comparison_packet = data.duplicate(true)
	var retained: Dictionary = discovery.comparisons.peek(str(track.metadata.get("cloud_version","")),VehicleCatalog.selected) if track != null else {}
	snapshot._comparison_fetched_at = int(retained.get("_fetched_at",Time.get_unix_time_from_system()))
	snapshot.erase("comparison_error")
	snapshot.erase("test_population")
	_align_personal_comparison(snapshot,local)
	return true

static func _personal_best_ms(snapshot: Dictionary, local: Dictionary, metric: String) -> int:
	var cached: int = int(snapshot.get(metric+"_ms",0))
	var own: int = int(local.get("race_ms" if metric == "race" else "flying_ms",0))
	return mini(cached,own) if cached > 0 and own > 0 else maxi(cached,own)

static func _align_personal_comparison(snapshot: Dictionary, local: Dictionary) -> void:
	for metric: String in ["race","lap"]:
		var own: int = _personal_best_ms(snapshot,local,metric)
		if own <= 0: continue
		snapshot[metric+"_ms"] = own
		if snapshot.get(metric+"_distribution") is Dictionary:
			snapshot[metric+"_distribution"].markers = [{"value_ms":own,"label":"YOU","color":MenuStyle.ACCENT}]
		var comparison: Variant = snapshot.get(metric+"_comparison")
		# Warmed/disk packets may rank an older verified PB. Never attach that
		# placement to a faster local marker or infer an exact rank from bins.
		if comparison is Dictionary and int(comparison.get("candidate_ticks",0)) != roundi(float(own)*VehicleSimulation.TICK_RATE/1000.0):
			snapshot[metric+"_comparison"] = null
			if metric == "race":
				for field: String in ["race_rank","race_top_percent","population"]: snapshot.erase(field)

static func _comparison_ready(snapshot: Dictionary) -> bool:
	return snapshot.get("comparison_scope","") == "all" and int(snapshot.get("comparison_bins",0)) == RaceComplete.COMPARISON_BINS and snapshot.get("race_distribution") is Dictionary and snapshot.get("lap_distribution") is Dictionary

static func _cached_frame_query(distribution: Dictionary, metric: String) -> String:
	var edges: Array = distribution.get("edges_ms",[])
	if edges.size() < 2: return ""
	return "&%s_from_ticks=%d&%s_to_ticks=%d" % [metric,roundi(float(edges[0])*VehicleSimulation.TICK_RATE/1000.0),metric,roundi(float(edges[-1])*VehicleSimulation.TICK_RATE/1000.0)]

static func _snapshot_frame(snapshot: Dictionary) -> Dictionary:
	if snapshot.get("_comparison_packet") is Dictionary: return snapshot._comparison_packet
	var result: Dictionary = {}
	for pair: Array in [["race","race_distribution"],["best_lap","lap_distribution"]]:
		var edges: Array = snapshot.get(pair[1],{}).get("edges_ms",[])
		if edges.size() >= 2: result[pair[0]] = {"bins":[{"from_ticks":roundi(float(edges[0])*VehicleSimulation.TICK_RATE/1000.0),"to_ticks_exclusive":roundi(float(edges[-1])*VehicleSimulation.TICK_RATE/1000.0)}]}
	return result

func _comparison_expired(snapshot: Dictionary, request_key: String) -> bool:
	if snapshot.has("comparison_error") or Time.get_ticks_msec()-int(_comparison_attempts.get(request_key,-30000)) < 30000: return false
	return not COMPARISON_REUSE.fresh({"packet":snapshot.get("_comparison_packet",{}),"_fetched_at":snapshot.get("_comparison_fetched_at",0)})

func _open_scores() -> void:
	var dialog := preload("res://ui/cloud_leaderboard.gd").new()
	dialog.client = cloud.client
	dialog.version = str(preview_entry.get("version_id",selected_track.metadata.cloud_version))
	dialog.vehicle = VehicleCatalog.selected
	add_child(dialog)
	dialog.confirmed.connect(dialog.queue_free)
	dialog.canceled.connect(dialog.queue_free)
	dialog.popup_centered()

func _discovery_changed() -> void:
	if page_preview:
		_page_dirty = true
		return
	_refresh()
	if not selecting: _show_detail()

func _build_actions() -> void:
	var actions: Container = GridContainer.new() if selection_only else HBoxContainer.new()
	if selection_only:
		_selection_actions = actions as GridContainer
		_selection_actions.columns = 2 if get_viewport_rect().size.x < 720 else 4
		_selection_actions.add_theme_constant_override("h_separation",8)
		_selection_actions.add_theme_constant_override("v_separation",8)
		resized.connect(func() -> void: _selection_actions.columns = 2 if size.x < 720 else 4)
	actions.name = "PlayActions"
	add_child(actions)
	random_button = MenuStyle.button("Random track",_random)
	random_button.icon = MenuIcon.texture("dice")
	random_button.name = "RandomTrack"
	actions.add_child(random_button)
	var filters := MenuStyle.button("Filters",func() -> void:
		gallery.call("_stop_snap")
		gallery.set_process_input(false)
		track_list.set_process_input(false)
		filter_dialog.open_for(state,filter_button))
	filter_button = filters
	filters.name = "RaceFilters"
	filters.icon = MenuIcon.texture("filter")
	actions.add_child(filters)
	var search := MenuStyle.button("Search",func() -> void:
		gallery.call("_stop_snap")
		gallery.set_process_input(false)
		track_list.set_process_input(false)
		search_dialog.open_for(state,find_child("RaceSearch",true,false)))
	search.name = "RaceSearch"
	search.icon = MenuIcon.texture("search")
	actions.add_child(search)
	for button: Button in [random_button,filters,search]:
		button.custom_minimum_size = Vector2(0 if selection_only else 196,60)
		button.size_flags_horizontal = Control.SIZE_EXPAND_FILL if selection_only else Control.SIZE_FILL
		if selection_only:
			button.clip_text = true
			button.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	race_button = MenuStyle.button("RACE",func() -> void: race_requested.emit(selected_track),true)
	race_button.name = "LibraryRace"
	race_button.icon = MenuIcon.texture("arrow")
	race_button.icon_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	race_button.add_theme_color_override("icon_normal_color",MenuStyle.INK)
	race_button.add_theme_color_override("icon_hover_color",MenuStyle.INK)
	race_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	race_button.clip_text = true
	race_button.custom_minimum_size = Vector2(240,60)
	race_button.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	actions.add_child(race_button)

func _heading(parent: Control, caption: String, icon: String) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation",8)
	parent.add_child(row)
	var indent := Control.new()
	indent.custom_minimum_size.x = 4
	row.add_child(indent)
	row.add_child(ResultsIcons.view(icon,20))
	var label := MenuStyle.label(caption,21,true)
	label.add_theme_font_override("font",MenuStyle.DISPLAY)
	row.add_child(label)
	return row

func _show_detail(preview_snapshot: Dictionary = {}) -> void:
	if selection_only: return
	if list_open: return
	if selected_track.metadata.get("metadata_only",false) and preview_snapshot.is_empty():
		if preview_entry.is_empty(): preview_entry = selected_track.metadata.cloud_entry.duplicate(true)
		var known_contract: bool = not selected_track.content_hash.is_empty()
		var rules_key: String = records.key_for(selected_track,HandlingSelection.config()) if known_contract else ""
		var snapshot: Dictionary = discovery.record_snapshot(rules_key) if known_contract else {}
		var warmed: Dictionary = discovery.comparisons.peek(str(selected_track.metadata.cloud_version),VehicleCatalog.selected)
		if not _comparison_ready(snapshot) and warmed.get("packet") is Dictionary:
			_apply_cloud_comparison(snapshot,warmed.packet,selected_track if known_contract else null)
		for field: String in ["friends","board_error","comparison_error"]:
			if not snapshot.has(field) and warmed.has(field): snapshot[field] = warmed[field]
		if not page_preview and cloud.client.signed_in():
			var request_key: String = _comparison_selection_key(selected_track)
			if _comparison_selection != request_key or (known_contract and not _cloud_detail_pending.has(request_key) and _comparison_expired(snapshot,request_key)):
				if known_contract: _load_cloud_detail(selected_track)
				else:
					_comparison_selection = request_key
					_show_preview_comparison(preview_entry,_selection_serial,VehicleCatalog.selected)
		elif not cloud.client.signed_in(): snapshot.comparison_error = "Sign in to compare"
		# Known PB contracts keep candidate percentiles and retained histogram
		# frames through the existing read-model path, without compiling geometry.
		if known_contract:
			var latest: Dictionary = discovery.record_snapshot(rules_key)
			if not latest.is_empty(): snapshot = latest
		snapshot._metadata_pending = true
		_show_detail(snapshot)
		return
	var metadata_only: bool = not preview_snapshot.is_empty()
	if (selecting or not preview_entry.is_empty()) and not metadata_only: return
	var key: String = records.key_for(selected_track,HandlingSelection.config()) if not metadata_only else "preview:"+str(preview_entry.get("version_id",""))
	# Metadata-only cloud views can already have a verified PB rules key. Pin
	# that stored record rather than their temporary preview identity.
	discovery.pin_record(records.key_for(selected_track,HandlingSelection.config()) if metadata_only and not selected_track.content_hash.is_empty() else key)
	var pb: Dictionary = records.records.get(key,{}) if not metadata_only else records.records.get(records.key_for(selected_track,HandlingSelection.config()),{}) if not selected_track.content_hash.is_empty() else {}
	var snapshot: Dictionary = discovery.record_snapshot(key) if not metadata_only else preview_snapshot
	_align_personal_comparison(snapshot,pb)
	var metadata: Dictionary = selected_track.metadata if not metadata_only else preview_entry
	var cloud_version: String = str(metadata.get("cloud_version" if not metadata_only else "version_id",""))
	# A restored selection can open without any tile selection event. Start its
	# one comparison read when the actual page is visible, including promotion.
	if not metadata_only and not page_preview and cloud != null and selected_track.metadata.has("cloud_version") and _selected_is_available():
		var request_key: String = _comparison_selection_key(selected_track)
		var unresolved: bool = (not _comparison_ready(snapshot) or _comparison_expired(snapshot,request_key)) and not snapshot.has("comparison_error") and not _cloud_detail_pending.has(request_key)
		if _comparison_selection != request_key or unresolved:
			_load_cloud_detail(selected_track)
			snapshot = discovery.record_snapshot(key)
			_align_personal_comparison(snapshot,pb)
	# An old-resolution cache must not flash before the fresh grid arrives.
	if int(snapshot.get("comparison_bins",0)) != RaceComplete.COMPARISON_BINS:
		snapshot.erase("race_distribution")
		snapshot.erase("lap_distribution")
	var available: bool = _selected_is_available() if not metadata_only else true
	if cloud != null and not cloud_version.is_empty() and not _comparison_ready(snapshot) and not cloud.client.signed_in():
		snapshot.comparison_error = "Sign in to compare"
	var waiting: bool = available and cloud != null and not cloud_version.is_empty() and not _comparison_ready(snapshot) and not snapshot.has("comparison_error")
	var board_pending: bool = available and not cloud_version.is_empty() and not snapshot.has("friends")
	var exceptional_wait: bool = (waiting or board_pending) and _detail_wait_started > 0 and Time.get_ticks_msec()-_detail_wait_started >= COMPARISON_NOTICE_DELAY_MS
	if waiting != _detail_loading:
		_detail_loading = waiting
		_detail_state = []
	pending_records.hide()
	detail.show()
	var current: Array = [selected_track,key,available,pb,snapshot,cloud_version,exceptional_wait]
	if current == _detail_state:
		_show_hero(str(metadata.get("title",metadata.get("name",selected_track.identity))).to_upper() if available else "CHOOSE A TRACK",str(metadata.get("theme","pine")) if available else "pine")
		return
	_detail_state = current.duplicate(true)
	if not available:
		_clear(detail)
		_show_hero("CHOOSE A TRACK","pine")
		if matches.is_empty() and not loading and (cloud == null or not cloud.refreshing) and (cloud == null or not cloud.paged_discovery_available() or (is_instance_valid(cloud.discovery_pages) and cloud.discovery_pages.total >= 0)):
			detail.add_child(MenuStyle.label("Connect to load published tracks. Downloaded tracks remain available offline.",18,true))
		if is_instance_valid(race_button):
			race_button.disabled = true
			race_button.text = "Choose a track"
		return
	_prepare_outgoing_section()
	var comparison_view_key: String = JSON.stringify([cloud_version if not cloud_version.is_empty() else key,VehicleCatalog.selected,_comparison_scope() if cloud != null else ""])
	var retained_distribution: VBoxContainer = _retain_comparison_view(comparison_view_key,snapshot)
	_clear(detail)
	var row := HBoxContainer.new()
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	row.add_theme_constant_override("separation",12)
	detail.add_child(row)
	var title: String = str(metadata.get("title",metadata.get("name",selected_track.identity))).to_upper()
	var theme_id: String = str(metadata.get("theme","pine"))
	_show_hero(title,theme_id)
	var personal := VBoxContainer.new()
	personal.custom_minimum_size.x = 0
	personal.add_theme_constant_override("separation",2)
	_fixed_column(row,personal,"PersonalRecords",230)
	_heading(personal,"YOUR RECORDS","timer")
	var personal_body: VBoxContainer = _section_body(personal)
	var best_ms: int = int(snapshot.get("race_ms",pb.get("race_ms",0)))
	if best_ms <= 0:
		var empty_time := MenuStyle.label("No time yet",18)
		empty_time.name = "LibraryBestTime"
		if not metadata_only:
			personal_body.add_child(empty_time)
			_friendly_hint(personal_body,"Set your first record and see how you perform.")
		else: empty_time.free() # Local PBs are unresolved until pinned compilation finishes.
	else:
		personal_body.add_child(MenuStyle.label("Best race time",14,true))
		var timer := MenuStyle.label(MenuStyle.time_text(best_ms/1000.0),26)
		timer.name = "LibraryBestTime"
		timer.add_theme_color_override("font_color",MenuStyle.ACCENT)
		personal_body.add_child(timer)
		var placement: String = RaceComplete._position_text(snapshot.get("race_comparison"))
		if not placement.is_empty(): personal_body.add_child(MenuStyle.label(placement,12,true))
		var lap_ms: int = int(snapshot.get("lap_ms",pb.get("flying_ms",0)))
		if lap_ms > 0:
			personal_body.add_child(MenuStyle.label("Best lap  "+MenuStyle.time_text(float(lap_ms)/1000.0),16,true))
	row.add_child(VSeparator.new())
	row.add_child(retained_distribution if retained_distribution != null else _build_comparison_view(snapshot,waiting,exceptional_wait))
	_comparison_view_key = comparison_view_key
	row.add_child(VSeparator.new())
	var friends := VBoxContainer.new()
	friends.custom_minimum_size.x = 0
	friends.add_theme_constant_override("separation",8)
	if not cloud_version.is_empty(): friends.add_theme_constant_override("separation",2)
	_fixed_column(row,friends,"Standings",270)
	_heading(friends,"HIGH SCORES" if not cloud_version.is_empty() else "FRIENDS","friends")
	var friends_body: VBoxContainer = _section_body(friends)
	var standings: Array = snapshot.get("friends",[])
	if standings.is_empty():
		var board_waiting: bool = not cloud_version.is_empty() and not snapshot.has("friends")
		if not board_waiting or exceptional_wait: friends_body.add_child(MenuStyle.label("Loading..." if board_waiting else "Scores unavailable" if not str(snapshot.get("board_error","")).is_empty() else "No times yet" if not cloud_version.is_empty() else "No friend times",18))
		if not board_waiting and str(snapshot.get("board_error","")).is_empty(): _friendly_hint(friends_body,"Be the first to set a time!" if not cloud_version.is_empty() else "Share this track and challenge a friend.")
	else:
		for index: int in range(mini(3,standings.size())):
			var friend: Dictionary = standings[index]
			var identity := HBoxContainer.new()
			identity.add_theme_constant_override("separation",6)
			friends_body.add_child(identity)
			identity.add_child(PlayerCountry.flag(str(friend.get("country_code","")),20))
			var line := MenuStyle.label("%s  %s" % [str(friend.player),MenuStyle.time_text(float(friend.race_ms)/1000)],12)
			line.clip_text = true
			line.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			identity.add_child(line)
	if not cloud_version.is_empty():
		var actions := HBoxContainer.new()
		friends_body.add_child(actions)
		var scores_button := MenuStyle.button("High scores",_open_scores)
		scores_button.add_theme_font_size_override("font_size",18)
		scores_button.custom_minimum_size.y = 48
		scores_button.disabled = metadata_only and not selected_track.metadata.get("metadata_only",false)
		actions.add_child(scores_button)
		var rate := MenuStyle.button("Rate",_open_rating)
		rate.add_theme_font_size_override("font_size",18)
		rate.custom_minimum_size.y = 48
		rate.disabled = metadata_only and not selected_track.metadata.get("metadata_only",false)
		actions.add_child(rate)
		var safety_button := MenuStyle.button("Report / block",func() -> void: preload("res://ui/community_safety_ui.gd").open(self,cloud.client,"track",preload("res://ui/community_safety_ui.gd").track_target(selected_track)))
		safety_button.name = "TrackSafety"
		safety_button.add_theme_font_size_override("font_size",18)
		safety_button.custom_minimum_size.y = 48
		actions.add_child(safety_button)
		if not str(snapshot.get("board_error","")).is_empty(): scores_button.tooltip_text = "Scores unavailable - retry"
		# Reserve the complete action row and its section insets in the clipped slot.
		friends.get_parent().custom_minimum_size.x = maxf(270.0,friends.get_combined_minimum_size().x)
	race_button.text = "RACE "+title
	race_button.disabled = selecting or _resolve_job != null or (metadata_only and not selected_track.metadata.get("metadata_only",false))
	if race_button.disabled: race_button.text = "Loading track..."
	detail_costs = {"preview":0.0}

func _retain_comparison_view(view_key: String, snapshot: Dictionary) -> VBoxContainer:
	if view_key != _comparison_view_key: return null
	if not _comparison_ready(snapshot) and snapshot.has("comparison_error"): return null
	var distribution: VBoxContainer = detail.find_child("RaceComparison",true,false) as VBoxContainer
	if distribution == null: return null
	# Keep laid-out controls through metadata promotion and unrelated score/PB
	# updates. A confirmed empty metric still needs its proper empty-state layout.
	for metric: String in ["race","lap"]:
		var chart: TrackDistribution = distribution.find_child("RaceDistribution" if metric == "race" else "LapDistribution",true,false)
		if chart == null or chart.snapshot.get("bins",[]).is_empty(): return null
		if _comparison_ready(snapshot) and snapshot[metric+"_distribution"].get("bins",[]).is_empty(): return null
	if _comparison_ready(snapshot):
		for metric: String in ["race","lap"]:
			var chart: TrackDistribution = distribution.find_child("RaceDistribution" if metric == "race" else "LapDistribution",true,false)
			var fresh: Dictionary = snapshot[metric+"_distribution"]
			if chart.snapshot != fresh:
				chart.snapshot = fresh.duplicate(true)
				chart.queue_redraw()
	distribution.get_parent().remove_child(distribution)
	return distribution

func _build_comparison_view(snapshot: Dictionary, waiting: bool, exceptional_wait: bool) -> VBoxContainer:
	var distribution := VBoxContainer.new()
	distribution.name = "RaceComparison"
	distribution.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	distribution.size_flags_stretch_ratio = 1.4
	distribution.add_theme_constant_override("separation",2)
	_heading(distribution,"WHERE YOU STAND","podium")
	var distribution_body: VBoxContainer = _section_body(distribution)
	var charts := HBoxContainer.new()
	charts.size_flags_vertical = Control.SIZE_EXPAND_FILL
	charts.add_theme_constant_override("separation",8)
	distribution_body.add_child(charts)
	for metric: String in ["race","lap"]:
		var card := PanelContainer.new()
		card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		card.add_theme_stylebox_override("panel",MenuStyle.box(Color.TRANSPARENT,0))
		charts.add_child(card)
		var column := VBoxContainer.new()
		column.add_theme_constant_override("separation",4)
		card.add_child(column)
		column.add_child(MenuStyle.label("Race" if metric == "race" else "Lap",12,true))
		var histogram := TrackDistribution.new()
		histogram.name = "RaceDistribution" if metric == "race" else "LapDistribution"
		histogram.snapshot = snapshot.get(metric+"_distribution",{}).duplicate(true)
		if histogram.snapshot.get("bins",[]).is_empty():
			histogram.hide()
			if not waiting or (exceptional_wait and metric == "race"): column.add_child(MenuStyle.label("Loading..." if waiting else str(snapshot.get("comparison_error","No times yet")),12,true))
		histogram.bar_color = Color("41667b") if metric == "race" else Color("42865d")
		histogram.custom_minimum_size = Vector2(112,96)
		histogram.size_flags_vertical = Control.SIZE_EXPAND_FILL
		column.add_child(histogram)
	return distribution

func _open_rating() -> void:
	var dialog := AcceptDialog.new()
	dialog.title = "Rate this track"
	add_child(dialog)
	preload("res://ui/popup_style.gd").watch(dialog)
	var column := VBoxContainer.new()
	dialog.add_child(column)
	var rating := TrackRating.new()
	rating.records = records
	rating.track_id = selected_track.identity
	rating.cloud_client = cloud.client if cloud != null else null
	rating.cloud_version = str(selected_track.metadata.cloud_version)
	rating.cloud_sync = cloud
	column.add_child(rating)
	rating.caption.reparent(column)
	if cloud != null: rating.rated.connect(func() -> void: cloud.refresh(true))
	dialog.confirmed.connect(dialog.queue_free)
	dialog.canceled.connect(dialog.queue_free)
	dialog.popup_centered()

func _favorite() -> void:
	if selecting: return
	_favorite_id(str(preview_entry.get("id",selected_track.identity)))
	_show_hero(str(selected_track.metadata.get("title",selected_track.metadata.get("name",selected_track.identity))).to_upper(),str(selected_track.metadata.get("theme","pine")))

func _favorite_id(id: String) -> void:
	var favorites: Array = records.settings.get("favorites",[]).duplicate()
	if id in favorites: favorites.erase(id)
	else: favorites.append(id)
	records.settings.favorites = favorites
	if records.save_records() != OK: notice.emit("Favorite could not be saved. Check available storage.")
	_refresh()
	if id == selected_track.identity: _show_hero(str(selected_track.metadata.get("title",selected_track.metadata.get("name",selected_track.identity))).to_upper(),str(selected_track.metadata.get("theme","pine")))

func _build_mode_rail(parent: Control) -> void:
	if selection_only: return
	var rail := RaceModeRail.new()
	rail.mode_requested.connect(func(mode: String) -> void:
		if mode == "rivalry": rivalry_requested.emit()
		elif mode == "challenges": challenges_requested.emit()
		elif mode == "daily": daily_requested.emit())
	parent.add_child(rail)

func _show_hero(title: String, theme_id: String) -> void:
	if list_open: return
	var rating_entry: Dictionary = preview_entry
	if rating_entry.is_empty():
		for candidate: Dictionary in catalog.entries:
			if str(candidate.id) == selected_track.identity:
				rating_entry = candidate
				break
	var current: Array = [selected_track,_selection_serial,title,theme_id,preview_entry,records.settings.get("favorites",[]),records.settings.get("track_ratings",{}),rating_entry]
	if current == _hero_state: return
	_hero_state = current.duplicate(true)
	_prepare_outgoing_section()
	if not preview_entry.is_empty():
		title = str(preview_entry.name).to_upper()
		theme_id = str(preview_entry.get("theme","pine"))
	var hero_points: PackedVector2Array = selected_track.route
	var hero_length: float = selected_track.route_length
	var hero_creator: String = str(selected_track.metadata.get("cloud_creator",selected_track.metadata.get("creator_document",{}).get("creator",selected_track.metadata.get("creator","Unknown creator"))))
	if not preview_entry.is_empty():
		hero_creator = str(preview_entry.get("creator","Unknown creator"))
		hero_points = PackedVector2Array()
		for point: Array in preview_entry.get("points",[]): hero_points.append(Vector2(point[0],point[1]))
		hero_length = 0.0
		for index: int in range(hero_points.size()): hero_length += hero_points[index].distance_to(hero_points[(index+1)%hero_points.size()])
	var animate: bool = _hero_serial >= 0 and _hero_serial != _selection_serial
	_hero_serial = _selection_serial
	if _hero_scenery != null: hero.remove_child(_hero_scenery)
	_clear(hero)
	if _hero_scenery == null:
		_hero_scenery = Control.new()
		_hero_scenery.name = "HeroSceneryLayers"
		_hero_scenery.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_hero_scenery.clip_contents = true
	hero.add_child(_hero_scenery)
	var art := TextureRect.new()
	art.name = "SelectedTrackScenery"
	art.texture = TrackTile.scenery_texture(theme_id)
	art.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	art.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	art.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_clear(_hero_scenery)
	_hero_scenery.add_child(art)
	MenuStyle.fill(art)
	_hero_art = art
	var shade := ColorRect.new()
	shade.color = Color(0.02,0.05,0.07,0.38)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hero.add_child(shade)
	var inset := MarginContainer.new()
	for side: String in ["left","right","top","bottom"]: inset.add_theme_constant_override("margin_"+side,24 if side in ["left","right"] else 16)
	hero.add_child(inset)
	var row := HBoxContainer.new()
	inset.add_child(row)
	var info := VBoxContainer.new()
	info.add_theme_constant_override("separation",0)
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(info)
	var spacer := Control.new()
	spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	info.add_child(spacer)
	info.add_child(preload("res://ui/biome_badge.gd").view(theme_id,16))
	var heading := MenuStyle.user_label(title,60)
	heading.name = "HeroTrackTitle"
	var title_width: float = MenuStyle.DISPLAY.get_string_size(title,HORIZONTAL_ALIGNMENT_LEFT,-1,60).x
	heading.clip_text = true
	heading.tooltip_text = title
	heading.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var title_slot := Control.new()
	title_slot.custom_minimum_size.y = MenuStyle.DISPLAY.get_height(60)
	info.add_child(title_slot)
	var title_row := HBoxContainer.new()
	title_row.add_theme_constant_override("separation",12)
	title_slot.add_child(title_row)
	title_row.add_child(heading)
	var creator := MenuStyle.button(hero_creator,_show_creator_tracks.bind(hero_creator))
	GameText.user_text(creator)
	creator.name = "HeroCreatorLink"
	creator.clip_text = true
	creator.tooltip_text = "Show tracks by "+hero_creator
	creator.add_theme_font_override("font",MenuStyle.BODY)
	creator.add_theme_font_size_override("font_size",18)
	creator.alignment = HORIZONTAL_ALIGNMENT_LEFT
	creator.custom_minimum_size = Vector2(minf(280.0,MenuStyle.BODY.get_string_size(hero_creator,HORIZONTAL_ALIGNMENT_LEFT,-1,18).x),48)
	for button_state: String in ["normal","hover","pressed"]: creator.add_theme_stylebox_override(button_state,StyleBoxEmpty.new())
	for color_state: String in ["font_color","font_focus_color"]: creator.add_theme_color_override(color_state,MenuStyle.ACCENT)
	creator.add_theme_color_override("font_hover_color",Color("ffe499"))
	creator.add_theme_color_override("font_pressed_color",Color("e7b744"))
	var attribution := HBoxContainer.new()
	attribution.add_theme_constant_override("separation",16)
	info.add_child(attribution)
	var byline := HBoxContainer.new()
	byline.add_theme_constant_override("separation",4)
	attribution.add_child(byline)
	var by := MenuStyle.label("by",18)
	by.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	byline.add_child(by)
	byline.add_child(creator)
	var rating_tile := TrackTile.new()
	rating_tile.entry = rating_entry
	rating_tile.personal_rating = int(records.settings.get("track_ratings",{}).get(str(rating_entry.get("id",selected_track.identity)),0))
	var rating := HBoxContainer.new()
	rating.name = "HeroRating"
	rating.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	rating.add_theme_constant_override("separation",7)
	rating.tooltip_text = "Verified racers" if rating_entry.get("source") == "cloud" else "Local votes on this device"
	attribution.add_child(rating)
	var rating_star := TextureRect.new()
	rating_star.texture = MenuIcon.texture("star_filled" if rating_tile.has_rating() else "star")
	rating_star.modulate = MenuStyle.ACCENT if rating_tile.has_rating() else MenuStyle.MUTED
	rating_star.custom_minimum_size = Vector2(22,22)
	rating_star.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	rating_star.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	rating.add_child(rating_star)
	rating.add_child(MenuStyle.label(rating_tile.rating_text(),18,true))
	rating_tile.free()
	var is_favorite: bool = preview_entry.get("id",selected_track.identity) in records.settings.get("favorites",[])
	var favorite := MenuStyle.button("",_favorite)
	favorite.name = "HeroFavorite"
	favorite.icon = MenuIcon.texture("star_filled" if is_favorite else "star")
	favorite.tooltip_text = "Remove favorite" if is_favorite else "Save favorite"
	favorite.custom_minimum_size = Vector2(48,48)
	favorite.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	favorite.add_theme_stylebox_override("normal",MenuStyle.box(Color("0b202b99"),8))
	favorite.add_theme_color_override("icon_normal_color",MenuStyle.ACCENT if is_favorite else MenuStyle.TEXT)
	title_row.add_child(favorite)
	# Keep the star beside short titles while clipping long names within the hero.
	title_slot.resized.connect(func() -> void:
		title_row.size = Vector2(minf(title_slot.size.x,title_width+12+favorite.get_combined_minimum_size().x),title_slot.size.y))
	var route_column := VBoxContainer.new()
	route_column.add_theme_constant_override("separation",4)
	route_column.custom_minimum_size.x = 220
	row.add_child(route_column)
	var actions := VBoxContainer.new()
	actions.add_theme_constant_override("separation",8)
	row.add_child(actions)
	var close := MenuStyle.button("",_close_track_view)
	close.name = "CloseTrackView"
	close.icon = MenuIcon.texture("close")
	close.tooltip_text = "Back to all tracks"
	close.custom_minimum_size = Vector2(48,48)
	close.add_theme_stylebox_override("normal",MenuStyle.box(Color("0b202b99"),8))
	actions.add_child(close)
	if str(rating_entry.get("version_id","")).length() == 36:
		var share := MenuStyle.button("",func() -> void: share_requested.emit(rating_entry.duplicate(true)))
		share.name = "ShareTrackLink"
		share.icon = MenuIcon.texture("share")
		share.tooltip_text = "Share track link"
		share.custom_minimum_size = Vector2(48,48)
		share.add_theme_stylebox_override("normal",close.get_theme_stylebox("normal"))
		actions.add_child(share)
	var outline := Control.new()
	outline.name = "HeroRouteOutline"
	outline.custom_minimum_size = Vector2(220,96)
	outline.size_flags_vertical = Control.SIZE_EXPAND_FILL
	outline.mouse_filter = Control.MOUSE_FILTER_IGNORE
	route_column.add_child(outline)
	outline.draw.connect(func() -> void:
		var points: PackedVector2Array = hero_points
		if points.size() < 2: return
		var bounds := Rect2(points[0],Vector2.ZERO)
		for point: Vector2 in points: bounds = bounds.expand(point)
		var scale_factor: float = minf((outline.size.x-24)/maxf(1,bounds.size.x),(outline.size.y-24)/maxf(1,bounds.size.y))
		var path := PackedVector2Array()
		for point: Vector2 in points:
			var offset: Vector2 = (point-bounds.get_center())*scale_factor
			path.append(outline.size*0.5+Vector2(offset.x,-offset.y))
		path.append(path[0])
		outline.draw_polyline(path,Color("06131c"),8,true)
		outline.draw_polyline(path,Color.WHITE,4,true))
	outline.resized.connect(outline.queue_redraw)
	route_column.add_child(MenuStyle.label(("~ " if not preview_entry.is_empty() else "")+GameText.message("%.2f KM / LAP") % (hero_length/1000.0),20,true))
	if animate: _slide_section()

func _slide_section() -> void:
	if _section_motion != null: _section_motion.kill()
	_slide_distance = hero.get_parent_control().size.x
	_set_section_offset(_hero_direction*_slide_distance)
	_section_motion = create_tween().set_parallel(true)
	_section_motion.set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	_section_motion.tween_method(_set_section_offset,_section_offset,0.0,HERO_FADE_SECONDS)
	_section_motion.chain().tween_callback(_clear_outgoing_section)

func _prepare_outgoing_section() -> void:
	if _hero_serial < 0 or _hero_serial == _selection_serial or _outgoing_serial == _selection_serial: return
	if _section_motion != null: _section_motion.kill()
	_clear_outgoing_section()
	_outgoing_serial = _selection_serial
	# Retain the actual controls, including custom route drawing and old records.
	for panel: PanelContainer in [hero, records_panel]:
		panel.position.x = 0.0
		_disable_outgoing_input(panel)
		_outgoing_panels.append(panel)
		var replacement := PanelContainer.new()
		var panel_name: String = panel.name
		panel.name = "Outgoing" + panel_name
		replacement.name = panel_name
		replacement.clip_contents = panel.clip_contents
		replacement.add_theme_stylebox_override("panel", panel.get_theme_stylebox("panel"))
		panel.get_parent().add_child(replacement)
		panel.get_parent().move_child(replacement, 0)
		MenuStyle.fill(replacement)
		if panel == hero:
			hero = replacement
			_hero_scenery = null
		else:
			records_panel = replacement
			detail = VBoxContainer.new()
			replacement.add_child(detail)
			pending_records = MenuStyle.label("",18,true)
			replacement.add_child(pending_records)
			pending_records.hide()

func _disable_outgoing_input(node: Node) -> void:
	if node is Control:
		(node as Control).mouse_filter = Control.MOUSE_FILTER_IGNORE
		(node as Control).focus_mode = Control.FOCUS_NONE
	for child: Node in node.get_children(): _disable_outgoing_input(child)

func _clear_outgoing_section() -> void:
	for panel: Control in _outgoing_panels:
		panel.get_parent().remove_child(panel)
		panel.queue_free()
	_outgoing_panels.clear()

func _set_section_offset(value: float) -> void:
	_section_offset = value
	hero.position.x = value
	records_panel.position.x = value
	for panel: Control in _outgoing_panels:
		panel.position.x = value - _hero_direction*_slide_distance


func _section_body(parent: VBoxContainer) -> VBoxContainer:
	var inset := MarginContainer.new()
	inset.size_flags_vertical = Control.SIZE_EXPAND_FILL
	inset.add_theme_constant_override("margin_left",40)
	inset.add_theme_constant_override("margin_right",12)
	inset.add_theme_constant_override("margin_top",5)
	inset.add_theme_constant_override("margin_bottom",8)
	parent.add_child(inset)
	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation",3)
	inset.add_child(content)
	return content

func _friendly_hint(parent: Control, text: String) -> void:
	var hint := MenuStyle.label(text,15,true)
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	parent.add_child(hint)

func _fixed_column(parent: Control, column: Control, column_name: String, width: float) -> void:
	var slot := Control.new()
	slot.name = column_name
	slot.custom_minimum_size.x = width
	slot.clip_contents = true
	parent.add_child(slot)
	slot.add_child(column)
	MenuStyle.fill(column)

func _focus_card(index: int) -> void:
	var left: int = index*tile_stride
	if left < gallery.scroll_horizontal or left+tile_stride-12 > gallery.scroll_horizontal+gallery.size.x:
		gallery.call("_stop_snap")
		gallery.scroll_horizontal = left

func _select_tile(tile: TrackTile) -> void:
	_select(tile.entry)

func _focus_tile(tile: TrackTile) -> void:
	_focus_card(int(tile.get_meta("catalog_index")))
