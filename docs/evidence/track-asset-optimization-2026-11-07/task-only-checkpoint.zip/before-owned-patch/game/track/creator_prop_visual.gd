class_name CreatorPropVisual
extends RefCounted
## Original shared meshes for world placement and browser thumbnails.
const VERSION: String = "authored-props-17-sculpted-wreck-cliff"
const GUARDRAIL = preload("res://track/guardrail_visual.gd")
const WINTER_FINISH = preload("res://track/winter_prop_finish.gd")
const CACHE_LIMIT: int = 96
static var meshes: Dictionary = {}
static var pine_meshes: Dictionary = {}
const CACHE_BUDGET: int = 32 * 1024 * 1024
static var cache_bytes: int = 0
static var _ages: Dictionary = {}
static var _clock: int = 0

static func trim_cache() -> bool:
	assert(Thread.is_main_thread())
	meshes.clear(); pine_meshes.clear(); _ages.clear(); cache_bytes = 0
	return true


class PreparationKit extends Node:
	# Detached CPU helper, without NativeTrackVisual's rendering node/RID.
	var theme_id: String
	func _quad(tool: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, d: Vector3) -> void:
		for point: Vector3 in [a,c,b,a,d,c]: tool.add_vertex(point)

static func _key(kind: String, theme: String, length: float, color: String, optimize: bool = true) -> String:
	var paint: String = ContainerPaint.value({"color":color}) if kind == "container" else ""
	return "%s/%s/%s/%s/%s/%s" % [VERSION,kind,theme,str(length),paint,str(optimize)]

static func _build_model(tool: SurfaceTool, kit: Node, kind: String, length: float, color: String, optimize: bool = true, guardrail: Dictionary = {}) -> bool:
	var paint: String = ContainerPaint.value({"color":color}) if kind == "container" else ""
	if kind == "guardrail":
		GUARDRAIL.append(tool,length if length >= 0.0 else 6.0,guardrail,kit.theme_id == "winter")
		return true
	if PropNature.append(tool,kit,kind,Vector3.ZERO,1.0,0.0,optimize): return true
	if PropEquipment.append(tool,kit,kind,Vector3.ZERO,1.0,0.0,length,paint,optimize): return true
	if PropStructures.append(tool,kit,kind,Vector3.ZERO,1.0,0.0,optimize): return true
	if PropEgypt.append(tool,kind,Vector3.ZERO,1.0,0.0,optimize): return true
	if PropWinterCraft.append(tool,kind,Vector3.ZERO,1.0,0.0): return true
	return PropNight.append(tool,kit,kind,Vector3.ZERO,1.0,0.0)

static func warmed(kind: String, theme: String, length: float, color: String) -> bool:
	assert(Thread.is_main_thread())
	return pine_meshes.has(TrackTheme.foliage(theme).to_html()+"/true") if kind == "tree" else meshes.has(_key(kind,theme,length,color))

static func warm(cancelled: Callable, kind: String, theme: String, length: float = -1.0, color: String = "") -> Dictionary:
	if cancelled.is_valid() and cancelled.call(): return {}
	# The burning-car sculpt cuts a previously encoded wreck mesh. Keep that
	# optional warm-up on the normal installation path rather than reading a
	# mesh from a worker. Placement and rendering still use the exact model.
	if kind == "burning_car": return {}
	var kit := PreparationKit.new(); kit.theme_id = theme
	var tool: SurfaceTool = PropGeometry.model()
	tool.set_meta("prop_cpu_only",true)
	var found: bool = true
	if kind == "tree": _pine_model(tool,kit,Vector3.ZERO,1.0,0.0,TrackTheme.foliage(theme))
	else: found = _build_model(tool,kit,kind,length,color)
	kit.free()
	if not found or (cancelled.is_valid() and cancelled.call()): return {}
	return {"kind":kind,"theme":theme,"length":length,"color":color,"tool":tool}

static func publish_warm(packet: Dictionary) -> bool:
	assert(Thread.is_main_thread())
	if packet.is_empty(): return false
	var kind: String = packet.kind; var theme: String = packet.theme
	if warmed(kind,theme,float(packet.length),str(packet.color)): return true
	var model: ArrayMesh = PropGeometry.finish(packet.tool,kind not in PropEgypt.KINDS and kind not in PropWinterCraft.KINDS and kind not in PropNight.KINDS)
	if theme == "winter" and kind in WINTER_FINISH.KINDS: model = WINTER_FINISH.apply(model,kind,float(packet.length))
	if kind == "tree": _admit(pine_meshes,TrackTheme.foliage(theme).to_html()+"/true",model,32)
	else: _admit(meshes,_key(kind,theme,float(packet.length),str(packet.color)),model,CACHE_LIMIT)
	return true

static func _touch(mesh: Mesh) -> void:
	_clock += 1; _ages[mesh.get_instance_id()] = _clock

static func _bytes(mesh: Mesh) -> int:
	return preload("res://editor/cache_bytes.gd").mesh(mesh)+mesh.get_meta("prop_hidden_triangles",PackedInt32Array()).size()*4

static func _admit(cache: Dictionary, key: String, mesh: Mesh, limit: int) -> void:
	assert(Thread.is_main_thread())
	var size: int = _bytes(mesh)
	if size > CACHE_BUDGET: return
	cache_bytes = size
	for stored: Mesh in meshes.values()+pine_meshes.values(): cache_bytes += _bytes(stored)
	while cache.size() >= limit or cache_bytes > CACHE_BUDGET:
		var victim_cache: Dictionary = cache; var victim: String = ""; var age: int = 9223372036854775807
		for collection: Dictionary in ([cache] if cache.size() >= limit else [meshes,pine_meshes]):
			for candidate: String in collection:
				var candidate_age: int = int(_ages.get(collection[candidate].get_instance_id(),0))
				if candidate_age < age: age = candidate_age; victim = candidate; victim_cache = collection
		if victim.is_empty(): break
		var expired: Mesh = victim_cache[victim]; cache_bytes -= _bytes(expired); _ages.erase(expired.get_instance_id()); victim_cache.erase(victim)
	cache[key] = mesh; _touch(mesh)


static func append(tool: SurfaceTool, kit: Node, kind: String, center: Vector3, scale: float, turn: float, section_length: float = -1.0, color: String = "", optimize: bool = true, guardrail: Dictionary = {}) -> bool:
	assert(Thread.is_main_thread())
	var length: float = section_length/scale if section_length >= 0 else -1.0
	var key: String = _key(kind,kit.theme_id,length,color,optimize)
	if kind == "guardrail" and not guardrail.is_empty(): key += "/"+JSON.stringify(guardrail,"",true)
	var model: Mesh = meshes.get(key)
	if model == null:
		var local: SurfaceTool = PropGeometry.model(0.045 if optimize else -1.0)
		if not _build_model(local,kit,kind,length,color,optimize,guardrail): return false
		# Egyptian relief already has authored facet normals. Rebuilding them
		# after append smooths across tiny stone bevels and shades the flat faces
		# like deep triangular dents under the low Desert sun.
		model = PropGeometry.finish(local,kind not in PropEgypt.KINDS and kind not in PropWinterCraft.KINDS and kind not in PropNight.KINDS)
		if kit.theme_id == "winter" and kind in WINTER_FINISH.KINDS: model = WINTER_FINISH.apply(model,kind,length)
		_admit(meshes,key,model,CACHE_LIMIT)
	_touch(model)
	PropGeometry.append_mesh(tool,model,Transform3D(Basis(Vector3.UP,turn).scaled(Vector3.ONE*scale),center))
	if kind in PropWinterCraft.KINDS or kind in PropEgypt.KINDS or kind in PropNight.KINDS:
		# Keep a building's overlapping trim in its original triangle order inside
		# one spatial draw. These are triangle-corner ends, before hidden pruning.
		var ends: PackedInt32Array = tool.get_meta("spatial_object_ends",PackedInt32Array())
		var centres: PackedVector3Array = tool.get_meta("spatial_object_centres",PackedVector3Array())
		ends.append(int(tool.get_meta("prop_triangle_count"))*3); centres.append(center)
		tool.set_meta("spatial_object_ends",ends); tool.set_meta("spatial_object_centres",centres)
	return true

static func _face(tool: SurfaceTool, kit: Node, center: Vector3, scale: float, turn: float, points: Array, color: Color) -> void:
	var vertices: Array[Vector3] = []
	for point: Vector3 in points: vertices.append(center+(point*scale).rotated(Vector3.UP,turn))
	tool.set_color(color)
	if vertices.size() == 4: kit._quad(tool,vertices[0],vertices[1],vertices[2],vertices[3])
	else:
		for index: int in [0,2,1]: tool.add_vertex(vertices[index])

static func _stone(tool: SurfaceTool, kit: Node, center: Vector3, size: Vector3, turn: float, color: Color) -> void:
	# Three fractured strata and an offset split cap, inside the original footprint.
	var rings: Array = []
	for row: int in range(3):
		var ring: Array[Vector3] = []
		for i: int in range(12):
			var angle: float = TAU*i/12
			var radial: float = 0.92+0.08*sin(i*2.31)
			var reach: float = radial * ([1.0,0.93,0.67][row] + (0.055*sin(i*1.83+row) if row > 0 else 0.0))
			var y: float = [0.0,0.38,0.81][row] + (0.10*sin(i*1.73+row*0.83) if row > 0 else 0.0)
			ring.append(Vector3(cos(angle)*reach+row*0.025,y,sin(angle)*reach-row*0.018)*size)
		rings.append(ring)
	for row: int in range(2):
		for i: int in range(12):
			var j: int = (i+1)%12
			var shade: Color = color.darkened(0.12+0.045*((i+row)%3))
			var a: Vector3 = rings[row][i]; var b: Vector3 = rings[row][j]
			var c: Vector3 = rings[row+1][j]; var d: Vector3 = rings[row+1][i]
			var split: Vector3 = (a+b+c+d)*0.25 + Vector3(cos(i*TAU/12)*0.025,0,sin(i*TAU/12)*0.025)*size
			_leaf_face(tool,kit,center,1,turn,[a,b,split],shade.darkened(0.03))
			_leaf_face(tool,kit,center,1,turn,[b,c,split],shade)
			_leaf_face(tool,kit,center,1,turn,[c,d,split],shade.lightened(0.04))
			_leaf_face(tool,kit,center,1,turn,[d,a,split],shade)
			if row == 1 and i in [1,5,9]:
				var offset := Vector3(cos(i*TAU/12),0,sin(i*TAU/12))*0.004
				_leaf_face(tool,kit,center,1,turn,[a.lerp(d,0.22)+offset,d+offset,d.lerp(c,0.025)+offset],color.darkened(0.42))
	for i: int in range(12):
		var j: int = (i+1)%12
		var cap := Vector3(-0.08,1.0,0.07)*size
		_leaf_face(tool,kit,center,1,turn,[rings[2][i],rings[2][j],cap],color.lightened(0.12+(i%3)*0.04))
	# Short oblique sediment trace sits on one real slope, not a floating decal.
	for i: int in [2,3,7]:
		var a: Vector3 = rings[1][i].lerp(rings[2][i],0.23)
		var b: Vector3 = rings[1][(i+1)%12].lerp(rings[2][(i+1)%12],0.30)
		var offset := Vector3(cos(i*TAU/12)*0.005,0.003,sin(i*TAU/12)*0.005)
		_leaf_face(tool,kit,center,1,turn,[a+offset,b+offset,b+offset+Vector3.UP*size.y*0.009,a+offset+Vector3.UP*size.y*0.009],color.lightened(0.10))

static func _cliff(tool: SurfaceTool, kit: Node, center: Vector3, size: Vector3, turn: float, color: Color) -> void:
	# Continuous rectangular rock wall: exact solid footprint, broken upper ledge.
	var front: Array = []
	var back: Array = []
	for row: int in range(6):
		var f: Array[Vector3] = []
		var b: Array[Vector3] = []
		for i: int in range(7):
			var x: float = -0.5+float(i)/6.0
			var h: float = [0.0,0.16,0.34,0.53,0.73,0.91][row]+(0.11*sin(i*1.9) if row==5 else 0.045*sin(i*1.9+row*0.8) if row>0 else 0.0)
			if row > 0:
				var edge: float = pow(absf(x)*2.0,3.0)
				h *= 1.0-edge*0.30*float(row)/5.0
				x *= 1.0-0.12*float(row)/5.0
			var z: float = 0.5 if row==0 else [0.5,0.46,0.36,0.43,0.29,0.34][row]+0.035*sin(i*2.4)
			if i>0 and i<6 and row>0: x+=0.025*sin(i*3.2+row*0.8)
			f.append(Vector3(x,h,-z)*size)
			b.append(Vector3(x,h+0.015 if row>0 else 0.0,z)*size)
		front.append(f); back.append(b)
	for row: int in range(5):
		for i: int in range(6):
			var shade: Color = color.darkened(0.13+0.045*sin(i*2.1+row*0.9))
			_leaf_face(tool,kit,center,1,turn,[front[row][i],front[row][i+1],front[row+1][i+1],front[row+1][i]],shade)
			_leaf_face(tool,kit,center,1,turn,[back[row][i+1],back[row][i],back[row+1][i],back[row+1][i+1]],shade.darkened(0.10))
		for i: int in [0,6]:
			var points: Array = [front[row][i],back[row][i],back[row+1][i],front[row+1][i]]
			if i==0: points.reverse()
			_leaf_face(tool,kit,center,1,turn,points,color.darkened(0.30))
	for i: int in range(6):
		_leaf_face(tool,kit,center,1,turn,[front[5][i],front[5][i+1],back[5][i+1],back[5][i]],color.lightened(0.22))
	for row: int in [0,2,4]:
		for i: int in [1,3,5]:
			for side: int in [-1,1]:
				var rings: Array = front if side<0 else back
				var lo: Vector3 = rings[row][i].lerp(rings[row][i+1],0.45)
				var hi: Vector3 = rings[row+1][i].lerp(rings[row+1][i+1],0.30)
				var offset := Vector3(0,0,side*0.015)
				var points: Array = [lo.lerp(hi,0.18)+offset,hi+offset,hi+Vector3(size.x*0.008,0,side*0.015)]
				if side>0: points.reverse()
				_leaf_face(tool,kit,center,1,turn,points,color.darkened(0.55))
	# Narrow, interrupted sediment seams on both faces.
	for row: int in [2,4]:
		for i: int in range(6):
			if (i+row)%4==0: continue
			for side: int in [-1,1]:
				var ring: Array = front[row] if side<0 else back[row]
				var a: Vector3 = ring[i]+Vector3(0,0,side*0.012)
				var b: Vector3 = ring[i+1]+Vector3(0,0,side*0.012)
				var points: Array = [a,b,b+Vector3.UP*size.y*0.013,a+Vector3.UP*size.y*0.013]
				if side>0: points.reverse()
				_leaf_face(tool,kit,center,1,turn,points,color.darkened(0.47))

static func _crown(tool: SurfaceTool, kit: Node, center: Vector3, size: Vector3, turn: float, color: Color) -> void:
	# Serrated canopy edge with a single broad light plane and dark underside.
	# Deliberately no rounded rings or spherical leaf clusters.
	var rim: Array[Vector3] = []
	var upper: Array[Vector3] = []
	for i: int in range(18):
		var angle: float = TAU*i/18.0
		var radius: float = (1.0 if i%3 != 1 else 0.77)*(0.91+0.09*sin(i*2.1))
		rim.append(Vector3(cos(angle)*radius,0.24+0.08*sin(i*1.7),sin(angle)*radius)*size)
		upper.append(Vector3(cos(angle)*radius*0.57,0.73+0.07*sin(i*0.9),sin(angle)*radius*0.57)*size)
	for i: int in range(18):
		var j: int = (i+1)%18
		var side_color: Color = color.lightened(0.12) if cos(TAU*i/18.0+turn)>0.2 else color.darkened(0.22)
		_leaf_face(tool,kit,center,1,turn,[rim[i],rim[j],upper[j],upper[i]],side_color)
		_leaf_face(tool,kit,center,1,turn,[upper[i],upper[j],Vector3(-0.13,0.90,0.04)*size],color.lightened(0.26))
		_leaf_face(tool,kit,center,1,turn,[rim[j],rim[i],Vector3(0,0.0,0)*size],color.darkened(0.43))

static func pine(tool: SurfaceTool, kit: Node, center: Vector3, scale: float, turn: float, color: Color, optimize: bool = true) -> void:
	assert(Thread.is_main_thread())
	var key: String = color.to_html()+"/"+str(optimize)
	var model: Mesh = pine_meshes.get(key)
	if model == null:
		var local: SurfaceTool = PropGeometry.model(0.045 if optimize else -1.0)
		_pine_model(local,kit,Vector3.ZERO,1,0,color)
		model = PropGeometry.finish(local); _admit(pine_meshes,key,model,32)
	_touch(model)
	PropGeometry.append_mesh(tool,model,Transform3D(Basis(Vector3.UP,turn).scaled(Vector3.ONE*scale),center))

static func _pine_model(tool: SurfaceTool, kit: Node, center: Vector3, scale: float, turn: float, color: Color) -> void:
	_lathe(tool,kit,center,scale,turn,[Vector2(0.16,0),Vector2(0.10,2.7),Vector2(0,3.2)],[Color("65513c"),Color("8e7951")],true)
	var branches := SurfaceTool.new(); branches.begin(Mesh.PRIMITIVE_TRIANGLES)
	for i: int in range(7):
		var a: float = i*2.4
		PropGeometry.tube(branches,Vector3(0,0.035,0),Vector3(cos(a)*0.24,0.008,sin(a)*0.24),0.055,0.014,Color("63523e"),6)
	# Swept, tapered boughs: dark lower blades and connected upper ridges.
	for tier: int in range(5):
		var radius: float = 1.02-tier*0.17
		var height: float = 0.66+tier*0.49
		for branch: int in range(7):
			var angle: float = turn+branch*TAU/7.0+tier*0.63
			var reach: float = radius*(0.91+0.09*sin(branch*2.7+tier))
			var points: Array[Vector3] = [Vector3(-0.15,height+0.47,0),Vector3(reach*0.63,height+0.12,-reach*0.36),Vector3(reach,height-0.10,-reach*0.13),Vector3(reach*0.83,height-0.02,reach*0.08),Vector3(reach*0.95,height-0.15,reach*0.24),Vector3(reach*0.45,height+0.04,reach*0.40)]
			var ridge := Vector3(reach*0.38,height+0.37,0)
			PropGeometry.tube(branches,Vector3(0,height+0.10,0),Vector3(reach*0.77,height-0.045,0).rotated(Vector3.UP,angle-turn),0.025,0.007,Color("746044"),6)
			for i: int in range(points.size()):
				var j: int = (i+1)%points.size()
				var shade: Color = color.lightened(0.23) if i<3 else color.darkened(0.12)
				_leaf_face(tool,kit,center,scale,angle,[points[i],points[j],ridge],shade)
				_leaf_face(tool,kit,center,scale,angle,[points[j],points[i],Vector3(0,height-0.02,0)],color.darkened(0.40))
			# Split needle tips, rather than a single unbroken triangular blade.
			for spray: int in range(3):
				var p := Vector3(reach*(0.47+spray*0.17),height+0.14-spray*0.075,reach*(-0.19+spray*0.16))
				_leaf_face(tool,kit,center,scale,angle,[p+Vector3(-0.17,0.06,-0.05),p+Vector3(0.16,-0.06,-0.09),p+Vector3(0.13,-0.08,0.09),p+Vector3(-0.13,0.07,0.06)],color.lightened(0.17+(spray%2)*0.06))
	# Small pointed leader rather than a round cap.
	_lathe(tool,kit,center,scale,turn,[Vector2(0.22,2.65),Vector2(0.0,3.3)],[color.lightened(0.20)],true)
	PropGeometry.append_transformed(tool,branches,center,scale,turn)

static func _lathe(tool: SurfaceTool, kit: Node, center: Vector3, scale: float, turn: float, profile: Array, colors: Array, reverse: bool = false) -> void:
	for row: int in range(profile.size()-1):
		for i: int in range(20):
			var a: float=TAU*i/20+turn
			var b: float=TAU*(i+1)/20+turn
			var lo: Vector2=profile[row]
			var hi: Vector2=profile[row+1]
			tool.set_color(colors[row])
			var points: Array[Vector3] = [Vector3(cos(a)*lo.x,lo.y,sin(a)*lo.x),Vector3(cos(b)*lo.x,lo.y,sin(b)*lo.x),Vector3(cos(b)*hi.x,hi.y,sin(b)*hi.x),Vector3(cos(a)*hi.x,hi.y,sin(a)*hi.x)]
			if reverse: points.reverse()
			kit._quad(tool,center+points[0]*scale,center+points[1]*scale,center+points[2]*scale,center+points[3]*scale)

static func _roof(tool: SurfaceTool, kit: Node, center: Vector3, scale: float, turn: float, width: float, depth: float, color: Color) -> void:
	var count: int=ceili(width/0.4)
	for side: float in [-1.0,1.0]:
		for i: int in range(count):
			var x0: float=lerpf(-width*0.5-0.15,width*0.5+0.15,float(i)/count)
			var x1: float=lerpf(-width*0.5-0.15,width*0.5+0.15,float(i+1)/count)
			var points: Array[Vector3]=[Vector3(x0,3.02,side*(depth*0.5+0.15)),Vector3(x1,3.02,side*(depth*0.5+0.15)),Vector3(x1,4.0,0),Vector3(x0,4.0,0)]
			if side<0: points.reverse()
			for j: int in range(4): points[j]=center+(points[j]*scale).rotated(Vector3.UP,turn)
			tool.set_color(color.lightened((i%3)*0.025).darkened(0.08 if side<0 else 0))
			kit._quad(tool,points[0],points[1],points[2],points[3])

static func _leaf_face(tool: SurfaceTool, kit: Node, center: Vector3, scale: float, turn: float, points: Array, color: Color) -> void:
	# Godot's clockwise front faces must point outwards for the ink hull.
	points.reverse()
	_face(tool,kit,center,scale,turn,points,color)
